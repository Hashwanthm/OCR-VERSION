from pathlib import Path
import hashlib
import re
import uuid
from zipfile import ZipFile, ZIP_DEFLATED

import pdfplumber
from flask import Flask, render_template, request, jsonify, send_from_directory
from werkzeug.utils import secure_filename

from openpyxl import Workbook
from openpyxl.styles import Border, Side, Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.properties import PageSetupProperties


app = Flask(__name__)

BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = BASE_DIR / "uploads"
OUTPUT_DIR = BASE_DIR / "outputs"

UPLOAD_DIR.mkdir(exist_ok=True)
OUTPUT_DIR.mkdir(exist_ok=True)


# ======================================================
# CLEANING
# ======================================================

def clean_text(value):
    if value is None:
        return ""

    value = str(value)
    value = value.replace("\n", " ")
    value = value.replace("\xa0", " ")
    value = re.sub(r"\s+", " ", value)
    return value.strip()


def amount_to_number(value):
    value = clean_text(value)

    if value in ["", "-", ".", "0"]:
        return 0.0

    value = value.replace(",", "")
    value = re.sub(r"[^\d.]", "", value)

    if value == "":
        return 0.0

    try:
        return float(value)
    except Exception:
        return 0.0


def extract_financial_year(text, table_rows=None, monthly_rows=None):
    """Extract financial year from the uploaded PDF and return (start_year, end_year).

    EPFO passbooks normally contain text like:
      EPF Passbook [ Financial Year - 2024-2025 ]

    The Form 3A Excel header and browser preview must use that same year:
      Contribution Card ... from 1st April 2024 to 31st March 2025
    """
    parts = [text or ""]

    if table_rows:
        for row in table_rows:
            row_text = " ".join(clean_text(cell) for cell in row if clean_text(cell))
            if row_text:
                parts.append(row_text)

    combined = clean_text(" ".join(parts))

    year_patterns = [
        # EPFO passbook: Financial Year - 2024-2025
        r"Financial\s*Year\s*[-:–—]?\s*(?:\[\s*)?(20\d{2})\s*[-–—/]\s*(20\d{2})",
        # Hindi / mixed extraction around the financial-year line.
        r"(?:वित्तीय|Vittiya|Financial|Year)\s*(?:वर्ष|Varsh|Year)?[^0-9]{0,80}(20\d{2})\s*[-–—/]\s*(20\d{2})",
        # Already formatted Form 3A PDFs.
        r"Currency\s*Period\s*from\s*1st\s*April\s*(20\d{2})\s*to\s*31st\s*March\s*(20\d{2})",
        r"1st\s*April\s*(20\d{2}).{0,100}?31st\s*March\s*(20\d{2})",
    ]

    for pattern in year_patterns:
        match = re.search(pattern, combined, flags=re.IGNORECASE | re.DOTALL)
        if not match:
            continue

        start_year = int(match.group(1))
        end_year = int(match.group(2))

        if 2000 <= start_year <= 2100 and end_year == start_year + 1:
            return str(start_year), str(end_year)

    # Extra robust path: find any consecutive 20XX-20YY pair near FY wording.
    # This catches cases where pdfplumber separates labels and values.
    for match in re.finditer(r"(20\d{2})\s*[-–—/]\s*(20\d{2})", combined):
        start_year = int(match.group(1))
        end_year = int(match.group(2))
        if end_year != start_year + 1:
            continue

        window = combined[max(0, match.start() - 90):match.end() + 90]
        if re.search(r"Financial|Year|Passbook|वित्तीय|वर्ष|Currency\s*Period", window, re.IGNORECASE):
            return str(start_year), str(end_year)

    # Fallback: infer from extracted month rows.
    # Example Mar-2024/Apr-2024 rows -> FY 2024-2025.
    years = []

    if monthly_rows:
        for item in monthly_rows:
            month_value = clean_text(item.get("month", ""))
            match = re.search(r"\b(?:Jan|January|Feb|February|Mar|March|Apr|April|May|Jun|June|Jul|July|Aug|August|Sep|September|Oct|October|Nov|November|Dec|December)[a-z]*[-\s]*(20\d{2})\b", month_value, flags=re.IGNORECASE)
            if match:
                years.append(int(match.group(1)))

    if not years and table_rows:
        for row in table_rows:
            row_text = " ".join(clean_text(cell) for cell in row if clean_text(cell))
            match = re.search(r"\b(?:Jan|January|Feb|February|Mar|March|Apr|April|May|Jun|June|Jul|July|Aug|August|Sep|September|Oct|October|Nov|November|Dec|December)[a-z]*[-\s]*(20\d{2})\b", row_text, flags=re.IGNORECASE)
            if match:
                years.append(int(match.group(1)))

    if years:
        start_year = min(years)
        return str(start_year), str(start_year + 1)

    return "", ""


def set_financial_year_details(details, text, table_rows=None, monthly_rows=None):
    """Add financial-year fields to the details dictionary."""
    start_year, end_year = extract_financial_year(text, table_rows, monthly_rows)

    if start_year and end_year:
        details["financial_year_start"] = start_year
        details["financial_year_end"] = end_year
        details["financial_year"] = f"{start_year}-{end_year}"

    return details


def currency_period_heading(details):
    """Return the Form 3A currency-period heading using the PDF financial year."""
    start_year = clean_text(details.get("financial_year_start", ""))
    end_year = clean_text(details.get("financial_year_end", ""))

    if not start_year or not end_year:
        financial_year = clean_text(details.get("financial_year", ""))
        match = re.search(r"(20\d{2})\s*[-–—/]\s*(20\d{2})", financial_year)
        if match:
            start_year, end_year = match.group(1), match.group(2)

    # Keep old behavior only as a final fallback when the PDF has no readable year.
    if not start_year or not end_year:
        start_year, end_year = "2025", "2026"

    return f"Contribution Card for the Currency Period from 1st April {start_year} to 31st March {end_year}"


def find_value(text, patterns, default=""):
    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE | re.DOTALL)
        if match:
            return clean_text(match.group(1))
    return default


def file_sha256(file_path):
    """Return SHA-256 hash so duplicate PDFs can be rejected."""
    digest = hashlib.sha256()

    with open(file_path, "rb") as file_obj:
        for chunk in iter(lambda: file_obj.read(1024 * 1024), b""):
            digest.update(chunk)

    return digest.hexdigest()


def clean_company_text(value):
    """Clean company / establishment name without replacing it with a wrong default."""
    text = clean_text(value)

    if not text:
        return ""

    # Remove labels or following details that may get joined by pdfplumber.
    text = re.split(
        r"\b(?:Member\s*ID\s*/?\s*Name|Member\s*Passbook|Date\s*of\s*Birth|DOB|UAN\b|EPF\s*Passbook|Financial\s*Year|Taxable\s*Data|Printed\s*On|Dated|2\s*Name\s*/\s*Surname|3\s*Father|5\s*Statutory)\b",
        text,
        maxsplit=1,
        flags=re.IGNORECASE,
    )[0]

    text = re.sub(r"^[\s:/|Iil\-]+", "", text)
    text = re.sub(r"[^A-Za-z0-9\s\.\-&(),]", " ", text)
    text = clean_text(text)

    # If more text is present after a common company suffix, stop there.
    suffix_match = re.search(
        r"(.+?\b(?:PRIVATE\s+LIMITED|PVT\.?\s*LTD\.?|LIMITED|LTD\.?|LLP|INC\.?|COMPANY|CORPORATION)\b)",
        text,
        flags=re.IGNORECASE,
    )
    if suffix_match:
        text = suffix_match.group(1)

    # Avoid accidentally returning labels as names.
    bad_tokens = {"ESTABLISHMENT", "MEMBER", "NAME", "ID"}
    words = [word for word in text.split() if word.upper() not in bad_tokens]

    if len(words) > 12:
        words = words[:12]

    return " ".join(words).strip().upper()


def extract_company_after_establishment_slash(text, table_rows=None):
    """Return (establishment_id, company_name) from the value after '/' in Establishment ID/Name.

    Required rule for EPFO passbook PDFs:
      Establishment ID/Name  DLCPM1020969000 / TRICORE SOLUTIONS PRIVATE LIMITED

    The Excel must paste only the text after the slash as the company/factory
    name. This function checks raw text, extracted table rows, and individual
    row/cell combinations because pdfplumber reads different PDFs differently.
    """

    def parse_value(value):
        value = clean_text(value)
        if not value:
            return "", ""

        # Remove the label if it is included in the same text.
        value = re.sub(
            r".*?Establishment\s*ID\s*/?\s*Name\s*[:\-]?\s*",
            "",
            value,
            flags=re.IGNORECASE,
        )

        # Stop before the next passbook field if text got joined.
        value = re.split(
            r"\b(?:Member\s*ID\s*/?\s*Name|Date\s*of\s*Birth|DOB|UAN\b|Member\s*Passbook|EPF\s*Passbook|Financial\s*Year)\b",
            value,
            maxsplit=1,
            flags=re.IGNORECASE,
        )[0]

        # Best case: ID / COMPANY. Also handles common extraction variants such as |.
        slash_match = re.search(
            r"\b([A-Z]{2,}[A-Z0-9]{8,})\b\s*(?:/|\\|\|)\s*([A-Z][A-Z0-9\s\.\-&(),]+)",
            value,
            flags=re.IGNORECASE,
        )
        if slash_match:
            return slash_match.group(1).upper(), clean_company_text(slash_match.group(2))

        # Fallback: if the slash is lost, take the text after the establishment ID.
        id_match = re.search(r"\b([A-Z]{2,}[A-Z0-9]{8,})\b", value, flags=re.IGNORECASE)
        if id_match:
            after_id = value[id_match.end():]
            return id_match.group(1).upper(), clean_company_text(after_id)

        return "", ""

    candidates = []

    if text:
        candidates.append(text)
        candidates.extend(text.splitlines())

    if table_rows:
        for row in table_rows:
            cells = [clean_text(cell) for cell in row if clean_text(cell)]
            if not cells:
                continue
            row_text = " ".join(cells)
            candidates.append(row_text)

            # If one cell is the label, parse the cells after that label.
            for index, cell in enumerate(cells):
                if re.search(r"Establishment\s*ID\s*/?\s*Name", cell, flags=re.IGNORECASE):
                    candidates.append("Establishment ID/Name " + " ".join(cells[index + 1:]))

    for candidate in candidates:
        if not re.search(r"Establishment\s*ID\s*/?\s*Name", candidate, flags=re.IGNORECASE):
            continue
        establishment_id, company_name = parse_value(candidate)
        if company_name:
            return establishment_id, company_name

    # Last fallback: search the whole combined content without depending on line breaks.
    combined = clean_text(" ".join(candidates))
    match = re.search(
        r"Establishment\s*ID\s*/?\s*Name\s*[:\-]?\s*([A-Z]{2,}[A-Z0-9]{8,})\s*(?:/|\\|\|)\s*([A-Z][A-Z0-9\s\.\-&(),]+?)(?=\s*(?:Member\s*ID\s*/?\s*Name|Date\s*of\s*Birth|DOB|UAN\b|EPF\s*Passbook|Financial\s*Year|$))",
        combined,
        flags=re.IGNORECASE,
    )
    if match:
        return match.group(1).upper(), clean_company_text(match.group(2))

    return "", ""


def extract_establishment_details(text, table_rows=None):
    """Extract establishment ID and company name from passbook text/table rows.

    EPFO passbook PDFs often show this as:
    Establishment ID/Name  PUPUN2423390000 / ETRAVELI INDIA PRIVATE LIMITED

    The previous logic could miss the company name when the slash/spacing was
    read differently, causing the Excel output to fall back to the wrong sample
    company. This function uses line extraction first and regex fallback second.
    """
    raw_parts = [text or ""]

    if table_rows:
        for row in table_rows:
            row_text = " ".join(clean_text(cell) for cell in row if clean_text(cell))
            if row_text:
                raw_parts.append(row_text)

    raw_text = "\n".join(raw_parts)
    establishment_id = ""
    company_name = ""

    # First priority: take company name after the slash in Establishment ID/Name.
    # Example: DLCPM1020969000 / TRICORE SOLUTIONS PRIVATE LIMITED
    # Excel should paste: TRICORE SOLUTIONS PRIVATE LIMITED
    direct_id, direct_company = extract_company_after_establishment_slash(text, table_rows)
    if direct_id:
        establishment_id = direct_id
    if direct_company:
        company_name = direct_company
        return establishment_id, company_name

    # Best path: parse the exact line that contains Establishment ID/Name.
    for line in raw_text.splitlines():
        line_clean = clean_text(line)
        if not re.search(r"Establishment\s*ID\s*/?\s*Name", line_clean, re.IGNORECASE):
            continue

        after_label = re.sub(
            r".*?Establishment\s*ID\s*/?\s*Name\s*[:\-]?\s*",
            "",
            line_clean,
            flags=re.IGNORECASE,
        )

        id_match = re.search(r"\b([A-Z]{2,}[A-Z0-9]{8,})\b", after_label, re.IGNORECASE)
        if id_match:
            establishment_id = establishment_id or id_match.group(1).upper()
            after_id = after_label[id_match.end():]
            possible_company = clean_company_text(after_id)
            if possible_company:
                company_name = possible_company
                break

    normalized = clean_text(raw_text)

    if not establishment_id:
        establishment_id = find_value(normalized, [
            r"Establishment\s*ID\s*/?\s*Name\s*([A-Z]{2,}[A-Z0-9]{8,})",
            r"Establishment\s*ID\s*[:\-]?\s*([A-Z]{2,}[A-Z0-9]{8,})",
        ])

    if not company_name:
        for pattern in [
            r"Establishment\s*ID\s*/?\s*Name\s*[A-Z]{2,}[A-Z0-9]{8,}\s*(?:/|\||\bI\b|\bl\b|:|-)?\s*([A-Z][A-Z0-9\s\.\-&(),]+?)(?=\s*(?:Member\s*ID\s*/?\s*Name|Member\s*Passbook|Date\s*of\s*Birth|DOB|UAN\b|EPF\s*Passbook|Financial\s*Year|$))",
            r"Establishment\s*ID\s*[:\-]?\s*[A-Z]{2,}[A-Z0-9]{8,}\s*(?:/|\||\bI\b|\bl\b|:|-)?\s*([A-Z][A-Z0-9\s\.\-&(),]+?)(?=\s*(?:Member\s*ID\s*/?\s*Name|Date\s*of\s*Birth|DOB|UAN\b|$))",
        ]:
            match = re.search(pattern, normalized, re.IGNORECASE | re.DOTALL)
            if match:
                possible_company = clean_company_text(match.group(1))
                if possible_company:
                    company_name = possible_company
                    break

    return establishment_id, company_name


def cleanup_files(paths):
    """Remove uploaded/temp files after validation failure."""
    for path in paths:
        try:
            Path(path).unlink(missing_ok=True)
        except Exception:
            pass


# ======================================================
# PDF EXTRACTION
# ======================================================

def extract_pdf_text(pdf_path, page_number=0):
    """Extract text from one page only. Default: first page."""

    with pdfplumber.open(pdf_path) as pdf:
        if not pdf.pages:
            return ""

        if page_number >= len(pdf.pages):
            page_number = 0

        page = pdf.pages[page_number]
        return page.extract_text(x_tolerance=2, y_tolerance=3) or ""


def extract_pdf_tables(pdf_path, page_number=0):
    """Extract table rows from one page only. Default: first page."""
    all_rows = []

    line_settings = {
        "vertical_strategy": "lines",
        "horizontal_strategy": "lines",
        "snap_tolerance": 3,
        "join_tolerance": 3,
        "intersection_tolerance": 5,
        "text_x_tolerance": 2,
        "text_y_tolerance": 3,
    }

    text_settings = {
        "vertical_strategy": "text",
        "horizontal_strategy": "text",
        "snap_tolerance": 3,
        "join_tolerance": 3,
        "intersection_tolerance": 5,
        "text_x_tolerance": 2,
        "text_y_tolerance": 3,
    }

    with pdfplumber.open(pdf_path) as pdf:
        if not pdf.pages:
            return all_rows

        if page_number >= len(pdf.pages):
            page_number = 0

        page = pdf.pages[page_number]
        tables = page.extract_tables(table_settings=line_settings)

        if not tables:
            tables = page.extract_tables(table_settings=text_settings)

        for table in tables:
            for row in table:
                cleaned_row = [clean_text(cell) for cell in row]

                if any(cleaned_row):
                    all_rows.append(cleaned_row)

    return all_rows


# ======================================================
# PARSE BASIC DETAILS
# Works for:
# 1. Form 3A PDF
# 2. EPFO passbook PDF
# ======================================================


def extract_member_name_from_passbook(text):
    """Get employee name from EPFO passbook text after Member ID/Name.

    This first tries line-by-line extraction so Hindi labels or nearby text
    do not get added to the employee name. It also accepts separators that
    pdfplumber may read as /, |, I, or l.
    """

    raw_text = text or ""

    def clean_name(candidate):
        candidate = clean_text(candidate)

        # Stop immediately if other labels appear after the name.
        candidate = re.split(
            r"\b(?:Date\s*of\s*Birth|DOB|UAN|EPF\s*Passbook|Financial\s*Year|Taxable\s*Data|Establishment\s*ID|Member\s*Passbook)\b",
            candidate,
            maxsplit=1,
            flags=re.IGNORECASE,
        )[0]

        # Keep only alphabetic name characters and spaces.
        candidate = re.sub(r"[^A-Za-z.\s]", " ", candidate)
        candidate = re.sub(r"\b(Member|ID|Name|Date|Birth|UAN|TUE|FRFFK|LFKKIUK|IKKCQD|VKBZMH)\b", "", candidate, flags=re.IGNORECASE)
        candidate = clean_text(candidate)

        # Avoid extra OCR/pdfplumber garbage after the real name.
        words = [w for w in candidate.split() if len(w) > 1]
        if len(words) > 4:
            words = words[:4]

        return " ".join(words).upper()

    # Best path: read the actual text line that contains Member ID/Name.
    for line in raw_text.splitlines():
        line_clean = clean_text(line)
        if not re.search(r"Member\s*ID\s*/?\s*Name", line_clean, re.IGNORECASE):
            continue

        # Remove label.
        after_label = re.sub(
            r".*?Member\s*ID\s*/?\s*Name\s*[:\-]?\s*",
            "",
            line_clean,
            flags=re.IGNORECASE,
        )

        # Remove member id and separator. Whatever remains on this line is the name.
        after_id = re.sub(
            r"^[A-Z]{2,}[A-Z0-9]{8,}\s*(?:/|\||\bI\b|\bl\b|:)\s*",
            "",
            after_label,
            flags=re.IGNORECASE,
        )

        name = clean_name(after_id)
        if name:
            return name

    normalized = clean_text(raw_text)

    # Fallback: normalized paragraph pattern.
    patterns = [
        r"Member\s*ID\s*/?\s*Name\s*[:\-]?\s*[A-Z]{2,}[A-Z0-9]{8,}\s*(?:/|\||\bI\b|\bl\b|:)\s*([A-Z][A-Z.\s]+?)(?=\s*(?:Date\s*of\s*Birth|DOB|UAN\b|EPF\s*Passbook|Financial\s*Year|Taxable\s*Data|Establishment\s*ID|$))",
        r"Member\s*ID\s*Name\s*[:\-]?\s*[A-Z]{2,}[A-Z0-9]{8,}\s*(?:/|\||\bI\b|\bl\b|:)\s*([A-Z][A-Z.\s]+?)(?=\s*(?:Date\s*of\s*Birth|DOB|UAN\b|EPF\s*Passbook|Financial\s*Year|Taxable\s*Data|Establishment\s*ID|$))",
    ]

    for pattern in patterns:
        match = re.search(pattern, normalized, re.IGNORECASE | re.DOTALL)
        if match:
            name = clean_name(match.group(1))
            if name:
                return name

    return ""


def normalize_passbook_text_for_details(text, table_rows=None):
    """Join first-page text and table rows to improve detail extraction."""
    parts = [text or ""]

    if table_rows:
        for row in table_rows:
            row_text = " ".join(clean_text(cell) for cell in row if clean_text(cell))
            if row_text:
                parts.append(row_text)

    return "\n".join(parts)

def parse_basic_details(text, table_rows=None):
    normalized = clean_text(normalize_passbook_text_for_details(text, table_rows))

    details = {
        "account_no": "",
        "uan": "",
        "name": "",
        "father_name": "",
        "factory_address": "",
        "establishment_id": "",
        "company_name": "",
        "statutory_rate": "12%",
        "higher_rate_employee": "NO",
        "higher_rate_employer": "NO",
        "higher_rate_pension": "NO",
        "date": "",
        "financial_year_start": "",
        "financial_year_end": "",
        "financial_year": "",
    }

    # Member ID / Name from EPFO passbook
    member_id = find_value(normalized, [
        r"Member\s*ID\s*/?\s*Name\s*([A-Z0-9]+)\s*(?:/|\||\bI\b|\bl\b)?",
        r"Member\s*ID\s*[:\-]?\s*([A-Z0-9]+)",
    ])

    # Take employee name from the raw Member ID/Name line first.
    # This prevents nearby Hindi/OCR text from being pasted into the name.
    member_name = extract_member_name_from_passbook(text) or extract_member_name_from_passbook(normalized)

    # Establishment ID / Name from EPFO passbook.
    # This is also used as the Form 3A company/factory name when the input is
    # an EPFO passbook PDF.
    establishment_id, establishment_name = extract_establishment_details(text, table_rows)

    # Mandatory company rule: take the company name after '/' in Establishment ID/Name.
    # Example: "DLCPM1020969000 / TRICORE SOLUTIONS PRIVATE LIMITED" ->
    # company/factory name = "TRICORE SOLUTIONS PRIVATE LIMITED".
    direct_establishment_id, direct_company_name = extract_company_after_establishment_slash(text, table_rows)
    if direct_establishment_id:
        establishment_id = direct_establishment_id
    if direct_company_name:
        establishment_name = direct_company_name

    if not establishment_id:
        establishment_id = find_value(normalized, [
            r"Establishment\s*ID\s*/?\s*Name\s*([A-Z0-9]+)\s*(?:/|\||\bI\b|\bl\b)?",
            r"Establishment\s*ID\s*([A-Z0-9]+)",
        ])

    if not establishment_name:
        establishment_name = find_value(normalized, [
            r"Establishment\s*ID\s*/?\s*Name\s*[A-Z0-9]+\s*(?:/|\||\bI\b|\bl\b)?\s*([A-Z0-9\s\.\-&]+?)(?:\s*Member\s*ID|\s*Member|$)",
        ])
        establishment_name = clean_company_text(establishment_name)

    # Form 3A account number
    account_no = find_value(normalized, [
        r"1\s*Account\s*No\.?\s*([A-Z0-9]+)",
        r"Account\s*No\.?\s*([A-Z0-9]+)",
    ])

    details["account_no"] = account_no or member_id
    details["establishment_id"] = establishment_id

    details["uan"] = find_value(normalized, [
        r"\bUAN\b\s*([0-9]{8,20})",
    ])

    # Form 3A name
    form_name = find_value(normalized, [
        r"2\s*Name\s*/\s*Surname\s*([A-Z][A-Z\s\.]+?)(?:\s*\(in\s*Block|\s*3\s*Father|\s*Father)",
        r"Name\s*/\s*Surname\s*([A-Z][A-Z\s\.]+?)(?:\s*\(in\s*Block|\s*3\s*Father|\s*Father)",
    ])

    details["name"] = member_name or form_name

    details["father_name"] = find_value(normalized, [
        r"3\s*Father'?s\s*/\s*Husband'?s\s*Name\s*([A-Z][A-Z\s\.]+?)(?:\s*4\s*Name|\s*Name\s*&\s*Address)",
        r"Father'?s\s*/\s*Husband'?s\s*Name\s*([A-Z][A-Z\s\.]+?)(?:\s*4\s*Name|\s*Name\s*&\s*Address)",
    ])

    factory_address = find_value(normalized, [
        r"4\s*Name\s*&\s*Address\s*of\s*the\s*Factory\s*(.*?)(?:Establishment\s*ID)",
        r"Name\s*&\s*Address\s*of\s*the\s*Factory\s*(.*?)(?:Establishment\s*ID)",
    ])

    cleaned_factory_address = clean_text(factory_address)
    cleaned_establishment_name = clean_company_text(establishment_name)

    # For passbook PDFs, there is no separate Form 3A factory address field.
    # Use the establishment/company name from the passbook instead of a fixed
    # sample default so the generated Excel matches the selected PDF.
    details["factory_address"] = cleaned_factory_address or cleaned_establishment_name
    details["company_name"] = cleaned_establishment_name

    if not details["company_name"] and cleaned_factory_address:
        details["company_name"] = clean_company_text(cleaned_factory_address.split(",")[0])

    statutory_rate = find_value(normalized, [
        r"Statutory\s*rate\s*of\s*Contribution\s*([0-9]+%?)",
    ])

    if statutory_rate:
        if "%" not in statutory_rate:
            statutory_rate += "%"
        details["statutory_rate"] = statutory_rate

    details["date"] = find_value(normalized, [
        r"Dated\s*([0-9]{1,2}[/-][0-9]{1,2}[/-][0-9]{2,4})",
        r"Printed\s*On\s*[:\-]?\s*([0-9]{1,2}[/-][0-9]{1,2}[/-][0-9]{2,4})",
    ])

    set_financial_year_details(details, text, table_rows)

    return details


# ======================================================
# PARSE MONTHLY TABLE
# Works for Form 3A and EPFO passbook
# ======================================================

MONTH_PATTERN = r"^(Jan|January|Feb|February|Mar|March|Apr|April|May|Jun|June|Jul|July|Aug|August|Sep|September|Oct|October|Nov|November|Dec|December)"


def is_month_text(value):
    value = clean_text(value)
    return bool(re.match(MONTH_PATTERN, value, re.IGNORECASE))


def numeric_cells(cells):
    nums = []

    for cell in cells:
        text = clean_text(cell)

        if text == "":
            continue

        # Pick values like 15000, 15,000, 1800, 1,800, 0, 0.00
        if re.fullmatch(r"-?\d+(?:,\d{3})*(?:\.\d+)?", text):
            nums.append(amount_to_number(text))

    return nums


def calculate_correct_form3a_split(wages, epf_amount):
    """Return the corrected Form 3A employer split.

    Correct sheet rule requested:
      1. Pension fund 4(B) = ROUND(8.33% of wage, capped at 15,000 wage).
      2. EPF&8-1/3% 4(A) = EPF column amount - calculated pension fund.

    Example: wage 15,000 and EPF 1,800 -> pension 1,250 and EPF 4(A) 550.
    """
    wages = float(wages or 0)
    epf_amount = float(epf_amount or 0)

    if wages <= 0 or epf_amount <= 0:
        return 0.0, 0.0

    pension_base = min(wages, 15000.0)
    pension_fund = round(pension_base * 8.33 / 100)
    epf_833_difference = max(epf_amount - pension_fund, 0.0)

    return round(epf_833_difference, 2), round(pension_fund, 2)


def add_correct_and_incorrect_values(row):
    """Keep both Excel sheet values on each row.

    Incorrect sheet = values exactly extracted from the PDF employer/pension columns.
    Correct sheet = recalculated split using the 8.33% pension rule.
    """
    wages = amount_to_number(row.get("wages", 0))
    epf = amount_to_number(row.get("epf", 0))

    raw_epf_833 = amount_to_number(row.get("raw_epf_833", row.get("epf_833", 0)))
    raw_pension = amount_to_number(row.get("raw_pension", row.get("pension", 0)))
    correct_epf_833, correct_pension = calculate_correct_form3a_split(wages, epf)

    row["raw_epf_833"] = raw_epf_833
    row["raw_pension"] = raw_pension
    row["correct_epf_833"] = correct_epf_833
    row["correct_pension"] = correct_pension

    # Backwards-compatible keys are the Correct sheet values.
    row["epf_833"] = correct_epf_833
    row["pension"] = correct_pension

    return row


def rows_for_sheet(monthly_rows, sheet_type="correct"):
    """Return JSON/workbook rows for either Correct or Incorrect sheet."""
    output_rows = []

    for item in monthly_rows or []:
        row = dict(item)

        if sheet_type == "incorrect":
            row["epf_833"] = amount_to_number(row.get("raw_epf_833", row.get("epf_833", 0)))
            row["pension"] = amount_to_number(row.get("raw_pension", row.get("pension", 0)))
        else:
            row["epf_833"] = amount_to_number(row.get("correct_epf_833", row.get("epf_833", 0)))
            row["pension"] = amount_to_number(row.get("correct_pension", row.get("pension", 0)))

        output_rows.append(row)

    return output_rows


# Kept for compatibility with older code paths, but the new output uses
# calculate_correct_form3a_split() and also keeps raw PDF values for Incorrect.
def split_employer_share_for_form3a(wages, employer_amount, pension_amount=0.0):
    wages = float(wages or 0)
    employer_amount = float(employer_amount or 0)
    pension_amount = float(pension_amount or 0)

    if wages <= 0 or employer_amount <= 0:
        return 0.0, pension_amount

    if pension_amount > 0:
        return round(employer_amount, 2), round(pension_amount, 2)

    return calculate_correct_form3a_split(wages, employer_amount)


def parse_monthly_rows_from_tables(table_rows):
    monthly_rows = []

    for row in table_rows:
        if not row:
            continue

        cells = [clean_text(cell) for cell in row]

        if not cells:
            continue

        first_cell = cells[0]

        if not is_month_text(first_cell):
            continue

        row_text = " ".join(cells).upper()

        # EPFO passbook has CR / DR.
        # We use only CR contribution rows.
        if " DR " in f" {row_text} ":
            continue

        is_passbook_row = " CR " in f" {row_text} " or "CONTR" in row_text or "DUE-MONTH" in row_text

        if is_passbook_row:
            nums = numeric_cells(cells)

            # Expected EPFO passbook numeric sequence:
            # wages_epf, wages_eps, employee_contribution, employer_contribution, pension
            # We paste into Form 3A as: Wages, EPF, EPF 3.67%, Pension 8.33%.
            if len(nums) >= 5:
                wages = nums[0]
                employee_epf = nums[2]
                employer_amount = nums[3]
                pension_from_pdf = nums[4]
                monthly_rows.append(add_correct_and_incorrect_values({
                    "month": first_cell,
                    "wages": wages,
                    "epf": employee_epf,
                    "raw_epf_833": employer_amount,
                    "raw_pension": pension_from_pdf,
                    "refund": 0.0,
                    "non_contribution_days": 0.0,
                    "remarks": "",
                }))
            elif len(nums) >= 3:
                wages = nums[0]
                employee_epf = nums[1]
                employer_amount = nums[2]
                monthly_rows.append(add_correct_and_incorrect_values({
                    "month": first_cell,
                    "wages": wages,
                    "epf": employee_epf,
                    "raw_epf_833": employer_amount,
                    "raw_pension": 0.0,
                    "refund": 0.0,
                    "non_contribution_days": 0.0,
                    "remarks": "",
                }))

        else:
            # Form 3A table row:
            # Month, Wages, EPF, EPF 8 1/3, Pension, Refund, Days, Remarks
            while len(cells) < 8:
                cells.append("")

            monthly_rows.append(add_correct_and_incorrect_values({
                "month": cells[0],
                "wages": amount_to_number(cells[1]),
                "epf": amount_to_number(cells[2]),
                "raw_epf_833": amount_to_number(cells[3]),
                "raw_pension": amount_to_number(cells[4]),
                "refund": amount_to_number(cells[5]),
                "non_contribution_days": amount_to_number(cells[6]),
                "remarks": cells[7],
            }))

    return monthly_rows


def parse_monthly_rows_from_text(text):
    monthly_rows = []

    for line in text.splitlines():
        line = clean_text(line)

        if not is_month_text(line):
            continue

        upper_line = line.upper()

        if " DR " in f" {upper_line} ":
            continue

        # This fallback works for many selectable PDFs.
        amounts = re.findall(r"\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+\.\d{2}", line)

        if len(amounts) >= 4:
            first_amount_pos = line.find(amounts[0])
            month_part = line[:first_amount_pos].strip()

            values = [amount_to_number(x) for x in amounts]

            wages = values[0]
            epf = values[1] if len(values) > 1 else 0
            employer_amount = values[2] if len(values) > 2 else 0
            pension_from_text = values[3] if len(values) > 3 else 0

            monthly_rows.append(add_correct_and_incorrect_values({
                "month": month_part,
                "wages": wages,
                "epf": epf,
                "raw_epf_833": employer_amount,
                "raw_pension": pension_from_text,
                "refund": 0.0,
                "non_contribution_days": 0.0,
                "remarks": "",
            }))

    return monthly_rows


def parse_monthly_rows(table_rows, text):
    monthly_rows = parse_monthly_rows_from_tables(table_rows)

    if monthly_rows:
        return monthly_rows

    return parse_monthly_rows_from_text(text)


# ======================================================
# SAFE EXCEL HELPERS
# Fixes:
# 'MergedCell' object attribute 'value' is read-only
# ======================================================

def get_real_cell(ws, cell_ref):
    for merged_range in ws.merged_cells.ranges:
        if cell_ref in merged_range:
            min_col, min_row, max_col, max_row = merged_range.bounds
            return ws.cell(row=min_row, column=min_col)

    return ws[cell_ref]


def set_cell(ws, cell_ref, value, bold=False, size=8.5, align="left"):
    cell = get_real_cell(ws, cell_ref)
    cell.value = value
    cell.font = Font(bold=bold, size=size)
    cell.alignment = Alignment(
        horizontal=align,
        vertical="center",
        wrap_text=True
    )
    return cell


def make_border():
    thin = Side(style="thin", color="000000")
    return Border(left=thin, right=thin, top=thin, bottom=thin)


def apply_border(ws, start_row, start_col, end_row, end_col):
    border = make_border()

    for row in ws.iter_rows(
        min_row=start_row,
        max_row=end_row,
        min_col=start_col,
        max_col=end_col
    ):
        for cell in row:
            cell.border = border
            cell.alignment = Alignment(
                horizontal=cell.alignment.horizontal or "center",
                vertical="center",
                wrap_text=True
            )


# ======================================================
# CREATE FORM 3A EXCEL OUTPUT
# ======================================================

def set_cell(ws, cell_ref, value, bold=False, size=8.5, align="left", valign="center", underline=False):
    cell = get_real_cell(ws, cell_ref)
    cell.value = value
    cell.font = Font(name="Arial", bold=bold, size=size, underline="single" if underline else None)
    cell.alignment = Alignment(
        horizontal=align,
        vertical=valign,
        wrap_text=True
    )
    return cell


def remove_workbook_gridlines(wb):
    """Hide Excel sheet gridlines for every downloaded workbook/sheet."""
    for sheet in wb.worksheets:
        # Removes the grey Excel gridlines from the normal worksheet view.
        sheet.sheet_view.showGridLines = False

        # Also prevents gridlines from appearing when printing/exporting.
        sheet.print_options.gridLines = False
        sheet.print_options.gridLinesSet = True


def apply_outer_border(ws, start_row, start_col, end_row, end_col):
    medium = Side(style="medium", color="000000")

    for col in range(start_col, end_col + 1):
        ws.cell(start_row, col).border = Border(
            top=medium,
            left=ws.cell(start_row, col).border.left,
            right=ws.cell(start_row, col).border.right,
            bottom=ws.cell(start_row, col).border.bottom,
        )
        ws.cell(end_row, col).border = Border(
            bottom=medium,
            left=ws.cell(end_row, col).border.left,
            right=ws.cell(end_row, col).border.right,
            top=ws.cell(end_row, col).border.top,
        )

    for row in range(start_row, end_row + 1):
        ws.cell(row, start_col).border = Border(
            left=medium,
            top=ws.cell(row, start_col).border.top,
            right=ws.cell(row, start_col).border.right,
            bottom=ws.cell(row, start_col).border.bottom,
        )
        ws.cell(row, end_col).border = Border(
            right=medium,
            top=ws.cell(row, end_col).border.top,
            left=ws.cell(row, end_col).border.left,
            bottom=ws.cell(row, end_col).border.bottom,
        )


def write_form3a_month_values(ws, monthly_rows, data_start, total_data_rows):
    """Write monthly contribution values into an already formatted Form 3A sheet."""
    for i in range(total_data_rows):
        excel_row = data_start + i

        if i < len(monthly_rows):
            item = monthly_rows[i]
        else:
            item = {
                "month": "",
                "wages": 0,
                "epf": 0,
                "epf_833": 0,
                "pension": 0,
                "refund": 0,
                "non_contribution_days": 0,
                "remarks": "",
            }

        set_cell(ws, f"A{excel_row}", item.get("month", ""))
        ws[f"B{excel_row}"] = amount_to_number(item.get("wages", 0))
        ws[f"C{excel_row}"] = amount_to_number(item.get("epf", 0))
        ws[f"D{excel_row}"] = amount_to_number(item.get("epf_833", 0))
        ws[f"E{excel_row}"] = amount_to_number(item.get("pension", 0))
        ws[f"F{excel_row}"] = "-" if not item.get("refund") else amount_to_number(item.get("refund", 0))
        ws[f"G{excel_row}"] = amount_to_number(item.get("non_contribution_days", 0))

        for col in range(2, 6):
            cell = ws.cell(row=excel_row, column=col)
            cell.number_format = "0.00"
            cell.alignment = Alignment(horizontal="right", vertical="center")

        ws[f"G{excel_row}"].number_format = "0.00"
        ws[f"G{excel_row}"].alignment = Alignment(horizontal="right", vertical="center")
        ws[f"F{excel_row}"].alignment = Alignment(horizontal="center", vertical="center")


def write_form3a_total_values(ws, data_start, total_data_rows):
    """Write visible calculated totals into the Form 3A sheet.

    This is intentionally written as values instead of only Excel formulas so
    totals are visible immediately in the browser preview and in downloaded
    workbooks even before Excel recalculates formulas.
    """
    total_row = data_start + total_data_rows
    cert_row = total_row + 2

    def sum_column(col_index):
        total = 0.0
        for row_num in range(data_start, total_row):
            value = ws.cell(row=row_num, column=col_index).value
            total += amount_to_number(value)
        return round(total, 2)

    totals = {
        2: sum_column(2),  # Amount of wages
        3: sum_column(3),  # EPF
        4: sum_column(4),  # EPF&8-1/3% if any
        5: sum_column(5),  # Pension fund
        7: sum_column(7),  # Non-contributing days
    }

    set_cell(ws, f"A{total_row}", "TOTAL", bold=True, align="left")

    for col_index, total_value in totals.items():
        cell = ws.cell(row=total_row, column=col_index)
        cell.value = total_value
        cell.font = Font(name="Arial", bold=True, size=8.5)
        cell.number_format = "0.00"
        cell.alignment = Alignment(horizontal="right", vertical="center")

    ws[f"F{total_row}"] = "-"
    ws[f"F{total_row}"].font = Font(name="Arial", bold=True, size=8.5)
    ws[f"F{total_row}"].alignment = Alignment(horizontal="center", vertical="center")

    # Certification amount block below the table.
    epf_plus_difference = round(totals[3] + totals[4], 2)
    pension_total = round(totals[5], 2)

    epf_total_cell = get_real_cell(ws, f"G{cert_row}")
    epf_total_cell.value = epf_plus_difference
    epf_total_cell.font = Font(name="Arial", bold=True, size=8.5)
    epf_total_cell.number_format = "0.00"
    epf_total_cell.alignment = Alignment(horizontal="center", vertical="center")

    pension_total_cell = get_real_cell(ws, f"F{cert_row + 1}")
    pension_total_cell.value = f"{pension_total:.2f}\n(vide below)"
    pension_total_cell.font = Font(name="Arial", bold=True, underline="single", size=8.5)
    pension_total_cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    return totals


def create_form3a_excel(details, monthly_rows, excel_path, full_text="", table_rows=None):
    wb = Workbook()
    ws = wb.active
    ws.title = "Correct"

    # Keep downloaded workbook as A4 landscape, but do not collapse/shrink
    # the sheet vertically. Excel opens in a readable normal view like before.
    remove_workbook_gridlines(wb)
    set_financial_year_details(details, full_text, table_rows, monthly_rows)

    ws.sheet_view.view = "normal"
    # Open the downloaded workbook at a normal readable zoom.
    # Earlier compact preview settings made the real Excel workbook look too tiny.
    ws.sheet_view.zoomScale = 105
    ws.sheet_view.zoomScaleNormal = 105
    ws.sheet_view.topLeftCell = "A1"

    ws.sheet_properties.pageSetUpPr = PageSetupProperties(fitToPage=True)
    ws.page_setup.orientation = "landscape"
    ws.page_setup.paperSize = ws.PAPERSIZE_A4
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.page_setup.horizontalDpi = 300
    ws.page_setup.verticalDpi = 300

    # A4 margins kept small, but not zero, so the full form prints neatly.
    ws.page_margins.left = 0.20
    ws.page_margins.right = 0.20
    ws.page_margins.top = 0.25
    ws.page_margins.bottom = 0.25
    ws.page_margins.header = 0.10
    ws.page_margins.footer = 0.10
    ws.print_options.horizontalCentered = True

    # Neat downloaded workbook widths.
    # The browser preview uses its own CSS; the real .xlsx should be readable
    # when opened in Excel and still print within A4 landscape using fitToWidth.
    column_widths = {
        "A": 13.0,   # Month / labels
        "B": 12.5,   # Wages / detail values
        "C": 11.5,   # EPF
        "D": 12.0,   # EPF & 8-1/3%
        "E": 12.5,   # Pension fund
        "F": 9.5,    # Refund
        "G": 13.0,   # Non-contributing days
        "H": 17.0,   # Remarks / right-side answers
    }

    for col, width in column_widths.items():
        ws.column_dimensions[col].width = width

    for row_no in range(1, 90):
        ws.row_dimensions[row_no].height = 17

    ws.row_dimensions[1].height = 21
    ws.row_dimensions[2].height = 18
    ws.row_dimensions[3].height = 18
    ws.row_dimensions[4].height = 22
    ws.row_dimensions[8].height = 24
    ws.row_dimensions[9].height = 24
    ws.row_dimensions[11].height = 22
    ws.row_dimensions[12].height = 22
    ws.row_dimensions[14].height = 26
    ws.row_dimensions[15].height = 24
    ws.row_dimensions[16].height = 24
    ws.row_dimensions[17].height = 24
    ws.row_dimensions[20].height = 24
    ws.row_dimensions[21].height = 38
    ws.row_dimensions[22].height = 18

    # ==================================================
    # HEADER - same visual style as the sample screenshot
    # ==================================================

    ws.merge_cells("A1:G1")
    set_cell(
        ws,
        "A1",
        "Form No.3A (Revised) ( See Paragraphs 35 & 42 of the Employees Provident Funds Scheme , 1952)",
        bold=True,
        size=9,
        align="center"
    )
    set_cell(ws, "H1", "S.No\n1", bold=True, size=8, align="center")

    ws.merge_cells("A2:H2")
    set_cell(
        ws,
        "A2",
        "(See Paragraph 19 of the Employees Pension Scheme , 1995)",
        size=8,
        align="center"
    )

    ws.merge_cells("A3:H3")
    set_cell(
        ws,
        "A3",
        "(FOR UNEXEMPTED ESTABLISHMENTS ONLY)",
        bold=True,
        size=9,
        align="center"
    )

    ws.merge_cells("A4:H4")
    set_cell(
        ws,
        "A4",
        currency_period_heading(details),
        bold=True,
        size=9,
        align="center"
    )

    # ==================================================
    # TOP DETAILS
    # ==================================================

    highlight_fill = PatternFill("solid", fgColor="FFF2CC")

    set_cell(ws, "A6", "1 Account No.")
    ws.merge_cells("B6:D6")
    account_cell = set_cell(ws, "B6", details.get("account_no", ""), bold=True)
    account_cell.fill = highlight_fill
    for row in ws["B6:D6"]:
        for cell in row:
            cell.fill = highlight_fill

    set_cell(ws, "A7", "   UAN")
    ws.merge_cells("B7:D7")
    uan_cell = set_cell(ws, "B7", details.get("uan", ""), bold=True)
    uan_cell.fill = highlight_fill
    for row in ws["B7:D7"]:
        for cell in row:
            cell.fill = highlight_fill

    set_cell(ws, "A8", "2 Name / Surname")
    set_cell(ws, "A9", "   (in Block Capitals)")
    ws.merge_cells("B8:D9")
    set_cell(ws, "B8", details.get("name", ""))

    set_cell(ws, "A11", "3 Father's/Husband's")
    set_cell(ws, "A12", "   Name")
    ws.merge_cells("B11:D12")
    set_cell(ws, "B11", details.get("father_name", ""))

    set_cell(ws, "A14", "4 Name & Address")
    set_cell(ws, "A15", "   of the Factory/")
    ws.merge_cells("B14:D17")
    set_cell(ws, "B14", details.get("factory_address", ""), valign="top")

    set_cell(ws, "A18", "   Establishment ID")
    ws.merge_cells("B18:D18")
    set_cell(ws, "B18", details.get("establishment_id", ""))

    ws.merge_cells("E6:G6")
    set_cell(ws, "E6", "5 Statutory rate of Contribution")
    set_cell(ws, "H6", details.get("statutory_rate", "12%"), bold=True, underline=True, align="center")

    ws.merge_cells("E8:G9")
    set_cell(ws, "E8", "6 Voluntary higher rate of employee's\n   contribution if any")
    ws.merge_cells("H8:H9")
    set_cell(ws, "H8", details.get("higher_rate_employee", "NO"), bold=True, underline=True, align="center")

    ws.merge_cells("E10:G11")
    set_cell(ws, "E10", "7 Employer contribution on Hr. wages to\n   EPF (ER) Y/N")
    ws.merge_cells("H10:H11")
    set_cell(ws, "H10", details.get("higher_rate_employer", "NO"), bold=True, underline=True, align="center")

    ws.merge_cells("E12:G13")
    set_cell(ws, "E12", "8 Voluntary contribution to Pension Y/N")
    ws.merge_cells("H12:H13")
    set_cell(ws, "H12", details.get("higher_rate_pension", "NO"), bold=True, underline=True, align="center")

    # ==================================================
    # TABLE HEADER
    # ==================================================

    ws.merge_cells("A20:A22")
    set_cell(ws, "A20", "Months", bold=True, align="center")

    ws.merge_cells("B20:C20")
    set_cell(ws, "B20", "Employees' Share", bold=True, align="center")

    ws.merge_cells("D20:E20")
    set_cell(ws, "D20", "Employer's share", bold=True, align="center")

    ws.merge_cells("F20:F21")
    set_cell(ws, "F20", "Refund of\nadvance", bold=True, align="center")

    ws.merge_cells("G20:G21")
    set_cell(ws, "G20", "No.of days /\nperiod of non-\ncontributing\nservice if any", bold=True, align="center")

    ws.merge_cells("H20:H21")
    set_cell(ws, "H20", "Remarks", bold=True, align="center")

    set_cell(ws, "B21", "Amount of\nWages", bold=True, align="center")
    set_cell(ws, "C21", "EPF", bold=True, align="center")
    set_cell(ws, "D21", "EPF&8-1/3%\nif any", bold=True, align="center")
    set_cell(ws, "E21", "Pension fund\ncontri 8-1/3%", bold=True, align="center")

    column_numbers = ["1", "2", "3", "4(A)", "4(B)", "5", "6", "7"]

    for col_index, number in enumerate(column_numbers, start=1):
        cell_ref = ws.cell(row=22, column=col_index).coordinate
        set_cell(ws, cell_ref, number, bold=False, align="center")

    # ==================================================
    # MONTHLY DATA
    # ==================================================

    data_start = 23
    minimum_month_rows = 12
    total_data_rows = max(minimum_month_rows, len(monthly_rows))

    for i in range(total_data_rows):
        excel_row = data_start + i
        ws.row_dimensions[excel_row].height = 17

        if i < len(monthly_rows):
            item = monthly_rows[i]
        else:
            item = {
                "month": "",
                "wages": 0,
                "epf": 0,
                "epf_833": 0,
                "pension": 0,
                "refund": 0,
                "non_contribution_days": 0,
                "remarks": "",
            }

        set_cell(ws, f"A{excel_row}", item["month"])
        ws[f"B{excel_row}"] = item["wages"]
        ws[f"C{excel_row}"] = item["epf"]
        ws[f"D{excel_row}"] = item["epf_833"]
        ws[f"E{excel_row}"] = item["pension"]
        ws[f"F{excel_row}"] = "-" if not item.get("refund") else item["refund"]
        ws[f"G{excel_row}"] = item["non_contribution_days"]

        for col in range(2, 6):
            cell = ws.cell(row=excel_row, column=col)
            cell.number_format = "0.00"
            cell.alignment = Alignment(horizontal="right", vertical="center")

        ws[f"G{excel_row}"].number_format = "0.00"
        ws[f"G{excel_row}"].alignment = Alignment(horizontal="right", vertical="center")
        ws[f"F{excel_row}"].alignment = Alignment(horizontal="center", vertical="center")

    # Remarks block as shown in the Form 3A sample.
    if total_data_rows >= 12:
        ws.merge_cells(start_row=data_start, start_column=8, end_row=data_start + 5, end_column=8)
        set_cell(ws, f"H{data_start}", "a) Date of\nleaving", align="center", valign="top")
        ws.merge_cells(start_row=data_start + 6, start_column=8, end_row=data_start + 11, end_column=8)
        set_cell(ws, f"H{data_start + 6}", "b) Reasons\nfor leaving", align="center", valign="top")

    # ==================================================
    # TOTAL ROW
    # ==================================================

    total_row = data_start + total_data_rows
    ws.row_dimensions[total_row].height = 20

    set_cell(ws, f"A{total_row}", "TOTAL", bold=True)

    for col in [2, 3, 4, 5, 7]:
        col_letter = get_column_letter(col)
        cell = ws[f"{col_letter}{total_row}"]
        cell.value = f"=SUM({col_letter}{data_start}:{col_letter}{total_row - 1})"
        cell.font = Font(name="Arial", bold=True, size=8.5)
        cell.number_format = "0.00"
        cell.alignment = Alignment(horizontal="right", vertical="center")

    ws[f"F{total_row}"] = "-"
    ws[f"F{total_row}"].alignment = Alignment(horizontal="center", vertical="center")

    # ==================================================
    # CERTIFICATION AREA
    # ==================================================

    cert_row = total_row + 2
    ws.row_dimensions[cert_row].height = 42
    ws.row_dimensions[cert_row + 1].height = 28

    ws.merge_cells(start_row=cert_row, start_column=1, end_row=cert_row + 1, end_column=5)
    set_cell(
        ws,
        f"A{cert_row}",
        "Certified that the total amount of contribution (both shares) indicated in this card i.e.,\n"
        "has already been remitted in full in EPF A/C No.1 and Pension Fund A/C No.10",
        align="left",
        valign="top"
    )

    set_cell(ws, f"F{cert_row}", "RS.", bold=True, align="center")
    ws.merge_cells(start_row=cert_row, start_column=7, end_row=cert_row, end_column=8)
    epf_total_cell = set_cell(ws, f"G{cert_row}", f"=C{total_row}+D{total_row}", bold=True, align="center")
    epf_total_cell.number_format = "0.00"

    ws.merge_cells(start_row=cert_row + 1, start_column=6, end_row=cert_row + 1, end_column=8)
    set_cell(ws, f"F{cert_row + 1}", "(vide below)", bold=True, align="center")

    cert_row_2 = cert_row + 4
    ws.row_dimensions[cert_row_2].height = 48

    ws.merge_cells(start_row=cert_row_2, start_column=1, end_row=cert_row_2 + 2, end_column=8)
    set_cell(
        ws,
        f"A{cert_row_2}",
        "Certified that the difference between the total of the contributions shown under columns(3) and 4(a) & 4(b) of the above\n"
        "table and that arrived at on the total wages shown in Col(2) at the prescribed rate is solely due to rounding off of\n"
        "contribution to the nearest rupee under the rules.",
        align="left",
        valign="top"
    )

    sign_row = cert_row_2 + 5
    ws.row_dimensions[sign_row].height = 30

    company_name = details.get("company_name") or details.get("factory_address") or ""

    ws.merge_cells(start_row=sign_row, start_column=5, end_row=sign_row, end_column=8)
    set_cell(ws, f"E{sign_row}", f"For {company_name}," if company_name else "For", bold=True, align="center")

    date_row = sign_row + 4
    set_cell(ws, f"A{date_row}", "Dated")
    set_cell(ws, f"B{date_row}", details.get("date", ""), bold=True, align="center")

    ws.merge_cells(start_row=date_row, start_column=6, end_row=date_row, end_column=8)
    set_cell(ws, f"F{date_row}", "Authorised Signatory", bold=True, align="center")

    note_row = date_row + 3
    ws.row_dimensions[note_row].height = 52
    ws.row_dimensions[note_row + 1].height = 38

    ws.merge_cells(start_row=note_row, start_column=1, end_row=note_row + 2, end_column=8)
    set_cell(
        ws,
        f"A{note_row}",
        "Note:- In respect of Form 3(A) sent to the Regional Office during the Course of the Currency period for the purpose of\n"
        "final settlement of the accounts of the member who had left service details of date and reason for leaving service.\n"
        "Should be furnished under column7(A) & (B)\n"
        "In respect of those who are not members of the Pension Fund the employers share of contribution to the EPF\n"
        "will be  8-1/3 or 10 % as the case may be and is to be shown under Column 4(b).",
        align="left",
        valign="top"
    )

    final_row = note_row + 2

    apply_border(ws, 1, 1, final_row, 8)
    apply_outer_border(ws, 1, 1, final_row, 8)

    # Final workbook polish: keep all cells readable, not overly compact.
    # Do not shrink fonts to 7.5; that made the downloaded Excel look tiny.
    for row in ws.iter_rows(min_row=1, max_row=final_row, min_col=1, max_col=8):
        for cell in row:
            current_size = float(cell.font.sz or 8.5)
            current_size = max(8.0, min(current_size, 10.0))
            cell.font = Font(
                name="Arial",
                bold=cell.font.bold,
                italic=cell.font.italic,
                underline=cell.font.underline,
                color=cell.font.color,
                size=current_size,
            )
            cell.alignment = Alignment(
                horizontal=cell.alignment.horizontal or "center",
                vertical=cell.alignment.vertical or "center",
                wrap_text=True,
                shrink_to_fit=False,
            )

    header_fill = PatternFill("solid", fgColor="E5E7EB")
    section_fill = PatternFill("solid", fgColor="F8FAFC")
    for header_row in range(20, 23):
        for header_cell in ws[header_row]:
            header_cell.fill = header_fill
            header_cell.font = Font(name="Arial", bold=True, size=8.5)

    for top_row in [1, 2, 3, 4]:
        for top_cell in ws[top_row]:
            top_cell.fill = section_fill

    # Make important text areas easier to read in the downloaded workbook.
    for range_ref in ["A1:H4", "A6:H18", f"A20:H{total_row}"]:
        for range_row in ws[range_ref]:
            for range_cell in range_row:
                range_cell.alignment = Alignment(
                    horizontal=range_cell.alignment.horizontal or "center",
                    vertical=range_cell.alignment.vertical or "center",
                    wrap_text=True,
                    shrink_to_fit=False,
                )

    # Write totals as actual visible values, not only formulas.
    write_form3a_total_values(ws, data_start, total_data_rows)

    ws.print_area = f"A1:H{final_row}"
    ws.freeze_panes = f"A{data_start}"

    # Add second sheet requested by user.
    # Correct sheet: 8.33% pension is calculated and EPF&8-1/3 is the difference.
    # Incorrect sheet: exact employer/pension contribution values extracted from the PDF.
    ws.sheet_properties.tabColor = "16A34A"

    incorrect_ws = wb.copy_worksheet(ws)
    incorrect_ws.title = "Incorrect"
    incorrect_ws.sheet_properties.tabColor = "DC2626"
    write_form3a_month_values(
        incorrect_ws,
        rows_for_sheet(monthly_rows, "incorrect"),
        data_start,
        total_data_rows
    )
    # Recalculate and write totals for the raw/exact PDF values sheet too.
    write_form3a_total_values(incorrect_ws, data_start, total_data_rows)

    # Keep first sheet visible first when the workbook opens.
    wb.active = 0

    # Keep downloaded workbook readable on both Correct and Incorrect sheets.
    for sheet in wb.worksheets:
        sheet.sheet_view.view = "normal"
        sheet.sheet_view.zoomScale = 105
        sheet.sheet_view.zoomScaleNormal = 105
        sheet.sheet_view.topLeftCell = "A1"
        sheet.sheet_view.showGridLines = False
        sheet.print_options.gridLines = False
        sheet.print_options.gridLinesSet = True

    # Keep gridlines hidden in the downloaded workbook.
    remove_workbook_gridlines(wb)
    wb.save(excel_path)


# ======================================================
# FLASK ROUTES
# ======================================================

@app.route("/")
def home():
    return render_template("index.html")


@app.route("/convert", methods=["POST"])
def convert_pdf():
    # User can upload 1 to 10 different PDFs.
    # Each PDF is converted into one separate Form 3A workbook.
    files = request.files.getlist("pdfs")

    if not files:
        single_file = request.files.get("pdf")
        files = [single_file] if single_file else []

    files = [file for file in files if file and file.filename]

    if len(files) < 1:
        return jsonify({"error": "Please upload at least 1 PDF file"}), 400

    if len(files) > 10:
        return jsonify({"error": "Maximum 10 PDF files are allowed"}), 400

    for file in files:
        if not file.filename.lower().endswith(".pdf"):
            return jsonify({"error": f"Only PDF files are allowed: {file.filename}"}), 400

    batch_id = uuid.uuid4().hex
    saved_files = []
    seen_hashes = {}

    # First save and verify all PDFs are different.
    for file_index, file in enumerate(files, start=1):
        safe_name = secure_filename(file.filename) or f"pdf_{file_index}.pdf"
        uploaded_pdf_name = f"{batch_id}_{file_index}_{safe_name}"
        uploaded_pdf_path = UPLOAD_DIR / uploaded_pdf_name
        file.save(uploaded_pdf_path)

        pdf_hash = file_sha256(uploaded_pdf_path)
        if pdf_hash in seen_hashes:
            cleanup_files([uploaded_pdf_path] + [item[2] for item in saved_files])
            return jsonify({
                "error": (
                    "Duplicate PDF detected. Please upload different PDF files. "
                    f"Duplicate files: {seen_hashes[pdf_hash]} and {safe_name}"
                )
            }), 400

        seen_hashes[pdf_hash] = safe_name
        saved_files.append((file_index, safe_name, uploaded_pdf_path))

    converted_files = []
    failed_files = []

    for file_index, safe_name, uploaded_pdf_path in saved_files:
        try:
            # Extract only first page. Page index 0 means first page.
            text = extract_pdf_text(uploaded_pdf_path, page_number=0)
            table_rows = extract_pdf_tables(uploaded_pdf_path, page_number=0)

            details = parse_basic_details(text, table_rows)
            monthly_rows = parse_monthly_rows(table_rows, text)
            set_financial_year_details(details, text, table_rows, monthly_rows)

            excel_name = f"{Path(safe_name).stem}_form3a_{batch_id}_{file_index}.xlsx"
            excel_path = OUTPUT_DIR / excel_name

            create_form3a_excel(details, monthly_rows, excel_path, full_text=text, table_rows=table_rows)

            correct_monthly_rows = rows_for_sheet(monthly_rows, "correct")
            incorrect_monthly_rows = rows_for_sheet(monthly_rows, "incorrect")

            converted_files.append({
                "original_name": safe_name,
                "excel_name": excel_name,
                "details": details,
                # Backward compatibility: default preview is Correct sheet.
                "monthly_rows": correct_monthly_rows,
                "correct_monthly_rows": correct_monthly_rows,
                "incorrect_monthly_rows": incorrect_monthly_rows,
                "download_url": f"/download/{excel_name}",
                "pdf_index": file_index - 1,
                "status": "success",
            })

        except Exception as error:
            failed_files.append({
                "original_name": safe_name,
                "error": str(error),
                "pdf_index": file_index - 1,
                "status": "failed",
            })

    requested_count = len(saved_files)

    if not converted_files:
        return jsonify({
            "error": f"No workbooks were created. Please check the uploaded PDF file(s).",
            "files": converted_files,
            "failed_files": failed_files,
            "expected_count": requested_count,
            "workbook_count": 0,
            "max_count": 10,
        }), 500

    # Create one ZIP containing all generated workbooks.
    # This avoids browser blocking caused by forcing multiple separate automatic downloads.
    zip_name = f"form3a_{len(converted_files)}_workbook{'s' if len(converted_files) != 1 else ''}_{batch_id}.zip"
    zip_path = OUTPUT_DIR / zip_name

    with ZipFile(zip_path, "w", ZIP_DEFLATED) as zip_file:
        used_names = set()

        for item in converted_files:
            excel_path = OUTPUT_DIR / item["excel_name"]
            arcname = f"{Path(item['original_name']).stem}_form3a.xlsx"

            # Avoid duplicate names inside the zip if two original file names are similar.
            if arcname in used_names:
                arcname = f"{Path(item['original_name']).stem}_form3a_{item['pdf_index'] + 1}.xlsx"

            used_names.add(arcname)
            zip_file.write(excel_path, arcname=arcname)

    first = converted_files[0]

    return jsonify({
        "message": f"{len(converted_files)} workbook(s) created successfully",
        "files": converted_files,
        "failed_files": failed_files,
        "details": first["details"],
        "monthly_rows": first["monthly_rows"],
        "download_url": first["download_url"],
        "download_all_url": f"/download/{zip_name}",
        "expected_count": requested_count,
        "workbook_count": len(converted_files),
        "max_count": 10,
    })

@app.route("/download/<filename>")
def download_excel(filename):
    return send_from_directory(
        OUTPUT_DIR,
        filename,
        as_attachment=True
    )


if __name__ == "__main__":
    app.run(debug=True)
