const pdfInput = document.getElementById("pdfInput");
const convertBtn = document.getElementById("convertBtn");
const pdfArea = document.getElementById("pdfArea");
const excelArea = document.getElementById("excelArea");
const statusBox = document.getElementById("status");
const downloadBtn = document.getElementById("downloadBtn");
const downloadAllBtn = document.getElementById("downloadAllBtn");
const pdfCount = document.getElementById("pdfCount");
const pdfSelector = document.getElementById("pdfSelector");
const loadingModal = document.getElementById("loadingModal");
const loadingText = document.getElementById("loadingText");
const workbookName = document.getElementById("workbookName");
const excelZoomOutBtn = document.getElementById("excelZoomOut");
const excelZoomInBtn = document.getElementById("excelZoomIn");
const excelZoomResetBtn = document.getElementById("excelZoomReset");
const excelZoomValue = document.getElementById("excelZoomValue");

const MAX_PDFS = 10;

let selectedFiles = [];
let selectedPdfUrls = [];
let convertedFiles = [];
let failedFiles = [];
let activeIndex = 0;
let activeSheetMode = "correct";
let excelPreviewZoom = 1.38;

updatePdfCount(0);
resetPdfSelector();
setConvertAvailability();

function updatePdfCount(count) {
  if (pdfCount) {
    pdfCount.textContent = `${count} / ${MAX_PDFS} PDFs selected`;
  }
}

function setConvertAvailability() {
  if (!convertBtn) return;

  convertBtn.disabled = selectedFiles.length < 1 || selectedFiles.length > MAX_PDFS;
}

function resetPdfSelector() {
  if (pdfSelector) {
    pdfSelector.innerHTML = `<option>No file selected</option>`;
    pdfSelector.disabled = true;
  }

  updateWorkbookName(null);
}

function updatePdfSelector() {
  if (!pdfSelector) return;

  if (!selectedFiles.length) {
    resetPdfSelector();
    return;
  }

  pdfSelector.disabled = false;
  pdfSelector.innerHTML = selectedFiles.map((file, index) => {
    const failed = getFailedByPdfIndex(index);
    const failedText = failed ? " - failed" : "";

    // Keep dropdown compact: no tick icon and no long Excel workbook name.
    return `<option value="${index}" title="${escapeHtml(file.name)}">PDF ${index + 1}: ${escapeHtml(shortFileName(file.name, 38))}${failedText}</option>`;
  }).join("");

  pdfSelector.value = String(activeIndex);
}

if (pdfSelector) {
  pdfSelector.addEventListener("change", function () {
    const index = Number(pdfSelector.value || 0);
    selectPdf(index);
  });
}

function updateExcelZoomControls() {
  if (excelZoomValue) {
    excelZoomValue.textContent = `${Math.round(excelPreviewZoom * 100)}%`;
  }

  const holder = document.getElementById("formPreviewHolder");
  if (holder) {
    holder.style.zoom = String(excelPreviewZoom);
  }
}

function changeExcelZoom(delta) {
  excelPreviewZoom = Math.max(0.8, Math.min(2.2, Number((excelPreviewZoom + delta).toFixed(2))));
  updateExcelZoomControls();
}

if (excelZoomOutBtn) {
  excelZoomOutBtn.addEventListener("click", function () {
    changeExcelZoom(-0.15);
  });
}

if (excelZoomInBtn) {
  excelZoomInBtn.addEventListener("click", function () {
    changeExcelZoom(0.15);
  });
}

if (excelZoomResetBtn) {
  excelZoomResetBtn.addEventListener("click", function () {
    excelPreviewZoom = 1.38;
    updateExcelZoomControls();
  });
}

updateExcelZoomControls();

function showLoading(message) {
  if (loadingText) {
    loadingText.textContent = message || `Please wait. Reading first page and creating ${selectedFiles.length || 1} Form 3A workbook(s).`;
  }

  if (loadingModal) {
    loadingModal.style.display = "flex";
  }
}

function hideLoading() {
  if (loadingModal) {
    loadingModal.style.display = "none";
  }
}

function basicDuplicateFileCheck(files) {
  const seen = new Map();

  for (const file of files) {
    const key = `${file.name.toLowerCase()}-${file.size}`;

    if (seen.has(key)) {
      return {
        hasDuplicate: true,
        firstName: seen.get(key),
        duplicateName: file.name
      };
    }

    seen.set(key, file.name);
  }

  return { hasDuplicate: false };
}

async function findDuplicatePdf(files) {
  // Compare actual file content. This catches renamed duplicate PDFs also.
  // If browser hashing is unavailable, fall back to a basic filename + size check.
  if (!window.crypto || !window.crypto.subtle) {
    return basicDuplicateFileCheck(files);
  }

  const seenHashes = new Map();

  for (const file of files) {
    const buffer = await file.arrayBuffer();
    const hashBuffer = await window.crypto.subtle.digest("SHA-256", buffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hash = hashArray.map(byte => byte.toString(16).padStart(2, "0")).join("");

    if (seenHashes.has(hash)) {
      return {
        hasDuplicate: true,
        firstName: seenHashes.get(hash),
        duplicateName: file.name
      };
    }

    seenHashes.set(hash, file.name);
  }

  return { hasDuplicate: false };
}

function getSelectedNumberHtml() {
  // Keep preview panels clean.
  // The selected PDF is already clear from the dropdown and pairing line.
  return "";
}

function getPairingHtml(index) {
  // Keep both preview panels clean.
  // The selected PDF is already shown in the dropdown.
  return "";
}

function updateWorkbookName(index) {
  if (!workbookName) return;

  if (index === null || index === undefined || !selectedFiles.length) {
    workbookName.textContent = "No workbook selected";
    workbookName.title = "";
    return;
  }

  const converted = getConvertedByPdfIndex(index);
  const failed = getFailedByPdfIndex(index);

  if (converted) {
    workbookName.textContent = `Selected: ${shortFileName(converted.excel_name, 28)}`;
    workbookName.title = converted.excel_name;
  } else if (failed) {
    workbookName.textContent = `Selected: PDF ${index + 1} failed`;
    workbookName.title = failed.error || "Conversion failed";
  } else {
    workbookName.textContent = `Selected: PDF ${index + 1} workbook pending`;
    workbookName.title = selectedFiles[index]?.name || "";
  }
}

pdfInput.addEventListener("change", async function () {
  selectedFiles = Array.from(pdfInput.files || []);
  convertedFiles = [];
  failedFiles = [];
  activeIndex = 0;
  activeSheetMode = "correct";

  downloadBtn.style.display = "none";
  downloadBtn.href = "#";
  downloadAllBtn.style.display = "none";
  downloadAllBtn.href = "#";
  updateWorkbookName(null);

  if (selectedFiles.length > MAX_PDFS) {
    const tooManyCount = selectedFiles.length;
    pdfInput.value = "";
    selectedFiles = [];
    selectedPdfUrls.forEach(url => URL.revokeObjectURL(url));
    selectedPdfUrls = [];
    updatePdfCount(0);
    resetPdfSelector();
    setConvertAvailability();
    setStatus(`Maximum ${MAX_PDFS} PDF files are allowed. You selected ${tooManyCount}.`, "error");
    pdfArea.innerHTML = `<div class="empty">Select up to ${MAX_PDFS} different PDF files.</div>`;
    excelArea.innerHTML = `<div class="empty">Remove extra files and upload again.</div>`;
    return;
  }

  const duplicateCheck = await findDuplicatePdf(selectedFiles);
  if (duplicateCheck.hasDuplicate) {
    pdfInput.value = "";
    selectedFiles = [];
    selectedPdfUrls.forEach(url => URL.revokeObjectURL(url));
    selectedPdfUrls = [];
    updatePdfCount(0);
    resetPdfSelector();
    setConvertAvailability();
    setStatus(`Duplicate PDF detected: ${duplicateCheck.firstName} and ${duplicateCheck.duplicateName}. Please upload different PDF files. Maximum limit is ${MAX_PDFS}.`, "error");
    pdfArea.innerHTML = `<div class="empty">Upload different PDF files. Maximum limit is ${MAX_PDFS}.</div>`;
    excelArea.innerHTML = `<div class="empty">Converted Form 3A preview will appear here.</div>`;
    return;
  }

  if (selectedFiles.some(file => file.type !== "application/pdf" && !file.name.toLowerCase().endsWith(".pdf"))) {
    pdfInput.value = "";
    selectedFiles = [];
    selectedPdfUrls.forEach(url => URL.revokeObjectURL(url));
    selectedPdfUrls = [];
    updatePdfCount(0);
    resetPdfSelector();
    setConvertAvailability();
    setStatus("Only PDF files are allowed.", "error");
    pdfArea.innerHTML = `<div class="empty">Upload PDF files only.</div>`;
    excelArea.innerHTML = `<div class="empty">Converted Form 3A preview will appear here.</div>`;
    return;
  }

  selectedPdfUrls.forEach(url => URL.revokeObjectURL(url));
  selectedPdfUrls = selectedFiles.map(file => URL.createObjectURL(file));
  updatePdfCount(selectedFiles.length);
  updatePdfSelector();
  setConvertAvailability();

  if (!selectedFiles.length) {
    updatePdfCount(0);
    resetPdfSelector();
    pdfArea.innerHTML = `
      <div class="empty">
        Upload 1 to 10 PDF files to preview them here.
      </div>
    `;
    excelArea.innerHTML = `
      <div class="empty">
        Converted Form 3A preview will appear here.
      </div>
    `;
    setStatus("Ready", "");
    return;
  }

  selectPdf(0);

  setStatus(`${selectedFiles.length} PDF file(s) selected. Click Convert to create ${selectedFiles.length} Excel workbook(s).`, "success");
});

convertBtn.addEventListener("click", async function () {
  if (!selectedFiles.length) {
    setStatus(`Please select 1 to ${MAX_PDFS} PDF file(s) first.`, "error");
    return;
  }

  if (selectedFiles.length > MAX_PDFS) {
    setStatus(`Maximum ${MAX_PDFS} PDF files are allowed. Currently selected: ${selectedFiles.length}.`, "error");
    return;
  }

  const duplicateCheck = await findDuplicatePdf(selectedFiles);
  if (duplicateCheck.hasDuplicate) {
    setStatus(`Duplicate PDF detected: ${duplicateCheck.firstName} and ${duplicateCheck.duplicateName}. Please upload different PDF files. Maximum limit is ${MAX_PDFS}.`, "error");
    return;
  }

  const formData = new FormData();
  selectedFiles.forEach(file => formData.append("pdfs", file));

  convertBtn.disabled = true;
  convertBtn.textContent = "Converting...";
  downloadBtn.style.display = "none";
  downloadAllBtn.style.display = "none";

  showLoading(`Converting ${selectedFiles.length} PDF file(s). Reading first page only and creating ${selectedFiles.length} Form 3A workbook(s)...`);
  setStatus(`Reading first page of ${selectedFiles.length} PDF file(s) and preparing ${selectedFiles.length} Form 3A workbook(s)...`, "");

  try {
    const response = await fetch("/convert", {
      method: "POST",
      body: formData
    });

    const result = await response.json();

    if (!response.ok) {
      throw new Error(result.error || "Conversion failed");
    }

    convertedFiles = result.files || [];
    failedFiles = result.failed_files || [];

    if (!convertedFiles.length) {
      throw new Error(result.error || "No workbooks were created.");
    }

    downloadAllBtn.href = result.download_all_url || "#";
    downloadAllBtn.style.display = result.download_all_url ? "inline-block" : "none";

    updatePdfSelector();
    selectPdf(activeIndex);

    const failedCount = failedFiles.length;
    if (downloadAllBtn) {
      downloadAllBtn.textContent = `Download ZIP (${convertedFiles.length})`;
    }

    const message = failedCount
      ? `${convertedFiles.length} workbook(s) created. ${failedCount} PDF(s) failed. Use dropdown to check each PDF.`
      : `${convertedFiles.length} workbook(s) created successfully. Download all as one ZIP, or use Download Workbook for the selected PDF.`;

    setStatus(message, failedCount ? "error" : "success");

  } catch (error) {
    excelArea.innerHTML = `
      <div class="empty">
        Conversion failed.
      </div>
    `;

    setStatus(error.message, "error");

  } finally {
    hideLoading();
    convertBtn.textContent = "Convert";
    setConvertAvailability();
  }
});

function selectPdf(index) {
  if (!selectedFiles.length) return;

  activeIndex = Math.max(0, Math.min(index, selectedFiles.length - 1));
  updateWorkbookName(activeIndex);
  updatePdfSelector();
  renderPdfPreview(activeIndex);
  renderExcelPreviewForPdf(activeIndex);
}

function setPreviewSheetMode(mode) {
  activeSheetMode = mode === "incorrect" ? "incorrect" : "correct";
  renderExcelPreviewForPdf(activeIndex);
}

window.setPreviewSheetMode = setPreviewSheetMode;

function getRowsForPreview(converted) {
  if (!converted) return [];

  if (activeSheetMode === "incorrect") {
    return converted.incorrect_monthly_rows || converted.monthly_rows || [];
  }

  return converted.correct_monthly_rows || converted.monthly_rows || [];
}

function renderSheetTabs() {
  const correctActive = activeSheetMode === "correct" ? "active" : "";
  const incorrectActive = activeSheetMode === "incorrect" ? "active" : "";

  return `
    <div class="sheet-tabs-preview">
      <button type="button" class="sheet-tab-preview ${correctActive}" onclick="setPreviewSheetMode('correct')">Correct Sheet</button>
      <button type="button" class="sheet-tab-preview ${incorrectActive}" onclick="setPreviewSheetMode('incorrect')">Incorrect Sheet</button>
    </div>
  `;
}

function renderPdfPreview(index) {
  const pdfUrl = selectedPdfUrls[index];

  pdfArea.innerHTML = `
    ${getSelectedNumberHtml()}
    ${getPairingHtml(index)}
    <iframe
      class="pdf-preview"
      src="${pdfUrl}#page=1&toolbar=1&navpanes=0&view=FitH"
      title="First page PDF preview">
    </iframe>
  `;
}

function renderExcelPreviewForPdf(pdfIndex) {
  const converted = getConvertedByPdfIndex(pdfIndex);
  const failed = getFailedByPdfIndex(pdfIndex);

  if (converted) {
    const correctRows = converted.correct_monthly_rows || converted.monthly_rows || [];
    const incorrectRows = converted.incorrect_monthly_rows || converted.monthly_rows || [];

    excelArea.innerHTML = `
      ${getSelectedNumberHtml()}
      ${getPairingHtml(pdfIndex)}
      <div id="formPreviewHolder" class="two-sheet-holder"></div>
    `;

    const holder = document.getElementById("formPreviewHolder");
    holder.innerHTML = `
      ${renderForm3AHtml(converted.details || {}, correctRows, "Correct Sheet - 8.33% Calculated")}
      ${renderForm3AHtml(converted.details || {}, incorrectRows, "Incorrect Sheet - Exact PDF Values")}
    `;
    updateExcelZoomControls();

    if (converted.download_url) {
      downloadBtn.href = converted.download_url;
      downloadBtn.style.display = "inline-block";
    }
    return;
  }

  downloadBtn.style.display = "none";
  downloadBtn.href = "#";

  if (failed) {
    excelArea.innerHTML = `
      ${getSelectedNumberHtml()}
      ${getPairingHtml(pdfIndex)}
      <div class="empty">
        Conversion failed for PDF ${pdfIndex + 1}.<br>
        ${escapeHtml(failed.error || "Unknown error")}
      </div>
    `;
    return;
  }

  excelArea.innerHTML = `
    ${getSelectedNumberHtml()}
    ${getPairingHtml(pdfIndex)}
    <div class="empty">
      Upload 1 to 10 PDFs, then click Convert.<br>
      One workbook will be created for each PDF.
    </div>
  `;
}

function getConvertedByPdfIndex(pdfIndex) {
  return convertedFiles.find(item => Number(item.pdf_index) === Number(pdfIndex));
}

function getFailedByPdfIndex(pdfIndex) {
  return failedFiles.find(item => Number(item.pdf_index) === Number(pdfIndex));
}

function renderForm3AHtml(details, monthlyRows, sheetLabel = "Correct Sheet") {
  const rows = [...monthlyRows];
  const currencyPeriodText = getCurrencyPeriodText(details || {}, rows);

  while (rows.length < 12) {
    rows.push({
      month: "",
      wages: 0,
      epf: 0,
      epf_833: 0,
      pension: 0,
      refund: 0,
      non_contribution_days: 0,
      remarks: ""
    });
  }

  const totals = rows.reduce((acc, row) => {
    acc.wages += toNumber(row.wages);
    acc.epf += toNumber(row.epf);
    acc.epf833 += toNumber(row.epf_833);
    acc.pension += toNumber(row.pension);
    acc.days += toNumber(row.non_contribution_days);
    return acc;
  }, { wages: 0, epf: 0, epf833: 0, pension: 0, days: 0 });

  const companyName = details.company_name || details.factory_address || "";
  const name = cleanPreviewName(details.name || "");

  const bodyRows = rows.map((row, index) => {
    const remark = index === 0
      ? `a) Date of<br>leaving`
      : index === 6
        ? `b) Reasons<br>for leaving`
        : "";

    return `
      <tr>
        <td class="month-cell">${escapeHtml(row.month || "")}</td>
        <td class="num">${formatAmount(row.wages)}</td>
        <td class="num">${formatAmount(row.epf)}</td>
        <td class="num">${formatAmount(row.epf_833)}</td>
        <td class="num">${formatAmount(row.pension)}</td>
        <td class="center">-</td>
        <td class="num">${formatAmount(row.non_contribution_days)}</td>
        <td class="remarks-cell">${remark}</td>
      </tr>
    `;
  }).join("");

  return `
    <div class="form-preview-wrap">
      <div class="sheet-mode-label">${escapeHtml(sheetLabel)}</div>
      <section class="form3a-sheet">
        <div class="form3a-topline">
          <strong>Form No.3A (Revised)</strong>
          <span>( See Paragraphs 35 &amp; 42 of the Employees Provident Funds Scheme , 1952)</span>
        </div>
        <div class="form3a-title">(See Paragraph 19 of the Employees Pension Scheme , 1995)</div>
        <div class="form3a-title bold">(FOR UNEXEMPTED ESTABLISHMENTS ONLY)</div>
        <div class="form3a-title bold period-title">${escapeHtml(currencyPeriodText)}</div>

        <div class="details-layout">
          <div class="left-details">
            <div class="detail-row"><div>1 Account No.</div><div class="highlight-value">${escapeHtml(details.account_no || "")}</div></div>
            <div class="detail-row"><div>&nbsp;&nbsp;&nbsp;UAN</div><div class="highlight-value">${escapeHtml(details.uan || "")}</div></div>
            <div class="detail-row name-row"><div>2 Name / Surname<br><span>(in Block Capitals)</span></div><div class="strong-name">${escapeHtml(name)}</div></div>
            <div class="detail-row father-row"><div>3 Father's/Husband's<br><span>Name</span></div><div>${escapeHtml(details.father_name || "")}</div></div>
            <div class="detail-row address-row"><div>4 Name &amp; Address<br><span>of the Factory/</span></div><div>${escapeHtml(details.factory_address || companyName)}</div></div>
            <div class="detail-row"><div>&nbsp;&nbsp;&nbsp;Establishment ID</div><div>${escapeHtml(details.establishment_id || "")}</div></div>
          </div>

          <div class="right-details">
            <div class="right-detail-line"><span>5 Statutory rate of Contribution</span><strong>${escapeHtml(details.statutory_rate || "12%")}</strong></div>
            <div class="right-detail-line tall"><span>6 Voluntary higher rate of employee's<br>&nbsp;&nbsp;&nbsp;contribution if any</span><strong>NO</strong></div>
            <div class="right-detail-line tall"><span>7 Employer contribution on Hr. wages to<br>&nbsp;&nbsp;&nbsp;EPF (ER) Y/N</span><strong>NO</strong></div>
            <div class="right-detail-line"><span>8 Voluntary contribution to Pension Y/N</span><strong>NO</strong></div>
          </div>
        </div>

        <table class="form3a-table">
          <thead>
            <tr>
              <th rowspan="2">Months</th>
              <th colspan="2">Employees' Share</th>
              <th colspan="2">Employer's share</th>
              <th rowspan="2">Refund of<br>advance</th>
              <th rowspan="2">No.of days /<br>period of non-<br>contributing<br>service if any</th>
              <th rowspan="2">Remarks</th>
            </tr>
            <tr>
              <th>Amount of<br>Wages</th>
              <th>EPF</th>
              <th>EPF&amp;8-1/3%<br>if any</th>
              <th>Pension fund<br>contri 8-1/3%</th>
            </tr>
            <tr class="col-num-row">
              <th>1</th><th>2</th><th>3</th><th>4(A)</th><th>4(B)</th><th>5</th><th>6</th><th>7</th>
            </tr>
          </thead>
          <tbody>
            ${bodyRows}
            <tr class="total-row">
              <td>TOTAL</td>
              <td class="num">${formatAmount(totals.wages)}</td>
              <td class="num">${formatAmount(totals.epf)}</td>
              <td class="num">${formatAmount(totals.epf833)}</td>
              <td class="num">${formatAmount(totals.pension)}</td>
              <td class="center">-</td>
              <td class="num">${formatAmount(totals.days)}</td>
              <td></td>
            </tr>
          </tbody>
        </table>

        <div class="cert-box">
          <div class="cert-left">
            Certified that the total amount of contribution (both shares) indicated in this card i.e.,<br>
            has already been remitted in full in EPF A/C No.1 and Pension Fund A/C No.10
          </div>
          <div class="cert-amount">
            <strong>RS.</strong>
            <strong>${formatAmount(totals.epf + totals.epf833)}</strong><br>
            <span class="pension-line">${formatAmount(totals.pension)}</span>
            <span>(vide below)</span>
          </div>
        </div>

        <div class="rounding-note">
          Certified that the difference between the total of the contributions shown under columns(3) and 4(a) &amp; 4(b) of the above<br>
          table and that arrived at on the total wages shown in Col(2) at the prescribed rate is solely due to rounding off of<br>
          contribution to the nearest rupee under the rules.
        </div>

        <div class="signature-row">
          <div></div>
          <strong>${companyName ? `For ${escapeHtml(companyName)},` : "For"}</strong>
        </div>

        <div class="dated-row">
          <div>Dated</div>
          <strong>${escapeHtml(details.date || "")}</strong>
          <strong>Authorised Signatory</strong>
        </div>

        <div class="note-text">
          Note:- In respect of Form 3(A) sent to the Regional Office during the Course of the Currency period for the purpose of<br>
          final settlement of the accounts of the member who had left service details of date and reason for leaving service.<br>
          Should be furnished under column7(A) &amp; (B)<br>
          In respect of those who are not members of the Pension Fund the employers share of contribution to the EPF<br>
          will be&nbsp;&nbsp; 8-1/3 or 10 % as the case may be and is to be shown under Column 4(b).
        </div>
      </section>
    </div>
  `;
}


function getCurrencyPeriodText(details, monthlyRows) {
  function yearsFromMonthlyRows(rows) {
    if (!Array.isArray(rows)) return null;

    const years = rows
      .map(row => String(row.month || "").match(/(?:Jan|January|Feb|February|Mar|March|Apr|April|May|Jun|June|Jul|July|Aug|August|Sep|September|Oct|October|Nov|November|Dec|December)[a-z]*[-\s]*(20\d{2})/i))
      .filter(Boolean)
      .map(match => Number(match[1]))
      .filter(year => Number.isFinite(year));

    if (!years.length) return null;

    const start = Math.min(...years);
    return { startYear: String(start), endYear: String(start + 1) };
  }

  let startYear = String(details.financial_year_start || "").trim();
  let endYear = String(details.financial_year_end || "").trim();

  if ((!startYear || !endYear) && details.financial_year) {
    const fyMatch = String(details.financial_year).match(/(20\d{2})\s*[-–—/]\s*(20\d{2})/);
    if (fyMatch) {
      startYear = fyMatch[1];
      endYear = fyMatch[2];
    }
  }

  // If the backend ever falls back to the old sample period, override it
  // with the actual years visible in the uploaded PDF month rows.
  const rowYears = yearsFromMonthlyRows(monthlyRows);
  if (rowYears) {
    // The visible rows come from the selected PDF, so use them to keep the
    // preview period synchronized when switching between uploaded PDFs.
    startYear = rowYears.startYear;
    endYear = rowYears.endYear;
  }

  if (!startYear || !endYear) {
    startYear = "2025";
    endYear = "2026";
  }

  return `Contribution Card for the Currency Period from 1st April ${startYear} to 31st March ${endYear}`;
}

function cleanPreviewName(value) {
  let text = String(value || "").replace(/[^A-Za-z.\s]/g, " ").replace(/\s+/g, " ").trim();
  text = text.replace(/\b(TUE|FRFFK|LFKKIUK|IKKCQD|VKBZMH)\b/gi, "").replace(/\s+/g, " ").trim();
  const words = text.split(" ").filter(Boolean);
  if (words.length > 4) {
    return words.slice(0, 4).join(" ").toUpperCase();
  }
  return text.toUpperCase();
}

function toNumber(value) {
  const number = Number(value || 0);
  return Number.isFinite(number) ? number : 0;
}

function formatAmount(value) {
  return toNumber(value).toFixed(2);
}

function shortFileName(name, maxLength = 38) {
  const text = String(name || "").trim();

  if (text.length <= maxLength) {
    return text;
  }

  const dotIndex = text.lastIndexOf(".");
  const extension = dotIndex > -1 ? text.slice(dotIndex) : "";
  const base = extension ? text.slice(0, dotIndex) : text;
  const keep = Math.max(8, maxLength - extension.length - 3);
  const front = Math.ceil(keep * 0.62);
  const back = keep - front;

  return `${base.slice(0, front)}...${base.slice(Math.max(0, base.length - back))}${extension}`;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function setStatus(message, type) {
  statusBox.textContent = message;
  statusBox.className = "status";

  if (type) {
    statusBox.classList.add(type);
  }
}
