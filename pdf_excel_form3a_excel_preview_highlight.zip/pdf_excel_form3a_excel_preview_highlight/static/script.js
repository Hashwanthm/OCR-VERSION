const pdfInput = document.getElementById("pdfInput");
const convertBtn = document.getElementById("convertBtn");
const pdfArea = document.getElementById("pdfArea");
const excelArea = document.getElementById("excelArea");
const fileName = document.getElementById("fileName");
const statusBox = document.getElementById("status");
const downloadBtn = document.getElementById("downloadBtn");

pdfInput.addEventListener("change", function () {
  const file = pdfInput.files[0];

  downloadBtn.style.display = "none";
  downloadBtn.href = "#";

  excelArea.innerHTML = `
    <div class="empty">
      Click Convert to paste first page data into Form 3A view.
    </div>
  `;

  if (!file) {
    fileName.textContent = "No file selected";

    pdfArea.innerHTML = `
      <div class="empty">
        Upload a PDF file to preview it here.
      </div>
    `;

    setStatus("Ready", "");
    return;
  }

  fileName.textContent = file.name;

  const pdfUrl = URL.createObjectURL(file);

  pdfArea.innerHTML = `
    <iframe
      class="pdf-preview"
      src="${pdfUrl}#page=1&toolbar=1&navpanes=0&view=FitH"
      title="First page PDF preview">
    </iframe>
  `;

  setStatus("PDF loaded. Only the first page will be converted.", "");
});

convertBtn.addEventListener("click", async function () {
  const file = pdfInput.files[0];

  if (!file) {
    setStatus("Please select a PDF file first.", "error");
    return;
  }

  const formData = new FormData();
  formData.append("pdf", file);

  convertBtn.disabled = true;
  convertBtn.textContent = "Converting...";
  downloadBtn.style.display = "none";

  setStatus("Reading first page and preparing Form 3A...", "");

  try {
    const response = await fetch("/convert", {
      method: "POST",
      body: formData
    });

    const result = await response.json();

    if (!response.ok) {
      throw new Error(result.error || "Conversion failed");
    }

    renderForm3APreview(result.details || {}, result.monthly_rows || []);

    downloadBtn.href = result.download_url;
    downloadBtn.style.display = "inline-block";

    setStatus("First page data pasted into Form 3A Excel preview. Account No and UAN are highlighted. Click Download Excel.", "success");

  } catch (error) {
    excelArea.innerHTML = `
      <div class="empty">
        Conversion failed.
      </div>
    `;

    setStatus(error.message, "error");

  } finally {
    convertBtn.disabled = false;
    convertBtn.textContent = "Convert";
  }
});

function renderForm3APreview(details, monthlyRows) {
  const rows = [...monthlyRows];

  while (rows.length < 12) {
    rows.push({
      month: "",
      wages: 0,
      epf: 0,
      epf_833: 0,
      pension: 0,
      refund: 0,
      non_contribution_days: 0,
      remarks: ""
    });
  }

  const totals = rows.reduce((acc, row) => {
    acc.wages += toNumber(row.wages);
    acc.epf += toNumber(row.epf);
    acc.epf833 += toNumber(row.epf_833);
    acc.pension += toNumber(row.pension);
    acc.days += toNumber(row.non_contribution_days);
    return acc;
  }, { wages: 0, epf: 0, epf833: 0, pension: 0, days: 0 });

  const companyName = details.company_name || "TRICORE SOLUTIONS PRIVATE LIMITED";
  const name = cleanPreviewName(details.name || "");

  const bodyRows = rows.map((row, index) => {
    const remark = index === 0
      ? `a) Date of<br>leaving`
      : index === 6
        ? `b) Reasons<br>for leaving`
        : "";

    return `
      <tr>
        <td class="month-cell">${escapeHtml(row.month || "")}</td>
        <td class="num">${formatAmount(row.wages)}</td>
        <td class="num">${formatAmount(row.epf)}</td>
        <td class="num">${formatAmount(row.epf_833)}</td>
        <td class="num">${formatAmount(row.pension)}</td>
        <td class="center">-</td>
        <td class="num">${formatAmount(row.non_contribution_days)}</td>
        <td class="remarks-cell">${remark}</td>
      </tr>
    `;
  }).join("");

  excelArea.innerHTML = `
    <div class="form-preview-wrap">
      <section class="form3a-sheet">
        <div class="form3a-topline">
          <strong>Form No.3A (Revised)</strong>
          <span>( See Paragraphs 35 &amp; 42 of the Employees Provident Funds Scheme , 1952)</span>
        </div>
        <div class="form3a-title">(See Paragraph 19 of the Employees Pension Scheme , 1995)</div>
        <div class="form3a-title bold">(FOR UNEXEMPTED ESTABLISHMENTS ONLY)</div>
        <div class="form3a-title bold period-title">Contribution Card for the Currency Period from 1st April 2025 to 31st March 2026</div>

        <div class="details-layout">
          <div class="left-details">
            <div class="detail-row"><div>1 Account No.</div><div class="highlight-value">${escapeHtml(details.account_no || "")}</div></div>
            <div class="detail-row"><div>&nbsp;&nbsp;&nbsp;UAN</div><div class="highlight-value">${escapeHtml(details.uan || "")}</div></div>
            <div class="detail-row name-row"><div>2 Name / Surname<br><span>(in Block Capitals)</span></div><div class="strong-name">${escapeHtml(name)}</div></div>
            <div class="detail-row father-row"><div>3 Father's/Husband's<br><span>Name</span></div><div>${escapeHtml(details.father_name || "")}</div></div>
            <div class="detail-row address-row"><div>4 Name &amp; Address<br><span>of the Factory/</span></div><div>${escapeHtml(details.factory_address || companyName)}</div></div>
            <div class="detail-row"><div>&nbsp;&nbsp;&nbsp;Establishment ID</div><div>${escapeHtml(details.establishment_id || "")}</div></div>
          </div>

          <div class="right-details">
            <div class="right-detail-line"><span>5 Statutory rate of Contribution</span><strong>${escapeHtml(details.statutory_rate || "12%")}</strong></div>
            <div class="right-detail-line tall"><span>6 Voluntary higher rate of employee's<br>&nbsp;&nbsp;&nbsp;contribution if any</span><strong>NO</strong></div>
            <div class="right-detail-line tall"><span>7 Employer contribution on Hr. wages to<br>&nbsp;&nbsp;&nbsp;EPF (ER) Y/N</span><strong>NO</strong></div>
            <div class="right-detail-line"><span>8 Voluntary contribution to Pension Y/N</span><strong>NO</strong></div>
          </div>
        </div>

        <table class="form3a-table">
          <thead>
            <tr>
              <th rowspan="2">Months</th>
              <th colspan="2">Employees' Share</th>
              <th colspan="2">Employer's share</th>
              <th rowspan="2">Refund of<br>advance</th>
              <th rowspan="2">No.of days /<br>period of non-<br>contributing<br>service if any</th>
              <th rowspan="2">Remarks</th>
            </tr>
            <tr>
              <th>Amount of<br>Wages</th>
              <th>EPF</th>
              <th>EPF&amp;8-1/3%<br>if any</th>
              <th>Pension fund<br>contri 8-1/3%</th>
            </tr>
            <tr class="col-num-row">
              <th>1</th><th>2</th><th>3</th><th>4(A)</th><th>4(B)</th><th>5</th><th>6</th><th>7</th>
            </tr>
          </thead>
          <tbody>
            ${bodyRows}
            <tr class="total-row">
              <td>TOTAL</td>
              <td class="num">${formatAmount(totals.wages)}</td>
              <td class="num">${formatAmount(totals.epf)}</td>
              <td class="num">${formatAmount(totals.epf833)}</td>
              <td class="num">${formatAmount(totals.pension)}</td>
              <td class="center">-</td>
              <td class="num">${formatAmount(totals.days)}</td>
              <td></td>
            </tr>
          </tbody>
        </table>

        <div class="cert-box">
          <div class="cert-left">
            Certified that the total amount of contribution (both shares) indicated in this card i.e.,<br>
            has already been remitted in full in EPF A/C No.1 and Pension Fund A/C No.10
          </div>
          <div class="cert-amount">
            <strong>RS.</strong>
            <strong>${formatAmount(totals.epf + totals.epf833)}</strong><br>
            <span class="pension-line">${formatAmount(totals.pension)}</span>
            <span>(vide below)</span>
          </div>
        </div>

        <div class="rounding-note">
          Certified that the difference between the total of the contributions shown under columns(3) and 4(a) &amp; 4(b) of the above<br>
          table and that arrived at on the total wages shown in Col(2) at the prescribed rate is solely due to rounding off of<br>
          contribution to the nearest rupee under the rules.
        </div>

        <div class="signature-row">
          <div></div>
          <strong>For ${escapeHtml(companyName)},</strong>
        </div>

        <div class="dated-row">
          <div>Dated</div>
          <strong>${escapeHtml(details.date || "")}</strong>
          <strong>Authorised Signatory</strong>
        </div>

        <div class="note-text">
          Note:- In respect of Form 3(A) sent to the Regional Office during the Course of the Currency period for the purpose of<br>
          final settlement of the accounts of the member who had left service details of date and reason for leaving service.<br>
          Should be furnished under column7(A) &amp; (B)<br>
          In respect of those who are not members of the Pension Fund the employers share of contribution to the EPF<br>
          will be&nbsp;&nbsp; 8-1/3 or 10 % as the case may be and is to be shown under Column 4(b).
        </div>
      </section>
    </div>
  `;
}

function cleanPreviewName(value) {
  let text = String(value || "").replace(/[^A-Za-z.\s]/g, " ").replace(/\s+/g, " ").trim();
  text = text.replace(/\b(TUE|FRFFK|LFKKIUK|IKKCQD|VKBZMH)\b/gi, "").replace(/\s+/g, " ").trim();
  const words = text.split(" ").filter(Boolean);
  if (words.length > 4) {
    return words.slice(0, 4).join(" ").toUpperCase();
  }
  return text.toUpperCase();
}

function toNumber(value) {
  const number = Number(value || 0);
  return Number.isFinite(number) ? number : 0;
}

function formatAmount(value) {
  return toNumber(value).toFixed(2);
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function setStatus(message, type) {
  statusBox.textContent = message;
  statusBox.className = "status";

  if (type) {
    statusBox.classList.add(type);
  }
}
