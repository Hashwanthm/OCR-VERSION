# Form 11 Fast AI OCR Project

This is the lightweight version using only the needed libraries for speed.

## What this project does

- Left side: PDF/image preview
- Right side: editable extracted fields
- Uses PaddleOCR for handwritten/scanned Form 11
- Uses OpenCV preprocessing for better OCR
- Converts all text values to CAPITAL LETTERS
- Generates Excel after user review
- Supports up to 10 files

## Libraries kept

Backend only uses:

- FastAPI
- Uvicorn
- python-multipart
- PyMuPDF
- OpenCV
- Pillow
- NumPy
- OpenPyXL
- RapidFuzz
- PaddleOCR
- PaddlePaddle

Heavy libraries removed:

- Torch
- Transformers
- Sentence Transformers
- Unstructured
- EasyOCR
- pdfplumber
- pandas

## Run backend

```cmd
cd backend
python -m venv venv
venv\Scripts\activate
install_ai_cpu.bat
python app.py
```

Backend runs on:

```text
http://127.0.0.1:8000
```

## Run frontend

Open another terminal:

```cmd
cd frontend
npm install
npm run dev
```

Frontend runs on:

```text
http://localhost:5173
```

## Important

Handwritten OCR is not 100% accurate. This project shows editable fields before Excel download, so the user can correct values before generating Excel.
