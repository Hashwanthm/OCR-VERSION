import React, { useMemo, useState } from "react";
import { Download, FileText, Loader2, Upload } from "lucide-react";

const API_BASE = "http://127.0.0.1:8000";

const FIELD_DEFS = [
  ["member_name", "Name of Member"],
  ["father_spouse_name", "Father / Spouse Name"],
  ["dob", "Date of Birth"],
  ["gender", "Gender"],
  ["marital_status", "Marital Status"],
  ["email_id", "Email ID"],
  ["mobile_no", "Mobile No"],
  ["date_of_joining", "Date of Joining"],
  ["bank_account_no", "Bank Account No"],
  ["ifsc_code", "IFSC Code"],
  ["aadhaar_no", "Aadhaar No"],
  ["pan_no", "PAN No"],
  ["previous_pf_no", "Previous PF No"],
  ["previous_uan", "Previous UAN"],
  ["passport_no", "Passport No"],
  ["passport_valid_from", "Passport Valid From"],
  ["passport_valid_to", "Passport Valid To"],
  ["country_of_origin", "Country of Origin"],
  ["nationality", "Nationality"],
];

function normalizeRecord(record) {
  const fields = {};
  FIELD_DEFS.forEach(([key]) => {
    fields[key] = (record?.fields?.[key] || "").toUpperCase();
  });
  return {
    file_name: record.file_name,
    fields,
    raw_ocr_text: record.raw_ocr_text || "",
    ocr_confidence: record.ocr_confidence || 0,
  };
}

function App() {
  const [files, setFiles] = useState([]);
  const [records, setRecords] = useState([]);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  const selectedFile = files[selectedIndex];
  const selectedRecord = records[selectedIndex];

  const previewUrl = useMemo(() => {
    if (!selectedFile) return "";
    return URL.createObjectURL(selectedFile);
  }, [selectedFile]);

  function handleFiles(event) {
    const selected = Array.from(event.target.files || []);
    if (selected.length > 10) {
      setMessage("Maximum 10 files allowed.");
      return;
    }
    setFiles(selected);
    setRecords([]);
    setSelectedIndex(0);
    setMessage(`${selected.length} file(s) selected.`);
  }

  async function extractData() {
    if (files.length === 0) {
      setMessage("Select PDF/image files first.");
      return;
    }
    setLoading(true);
    setMessage("Running AI OCR. Please wait...");
    const formData = new FormData();
    files.forEach((file) => formData.append("files", file));

    try {
      const response = await fetch(`${API_BASE}/api/extract`, {
        method: "POST",
        body: formData,
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.detail || "Extraction failed");
      const normalized = (data.records || []).map(normalizeRecord);
      setRecords(normalized);
      setSelectedIndex(0);
      setMessage(`Extracted ${normalized.length} file(s). Review and correct fields before Excel download.`);
    } catch (error) {
      setMessage(error.message);
    } finally {
      setLoading(false);
    }
  }

  function updateField(key, value) {
    setRecords((prev) => {
      const copy = structuredClone(prev);
      copy[selectedIndex].fields[key] = value.toUpperCase();
      return copy;
    });
  }

  async function downloadExcel() {
    if (records.length === 0) {
      setMessage("Extract data first.");
      return;
    }
    setMessage("Creating Excel...");
    try {
      const response = await fetch(`${API_BASE}/api/download-excel`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ records }),
      });
      if (!response.ok) {
        const data = await response.json().catch(() => ({}));
        throw new Error(data.detail || "Excel download failed");
      }
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "form11_extracted_data.xlsx";
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      setMessage("Excel downloaded.");
    } catch (error) {
      setMessage(error.message);
    }
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <div>
          <h1>FORM 11 AI OCR</h1>
          <p>Fast version using only needed libraries: PaddleOCR + OpenCV + PyMuPDF + OpenPyXL</p>
        </div>
        <div className="actions">
          <label className="upload-btn">
            <Upload size={16} />
            Upload PDF/Image
            <input type="file" multiple accept=".pdf,.png,.jpg,.jpeg,.webp,.bmp" onChange={handleFiles} />
          </label>
          <button className="primary" onClick={extractData} disabled={loading || files.length === 0}>
            {loading ? <Loader2 className="spin" size={16} /> : <FileText size={16} />}
            Extract
          </button>
          <button className="success" onClick={downloadExcel} disabled={records.length === 0}>
            <Download size={16} />
            Download Excel
          </button>
        </div>
      </header>

      <div className="status-row">
        <span>{files.length} / 10 files selected</span>
        <span>{message}</span>
      </div>

      <main className="main-grid">
        <section className="panel preview-panel">
          <div className="panel-head">
            <h2>PDF / Image Preview</h2>
            {files.length > 0 && (
              <select value={selectedIndex} onChange={(e) => setSelectedIndex(Number(e.target.value))}>
                {files.map((file, index) => (
                  <option key={file.name + index} value={index}>{`File ${index + 1}: ${file.name}`}</option>
                ))}
              </select>
            )}
          </div>
          <div className="preview-box">
            {!selectedFile && <p className="empty">Upload handwritten/scanned Form 11 PDF or image.</p>}
            {selectedFile && selectedFile.type.startsWith("image/") && <img src={previewUrl} alt="preview" />}
            {selectedFile && !selectedFile.type.startsWith("image/") && <iframe src={previewUrl} title="PDF preview" />}
          </div>
        </section>

        <section className="panel fields-panel">
          <div className="panel-head">
            <h2>Editable Extracted Fields</h2>
            {selectedRecord && <span className="confidence">OCR confidence: {Math.round((selectedRecord.ocr_confidence || 0) * 100)}%</span>}
          </div>

          {!selectedRecord && (
            <div className="empty right-empty">
              <p>After extraction, fields will appear here.</p>
              <p>Correct OCR mistakes before downloading Excel.</p>
            </div>
          )}

          {selectedRecord && (
            <div className="fields-scroll">
              <div className="field-grid">
                {FIELD_DEFS.map(([key, label]) => (
                  <label className="field" key={key}>
                    <span>{label}</span>
                    <input
                      value={selectedRecord.fields[key] || ""}
                      onChange={(e) => updateField(key, e.target.value)}
                      placeholder={`Enter ${label}`}
                    />
                  </label>
                ))}
              </div>
              <label className="field raw-field">
                <span>Raw OCR Text</span>
                <textarea
                  value={selectedRecord.raw_ocr_text || ""}
                  onChange={(e) => {
                    setRecords((prev) => {
                      const copy = structuredClone(prev);
                      copy[selectedIndex].raw_ocr_text = e.target.value.toUpperCase();
                      return copy;
                    });
                  }}
                />
              </label>
            </div>
          )}
        </section>
      </main>
    </div>
  );
}

export default App;
