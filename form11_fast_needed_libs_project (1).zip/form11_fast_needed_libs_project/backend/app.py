from typing import List

import uvicorn
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response
from pydantic import BaseModel

from excel_service import create_excel
from ocr_service import FORM11_FIELDS, extract_form11

app = FastAPI(title="Form 11 Fast AI OCR API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class Form11Record(BaseModel):
    file_name: str
    fields: dict
    raw_ocr_text: str | None = ""
    ocr_confidence: float | None = 0.0


class ExcelRequest(BaseModel):
    records: List[Form11Record]


@app.get("/api/health")
def health():
    return {"status": "ok", "message": "Form 11 Fast AI OCR API running"}


@app.get("/api/fields")
def fields():
    return {"fields": [{"key": key, "label": label} for key, label in FORM11_FIELDS]}


@app.post("/api/extract")
async def extract(files: List[UploadFile] = File(...)):
    if not files:
        raise HTTPException(status_code=400, detail="Upload at least one file")
    if len(files) > 10:
        raise HTTPException(status_code=400, detail="Maximum 10 files allowed")

    results = []
    for file in files:
        name = file.filename or "uploaded_file"
        if not name.lower().endswith((".pdf", ".png", ".jpg", ".jpeg", ".webp", ".bmp")):
            raise HTTPException(status_code=400, detail=f"Unsupported file type: {name}")
        content = await file.read()
        if not content:
            raise HTTPException(status_code=400, detail=f"Empty file: {name}")
        try:
            results.append(extract_form11(name, content))
        except RuntimeError as exc:
            raise HTTPException(status_code=500, detail=str(exc)) from exc
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Failed to process {name}: {exc}") from exc
    return {"records": results}


@app.post("/api/download-excel")
def download_excel(payload: ExcelRequest):
    if not payload.records:
        raise HTTPException(status_code=400, detail="No records to export")
    records = [record.model_dump() for record in payload.records]
    content = create_excel(records)
    return Response(
        content=content,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": 'attachment; filename="form11_extracted_data.xlsx"'},
    )


if __name__ == "__main__":
    uvicorn.run("app:app", host="127.0.0.1", port=8000, reload=True)
