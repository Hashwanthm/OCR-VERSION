@echo off
setlocal

echo ==============================================
echo Installing lightweight Form 11 OCR dependencies
echo ==============================================

python -m pip install --upgrade pip setuptools wheel

echo Installing PaddlePaddle CPU...
python -m pip install paddlepaddle==2.6.2 -i https://www.paddlepaddle.org.cn/packages/stable/cpu/

echo Installing backend requirements...
pip install -r requirements.txt

echo.
echo Done. Now run: python app.py
pause
