from io import BytesIO
from typing import Dict, List

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

FIELD_LABELS = [
    ("member_name", "NAME OF MEMBER"),
    ("father_spouse_name", "FATHER / SPOUSE NAME"),
    ("dob", "DATE OF BIRTH"),
    ("gender", "GENDER"),
    ("marital_status", "MARITAL STATUS"),
    ("email_id", "EMAIL ID"),
    ("mobile_no", "MOBILE NO"),
    ("date_of_joining", "DATE OF JOINING"),
    ("bank_account_no", "BANK ACCOUNT NO"),
    ("ifsc_code", "IFSC CODE"),
    ("aadhaar_no", "AADHAAR NO"),
    ("pan_no", "PAN NO"),
    ("previous_pf_no", "PREVIOUS PF NO"),
    ("previous_uan", "PREVIOUS UAN"),
    ("passport_no", "PASSPORT NO"),
    ("passport_valid_from", "PASSPORT VALID FROM"),
    ("passport_valid_to", "PASSPORT VALID TO"),
    ("country_of_origin", "COUNTRY OF ORIGIN"),
    ("nationality", "NATIONALITY"),
]


def upper(value):
    return str(value or "").strip().upper()


def create_excel(records: List[Dict]) -> bytes:
    wb = Workbook()
    ws = wb.active
    ws.title = "FORM11 DATA"
    ws.sheet_view.showGridLines = False

    thin = Side(style="thin", color="111827")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    header_fill = PatternFill("solid", fgColor="D9EAF7")
    title_fill = PatternFill("solid", fgColor="1F4E78")

    ws.merge_cells("A1:D1")
    ws["A1"] = "FORM 11 EXTRACTED DATA"
    ws["A1"].font = Font(bold=True, color="FFFFFF", size=14)
    ws["A1"].fill = title_fill
    ws["A1"].alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 24

    ws.append(["FILE NAME", "FIELD", "VALUE", "REMARKS"])
    for cell in ws[2]:
        cell.font = Font(bold=True)
        cell.fill = header_fill
        cell.border = border
        cell.alignment = Alignment(horizontal="center", vertical="center")

    row = 3
    for record in records:
        file_name = upper(record.get("file_name"))
        fields = record.get("fields", {}) or {}
        start_row = row
        for key, label in FIELD_LABELS:
            ws.cell(row=row, column=1, value=file_name)
            ws.cell(row=row, column=2, value=label)
            ws.cell(row=row, column=3, value=upper(fields.get(key, "")))
            ws.cell(row=row, column=4, value="REVIEWED")
            for col in range(1, 5):
                c = ws.cell(row=row, column=col)
                c.border = border
                c.alignment = Alignment(vertical="center", wrap_text=True)
                if col in (1, 2):
                    c.font = Font(bold=True)
            row += 1
        if row - start_row > 1:
            ws.merge_cells(start_row=start_row, start_column=1, end_row=row - 1, end_column=1)
            ws.cell(start_row, 1).alignment = Alignment(vertical="center", horizontal="center", wrap_text=True)

    widths = {"A": 28, "B": 28, "C": 42, "D": 18}
    for col, width in widths.items():
        ws.column_dimensions[col].width = width

    ws.freeze_panes = "A3"
    ws.page_setup.paperSize = ws.PAPERSIZE_A4
    ws.page_setup.orientation = ws.ORIENTATION_LANDSCAPE
    ws.page_margins.left = 0.25
    ws.page_margins.right = 0.25
    ws.page_margins.top = 0.35
    ws.page_margins.bottom = 0.35
    ws.sheet_view.zoomScale = 100

    bio = BytesIO()
    wb.save(bio)
    return bio.getvalue()
