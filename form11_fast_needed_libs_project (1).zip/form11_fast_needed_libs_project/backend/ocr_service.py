import io
import re
import tempfile
from pathlib import Path
from typing import Dict, List, Tuple

import cv2
import fitz  # PyMuPDF
import numpy as np
from PIL import Image
from rapidfuzz import fuzz

OCR_ENGINE = None

FORM11_FIELDS = [
    ("member_name", "Name of Member"),
    ("father_spouse_name", "Father / Spouse Name"),
    ("dob", "Date of Birth"),
    ("gender", "Gender"),
    ("marital_status", "Marital Status"),
    ("email_id", "Email ID"),
    ("mobile_no", "Mobile No"),
    ("date_of_joining", "Date of Joining"),
    ("bank_account_no", "Bank Account No"),
    ("ifsc_code", "IFSC Code"),
    ("aadhaar_no", "Aadhaar No"),
    ("pan_no", "PAN No"),
    ("previous_pf_no", "Previous PF No"),
    ("previous_uan", "Previous UAN"),
    ("passport_no", "Passport No"),
    ("passport_valid_from", "Passport Valid From"),
    ("passport_valid_to", "Passport Valid To"),
    ("country_of_origin", "Country of Origin"),
    ("nationality", "Nationality"),
]

LABELS = {
    "member_name": ["name of the member", "name of member", "member name", "name"],
    "father_spouse_name": ["father", "spouse", "father's name", "husband", "father spouse"],
    "dob": ["date of birth", "dob", "birth"],
    "gender": ["gender", "male", "female"],
    "marital_status": ["marital", "married", "unmarried"],
    "email_id": ["email", "e-mail"],
    "mobile_no": ["mobile", "mobile number", "phone"],
    "date_of_joining": ["date of joining", "joining", "doj"],
    "bank_account_no": ["bank account", "account no", "bank a/c", "savings bank"],
    "ifsc_code": ["ifsc"],
    "aadhaar_no": ["aadhaar", "aadhar", "aadhaar number", "aadhar number"],
    "pan_no": ["pan", "pan number"],
    "previous_pf_no": ["previous pf", "pf account", "member id"],
    "previous_uan": ["previous uan", "uan"],
    "passport_no": ["passport no", "passport number"],
    "passport_valid_from": ["valid from"],
    "passport_valid_to": ["valid to"],
    "country_of_origin": ["country of origin", "origin"],
    "nationality": ["nationality"],
}


def get_ocr_engine():
    global OCR_ENGINE
    if OCR_ENGINE is None:
        try:
            from paddleocr import PaddleOCR
        except Exception as exc:
            raise RuntimeError(
                "PaddleOCR is not installed. Run backend\\install_ai_cpu.bat first."
            ) from exc
        OCR_ENGINE = PaddleOCR(lang="en", use_angle_cls=False, show_log=False)
    return OCR_ENGINE


def pdf_first_page_to_image(file_bytes: bytes, zoom: float = 1.6) -> np.ndarray:
    doc = fitz.open(stream=file_bytes, filetype="pdf")
    if doc.page_count == 0:
        raise ValueError("PDF has no pages")
    page = doc.load_page(0)
    mat = fitz.Matrix(zoom, zoom)
    pix = page.get_pixmap(matrix=mat, alpha=False)
    img = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width, pix.n)
    if pix.n == 4:
        img = cv2.cvtColor(img, cv2.COLOR_RGBA2RGB)
    return img


def image_bytes_to_array(file_bytes: bytes) -> np.ndarray:
    image = Image.open(io.BytesIO(file_bytes)).convert("RGB")
    return np.array(image)


def load_upload_as_image(filename: str, file_bytes: bytes) -> np.ndarray:
    name = filename.lower()
    if name.endswith(".pdf"):
        return pdf_first_page_to_image(file_bytes)
    return image_bytes_to_array(file_bytes)


def preprocess_for_ocr(img_rgb: np.ndarray) -> np.ndarray:
    # Keep preprocessing light for speed.
    img = cv2.cvtColor(img_rgb, cv2.COLOR_RGB2BGR)

    # Resize very large images to speed up OCR while keeping readability.
    h, w = img.shape[:2]
    max_width = 1700
    if w > max_width:
        scale = max_width / w
        img = cv2.resize(img, (max_width, int(h * scale)), interpolation=cv2.INTER_AREA)

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = cv2.bilateralFilter(gray, 5, 50, 50)
    gray = cv2.convertScaleAbs(gray, alpha=1.18, beta=8)

    # Return 3-channel image because PaddleOCR handles color images well.
    return cv2.cvtColor(gray, cv2.COLOR_GRAY2RGB)


def run_paddle_ocr(img_rgb: np.ndarray) -> Tuple[List[Dict], str, float]:
    engine = get_ocr_engine()
    # PaddleOCR accepts ndarray. cls=False is faster.
    result = engine.ocr(img_rgb, cls=False)

    lines: List[Dict] = []
    confidences: List[float] = []

    for page in result or []:
        for item in page or []:
            try:
                box = item[0]
                text = str(item[1][0]).strip()
                conf = float(item[1][1])
            except Exception:
                continue
            if text:
                lines.append({"text": text, "confidence": round(conf, 3), "box": box})
                confidences.append(conf)

    raw_text = "\n".join(line["text"] for line in lines)
    avg_conf = round(sum(confidences) / len(confidences), 3) if confidences else 0.0
    return lines, raw_text, avg_conf


def clean_value(value: str) -> str:
    value = re.sub(r"\s+", " ", value or "").strip()
    value = value.replace("|", "").replace("__", "_")
    return value.upper()


def normalize_text(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", (value or "").lower()).strip()


def value_after_label(line: str, label_words: List[str]) -> str:
    lower = line.lower()
    for label in label_words:
        idx = lower.find(label.lower())
        if idx >= 0:
            rest = line[idx + len(label):]
            rest = re.sub(r"^[\s:;\-_/()]+", "", rest)
            return rest.strip()
    if ":" in line:
        return line.split(":", 1)[1].strip()
    return ""


def extract_by_regex(raw: str) -> Dict[str, str]:
    text = raw.upper()
    fields: Dict[str, str] = {}

    mobile = re.search(r"\b[6-9]\d{9}\b", text)
    if mobile:
        fields["mobile_no"] = mobile.group(0)

    aadhaar = re.search(r"\b\d{4}\s?\d{4}\s?\d{4}\b", text)
    if aadhaar:
        fields["aadhaar_no"] = re.sub(r"\s+", "", aadhaar.group(0))

    pan = re.search(r"\b[A-Z]{5}\d{4}[A-Z]\b", text)
    if pan:
        fields["pan_no"] = pan.group(0)

    ifsc = re.search(r"\b[A-Z]{4}0[A-Z0-9]{6}\b", text)
    if ifsc:
        fields["ifsc_code"] = ifsc.group(0)

    uan = re.search(r"\b\d{12}\b", text)
    if uan and "aadhaar_no" not in fields:
        fields["previous_uan"] = uan.group(0)

    email = re.search(r"[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}", text)
    if email:
        fields["email_id"] = email.group(0)

    # Common date formats
    dates = re.findall(r"\b\d{1,2}[\-/\. ]\d{1,2}[\-/\. ]\d{2,4}\b", text)
    if dates:
        fields.setdefault("dob", dates[0])
    if len(dates) > 1:
        fields.setdefault("date_of_joining", dates[1])

    if "MALE" in text:
        fields.setdefault("gender", "MALE")
    if "FEMALE" in text:
        fields.setdefault("gender", "FEMALE")
    if "UNMARRIED" in text:
        fields.setdefault("marital_status", "UNMARRIED")
    elif "MARRIED" in text:
        fields.setdefault("marital_status", "MARRIED")

    return fields


def extract_fields_from_ocr(lines: List[Dict], raw_text: str) -> Dict[str, str]:
    fields = {key: "" for key, _ in FORM11_FIELDS}
    fields.update(extract_by_regex(raw_text))

    texts = [line["text"] for line in lines]
    normalized = [normalize_text(t) for t in texts]

    for key, label_words in LABELS.items():
        if fields.get(key):
            continue

        best_index = -1
        best_score = 0
        best_label = ""
        for i, line_norm in enumerate(normalized):
            for label in label_words:
                score = fuzz.partial_ratio(normalize_text(label), line_norm)
                if score > best_score:
                    best_index = i
                    best_score = score
                    best_label = label

        if best_index >= 0 and best_score >= 78:
            same_line = value_after_label(texts[best_index], [best_label])
            if same_line and len(same_line) > 1:
                fields[key] = clean_value(same_line)
            elif best_index + 1 < len(texts):
                next_line = texts[best_index + 1]
                # Avoid using next label as value.
                if len(next_line) > 1 and not any(fuzz.partial_ratio(normalize_text(x), normalize_text(next_line)) > 85 for labels in LABELS.values() for x in labels):
                    fields[key] = clean_value(next_line)

    return {k: clean_value(v) for k, v in fields.items()}


def extract_form11(filename: str, file_bytes: bytes) -> Dict:
    img = load_upload_as_image(filename, file_bytes)
    prepared = preprocess_for_ocr(img)
    lines, raw_text, avg_confidence = run_paddle_ocr(prepared)
    fields = extract_fields_from_ocr(lines, raw_text)

    return {
        "file_name": filename,
        "fields": fields,
        "raw_ocr_text": clean_value(raw_text),
        "ocr_confidence": avg_confidence,
        "line_count": len(lines),
    }
