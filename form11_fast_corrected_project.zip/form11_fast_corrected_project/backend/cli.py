from __future__ import annotations

import argparse
from pathlib import Path

from excel_service import create_excel
from ocr_service import extract_form11


def main():
    parser = argparse.ArgumentParser(description="Fast Form 11 AI OCR CLI")
    parser.add_argument("input", help="PDF/image file or folder")
    parser.add_argument("--output", "-o", default="outputs", help="Output folder")
    args = parser.parse_args()

    input_path = Path(args.input)
    out_dir = Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)

    files = []
    if input_path.is_dir():
        for ext in ("*.pdf", "*.png", "*.jpg", "*.jpeg", "*.webp", "*.bmp"):
            files.extend(input_path.glob(ext))
    else:
        files = [input_path]

    for path in files:
        print(f"Extracting: {path.name}")
        result = extract_form11(path)
        out = create_excel(path.stem, result["fields"])
        final = out_dir / f"{path.stem}_FORM11.xlsx"
        final.write_bytes(out.read_bytes())
        print(f"Created: {final}")


if __name__ == "__main__":
    main()
