from __future__ import annotations

from pathlib import Path
from typing import Dict

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

ROOT = Path(__file__).resolve().parent
OUTPUT_DIR = ROOT / "outputs"
OUTPUT_DIR.mkdir(exist_ok=True)

FIELD_ORDER = [
    ("member_name", "NAME OF MEMBER"),
    ("father_spouse_name", "FATHER / HUSBAND NAME"),
    ("date_of_birth", "DATE OF BIRTH"),
    ("gender", "GENDER"),
    ("marital_status", "MARITAL STATUS"),
    ("email_id", "EMAIL ID"),
    ("mobile_number", "MOBILE NUMBER"),
    ("date_of_joining", "DATE OF JOINING"),
    ("bank_account_number", "BANK ACCOUNT NUMBER"),
    ("ifsc_code", "IFSC CODE"),
    ("aadhaar_number", "AADHAAR NUMBER"),
    ("pan_number", "PAN NUMBER"),
    ("previous_establishment", "PREVIOUS ESTABLISHMENT NAME & ADDRESS"),
    ("previous_uan", "PREVIOUS UAN"),
    ("previous_pf_number", "PREVIOUS PF ACCOUNT NUMBER"),
    ("previous_joining_date", "PREVIOUS DATE OF JOINING"),
    ("previous_exit_date", "PREVIOUS DATE OF EXIT"),
    ("ncp_days", "NCP DAYS"),
]


def create_excel(doc_id: str, fields: Dict[str, str]) -> Path:
    wb = Workbook()
    ws = wb.active
    ws.title = "FORM 11 DATA"
    ws.sheet_view.showGridLines = False
    ws.sheet_view.zoomScale = 100

    thin = Side(style="thin", color="1F2937")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    header_fill = PatternFill("solid", fgColor="D9EAF7")
    value_fill = PatternFill("solid", fgColor="FFF2CC")

    ws.merge_cells("A1:B1")
    ws["A1"] = "FORM 11 EXTRACTED DATA"
    ws["A1"].font = Font(bold=True, size=16)
    ws["A1"].alignment = Alignment(horizontal="center")

    ws["A3"] = "FIELD"
    ws["B3"] = "VALUE"
    for cell in ws[3]:
        cell.font = Font(bold=True)
        cell.fill = header_fill
        cell.border = border
        cell.alignment = Alignment(horizontal="center")

    row = 4
    for key, label in FIELD_ORDER:
        ws.cell(row=row, column=1, value=label)
        ws.cell(row=row, column=2, value=str(fields.get(key, "")).upper())
        ws.cell(row=row, column=1).font = Font(bold=True)
        ws.cell(row=row, column=2).font = Font(bold=True)
        ws.cell(row=row, column=2).fill = value_fill
        for col in (1, 2):
            c = ws.cell(row=row, column=col)
            c.border = border
            c.alignment = Alignment(vertical="top", wrap_text=True)
        row += 1

    ws.column_dimensions["A"].width = 38
    ws.column_dimensions["B"].width = 65
    for r in range(1, row + 1):
        ws.row_dimensions[r].height = 24

    raw = fields.get("raw_ocr_text", "")
    if raw:
        raw_ws = wb.create_sheet("RAW OCR TEXT")
        raw_ws["A1"] = raw.upper()
        raw_ws["A1"].alignment = Alignment(wrap_text=True, vertical="top")
        raw_ws["A1"].font = Font(name="Consolas", size=10)
        raw_ws.column_dimensions["A"].width = 120
        raw_ws.row_dimensions[1].height = 600
        raw_ws.sheet_view.showGridLines = False

    output = OUTPUT_DIR / f"form11_{doc_id}.xlsx"
    wb.save(output)
    return output
