@echo off
cd /d %~dp0
if not exist venv (
  python -m venv venv
)
call venv\Scripts\activate
python -m pip install --upgrade pip setuptools wheel
REM Install PaddlePaddle CPU first. Required by PaddleOCR.
python -m pip install paddlepaddle -i https://www.paddlepaddle.org.cn/packages/stable/cpu/
REM Install only needed backend + OCR libraries with compatible versions.
pip install -r requirements.txt
python -c "import uvicorn, fitz, cv2, openpyxl; from paddleocr import PaddleOCR; print('Backend + OCR libraries installed successfully')"
echo.
echo Done. Now run: python app.py
pause
