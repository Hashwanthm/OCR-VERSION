from __future__ import annotations

import io
import re
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import cv2
import fitz  # PyMuPDF
import numpy as np
from PIL import Image
from rapidfuzz import fuzz

ROOT = Path(__file__).resolve().parent
UPLOAD_DIR = ROOT / "uploads"
PREVIEW_DIR = ROOT / "previews"
UPLOAD_DIR.mkdir(exist_ok=True)
PREVIEW_DIR.mkdir(exist_ok=True)

OCR_ENGINE = None

FIELD_LABELS = {
    "member_name": "NAME OF MEMBER",
    "father_spouse_name": "FATHER / HUSBAND NAME",
    "date_of_birth": "DATE OF BIRTH",
    "gender": "GENDER",
    "marital_status": "MARITAL STATUS",
    "email_id": "EMAIL ID",
    "mobile_number": "MOBILE NUMBER",
    "date_of_joining": "DATE OF JOINING",
    "bank_account_number": "BANK ACCOUNT NUMBER",
    "ifsc_code": "IFSC CODE",
    "aadhaar_number": "AADHAAR NUMBER",
    "pan_number": "PAN NUMBER",
    "previous_establishment": "PREVIOUS ESTABLISHMENT NAME & ADDRESS",
    "previous_uan": "PREVIOUS UAN",
    "previous_pf_number": "PREVIOUS PF ACCOUNT NUMBER",
    "previous_joining_date": "PREVIOUS DATE OF JOINING",
    "previous_exit_date": "PREVIOUS DATE OF EXIT",
    "ncp_days": "NCP DAYS",
    "raw_ocr_text": "RAW OCR TEXT",
}

# Relative crop bands for common EPFO Form 11 layout.
# These are used after one full-page OCR pass: text boxes are assigned to a field by center point.
FIELD_ZONES = {
    "member_name": (0.48, 0.15, 0.96, 0.205),
    "father_spouse_name": (0.48, 0.205, 0.96, 0.255),
    "date_of_birth": (0.48, 0.255, 0.300, 0.305),
    "gender": (0.48, 0.300, 0.96, 0.345),
    "marital_status": (0.48, 0.345, 0.96, 0.390),
    "email_id": (0.48, 0.390, 0.96, 0.435),
    "mobile_number": (0.48, 0.435, 0.96, 0.480),
    "date_of_joining": (0.48, 0.480, 0.96, 0.535),
    "bank_account_number": (0.48, 0.560, 0.96, 0.605),
    "ifsc_code": (0.48, 0.605, 0.96, 0.645),
    "aadhaar_number": (0.48, 0.645, 0.96, 0.690),
    "pan_number": (0.48, 0.690, 0.96, 0.735),
    "previous_establishment": (0.05, 0.780, 0.250, 0.910),
    "previous_uan": (0.250, 0.780, 0.370, 0.910),
    "previous_pf_number": (0.370, 0.780, 0.520, 0.910),
    "previous_joining_date": (0.520, 0.780, 0.630, 0.910),
    "previous_exit_date": (0.630, 0.780, 0.740, 0.910),
    "ncp_days": (0.860, 0.780, 0.960, 0.910),
}

@dataclass
class OCRItem:
    text: str
    confidence: float
    box: List[List[float]]

    @property
    def center(self) -> Tuple[float, float]:
        xs = [p[0] for p in self.box]
        ys = [p[1] for p in self.box]
        return sum(xs) / 4, sum(ys) / 4


def get_ocr_engine():
    global OCR_ENGINE
    if OCR_ENGINE is None:
        try:
            from paddleocr import PaddleOCR
        except Exception as exc:
            raise RuntimeError(
                "PaddleOCR is not installed correctly. Run backend/install_backend_cpu.bat first."
            ) from exc
        OCR_ENGINE = PaddleOCR(use_angle_cls=False, lang="en", show_log=False)
    return OCR_ENGINE


def save_upload(file_bytes: bytes, filename: str) -> Tuple[str, Path]:
    file_id = uuid.uuid4().hex
    safe_name = re.sub(r"[^A-Za-z0-9_.-]+", "_", filename)
    path = UPLOAD_DIR / f"{file_id}_{safe_name}"
    path.write_bytes(file_bytes)
    return file_id, path


def render_first_page_to_image(path: Path, max_width: int = 1400) -> Path:
    ext = path.suffix.lower()
    preview_path = PREVIEW_DIR / f"{path.stem}.png"
    if ext == ".pdf":
        doc = fitz.open(path)
        page = doc[0]
        # 1.6 is faster than very high DPI but still readable for OCR.
        pix = page.get_pixmap(matrix=fitz.Matrix(1.6, 1.6), alpha=False)
        img_bytes = pix.tobytes("png")
        doc.close()
        image = Image.open(io.BytesIO(img_bytes)).convert("RGB")
    else:
        image = Image.open(path).convert("RGB")

    if image.width > max_width:
        ratio = max_width / image.width
        image = image.resize((max_width, int(image.height * ratio)))
    image.save(preview_path)
    return preview_path


def preprocess_for_ocr(image_path: Path) -> Path:
    image = cv2.imread(str(image_path))
    if image is None:
        return image_path
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    gray = cv2.fastNlMeansDenoising(gray, None, 10, 7, 21)
    # Light sharpening helps handwritten blue ink.
    blur = cv2.GaussianBlur(gray, (0, 0), 1.0)
    sharp = cv2.addWeighted(gray, 1.45, blur, -0.45, 0)
    # Keep as grayscale; aggressive thresholding can damage handwriting.
    out = PREVIEW_DIR / f"{image_path.stem}_ocr.png"
    cv2.imwrite(str(out), sharp)
    return out


def run_paddle_ocr(image_path: Path) -> List[OCRItem]:
    ocr = get_ocr_engine()
    result = ocr.ocr(str(image_path), cls=False)
    items: List[OCRItem] = []
    if not result:
        return items
    for page in result:
        if not page:
            continue
        for line in page:
            try:
                box, value = line
                text, conf = value
                text = str(text).strip()
                if text:
                    items.append(OCRItem(text=text, confidence=float(conf), box=box))
            except Exception:
                continue
    return items


def clean_text(value: str) -> str:
    value = value.replace("\n", " ")
    value = re.sub(r"\s+", " ", value).strip()
    return value.upper()


def clean_digits(value: str) -> str:
    return re.sub(r"\D+", "", value)


def clean_date(value: str) -> str:
    value = value.upper().replace("O", "0").replace("I", "1").replace("L", "1")
    nums = re.findall(r"\d+", value)
    if len(nums) >= 3:
        d, m, y = nums[0], nums[1], nums[2]
        if len(y) == 2:
            y = "20" + y
        return f"{d.zfill(2)}/{m.zfill(2)}/{y}"
    return clean_text(value)


def clean_pan(value: str) -> str:
    return re.sub(r"[^A-Z0-9]", "", clean_text(value))[:10]


def clean_ifsc(value: str) -> str:
    return re.sub(r"[^A-Z0-9]", "", clean_text(value))[:11]


def assign_by_zones(items: List[OCRItem], image_path: Path) -> Dict[str, str]:
    image = Image.open(image_path)
    w, h = image.size
    fields: Dict[str, List[str]] = {k: [] for k in FIELD_LABELS if k != "raw_ocr_text"}

    for item in items:
        cx, cy = item.center
        rx, ry = cx / w, cy / h
        for field, (x1, y1, x2, y2) in FIELD_ZONES.items():
            if x1 <= rx <= x2 and y1 <= ry <= y2:
                # Do not include printed labels if they accidentally fall inside a value zone.
                if looks_like_label(item.text):
                    continue
                fields[field].append(item.text)
                break

    extracted: Dict[str, str] = {}
    for field, parts in fields.items():
        extracted[field] = clean_text(" ".join(parts))

    return post_clean_fields(extracted)


def looks_like_label(text: str) -> bool:
    t = clean_text(text)
    labels = [
        "NAME", "FATHER", "SPOUSE", "DATE OF BIRTH", "GENDER", "MARITAL",
        "EMAIL", "MOBILE", "BANK", "AADHAAR", "PERMANENT", "ACCOUNT", "IFSC",
        "PREVIOUS", "ESTABLISHMENT", "UNIVERSAL", "NUMBER", "CONTRIBUTORY",
    ]
    return any(fuzz.partial_ratio(t, label) >= 85 for label in labels)


def fallback_from_raw(raw: str, extracted: Dict[str, str]) -> Dict[str, str]:
    text = clean_text(raw)
    emails = re.findall(r"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}", text)
    if emails and not extracted.get("email_id"):
        extracted["email_id"] = emails[0]

    phones = [x for x in re.findall(r"\b\d{10}\b", text) if not x.startswith("000")]
    if phones and not extracted.get("mobile_number"):
        extracted["mobile_number"] = phones[0]

    aadhaar = [x for x in re.findall(r"\b\d{12}\b", text)]
    if aadhaar and not extracted.get("aadhaar_number"):
        extracted["aadhaar_number"] = aadhaar[-1]

    pan = re.findall(r"\b[A-Z]{5}\d{4}[A-Z]\b", text)
    if pan and not extracted.get("pan_number"):
        extracted["pan_number"] = pan[0]

    ifsc = re.findall(r"\b[A-Z]{4}0[A-Z0-9]{6}\b", text)
    if ifsc and not extracted.get("ifsc_code"):
        extracted["ifsc_code"] = ifsc[0]
    return extracted


def post_clean_fields(fields: Dict[str, str]) -> Dict[str, str]:
    for key in list(fields.keys()):
        fields[key] = clean_text(fields.get(key, ""))

    for key in ["mobile_number", "aadhaar_number", "bank_account_number", "previous_uan", "ncp_days"]:
        if fields.get(key):
            fields[key] = clean_digits(fields[key])

    for key in ["date_of_birth", "date_of_joining", "previous_joining_date", "previous_exit_date"]:
        if fields.get(key):
            fields[key] = clean_date(fields[key])

    if fields.get("pan_number"):
        fields["pan_number"] = clean_pan(fields["pan_number"])
    if fields.get("ifsc_code"):
        fields["ifsc_code"] = clean_ifsc(fields["ifsc_code"])

    return fields


def extract_form11(file_path: Path) -> Dict[str, object]:
    preview_path = render_first_page_to_image(file_path)
    ocr_image = preprocess_for_ocr(preview_path)
    items = run_paddle_ocr(ocr_image)
    raw = "\n".join(item.text for item in items)
    fields = assign_by_zones(items, preview_path)
    fields = fallback_from_raw(raw, fields)
    fields = post_clean_fields(fields)
    fields["raw_ocr_text"] = clean_text(raw)

    confidence = 0.0
    if items:
        confidence = round(sum(item.confidence for item in items) / len(items), 3)

    return {
        "fields": fields,
        "raw_text": raw,
        "confidence": confidence,
        "preview_file": preview_path.name,
    }
