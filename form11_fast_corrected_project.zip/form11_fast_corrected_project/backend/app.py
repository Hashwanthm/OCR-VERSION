from __future__ import annotations

from pathlib import Path
from typing import Dict, List

import uvicorn
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel

from excel_service import create_excel
from ocr_service import FIELD_LABELS, PREVIEW_DIR, extract_form11, save_upload

app = FastAPI(title="Form 11 Fast AI OCR API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173", "*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

DOCUMENTS: Dict[str, Dict] = {}


class UpdatePayload(BaseModel):
    fields: Dict[str, str]


@app.get("/api/health")
def health():
    return {"status": "ok", "message": "Form 11 backend running"}


@app.post("/api/process")
async def process_files(files: List[UploadFile] = File(...)):
    if not files:
        raise HTTPException(status_code=400, detail="Upload at least 1 file")
    if len(files) > 10:
        raise HTTPException(status_code=400, detail="Maximum 10 files allowed")

    results = []
    for file in files:
        name = file.filename or "upload.pdf"
        suffix = Path(name).suffix.lower()
        if suffix not in {".pdf", ".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tif", ".tiff"}:
            raise HTTPException(status_code=400, detail=f"Unsupported file: {name}")
        content = await file.read()
        doc_id, upload_path = save_upload(content, name)
        try:
            extraction = extract_form11(upload_path)
        except RuntimeError as exc:
            raise HTTPException(status_code=500, detail=str(exc))
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"OCR failed for {name}: {exc}")

        fields = extraction["fields"]
        DOCUMENTS[doc_id] = {
            "id": doc_id,
            "filename": name,
            "upload_path": str(upload_path),
            "preview_file": extraction["preview_file"],
            "fields": fields,
            "confidence": extraction["confidence"],
        }
        results.append({
            "id": doc_id,
            "filename": name,
            "previewUrl": f"/api/preview/{extraction['preview_file']}",
            "fields": fields,
            "confidence": extraction["confidence"],
        })

    return {"documents": results, "fieldLabels": FIELD_LABELS}


@app.get("/api/preview/{preview_name}")
def preview(preview_name: str):
    path = PREVIEW_DIR / preview_name
    if not path.exists():
        raise HTTPException(status_code=404, detail="Preview not found")
    return FileResponse(path)


@app.post("/api/document/{doc_id}/excel")
def update_and_download(doc_id: str, payload: UpdatePayload):
    doc = DOCUMENTS.get(doc_id)
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found. Re-upload the file.")
    fields = {key: str(value).upper() for key, value in payload.fields.items()}
    doc["fields"] = fields
    output = create_excel(doc_id, fields)
    return FileResponse(
        output,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        filename=f"{Path(doc['filename']).stem}_FORM11.xlsx",
    )


if __name__ == "__main__":
    uvicorn.run("app:app", host="127.0.0.1", port=8000, reload=True)
