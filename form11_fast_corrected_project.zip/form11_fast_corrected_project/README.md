# Form 11 Fast AI OCR Project

This is the corrected speed-focused project for handwritten/scanned Form 11 extraction.

## What changed

- Removed heavy unused AI libraries: Torch, Transformers, Sentence Transformers, Unstructured, EasyOCR.
- Kept only needed OCR stack: PaddleOCR + PaddlePaddle + OpenCV + PyMuPDF.
- Fixed the OpenCV/PaddleOCR dependency conflict by pinning compatible versions.
- Left side shows PDF/image preview.
- Right side shows editable extracted fields.
- No Excel preview.
- Excel is generated after the user reviews/corrects the fields.
- Values are saved in CAPITAL LETTERS.

## Backend libraries

- FastAPI
- Uvicorn
- python-multipart
- PyMuPDF
- OpenCV
- Pillow
- NumPy
- OpenPyXL
- RapidFuzz
- PaddlePaddle
- PaddleOCR

## Frontend libraries

- React
- Vite 5.4.11

Vite is pinned to version 5.4.11 to avoid Node version issues.

## Run backend

Open terminal inside `backend`:

```cmd
cd backend
install_backend_cpu.bat
python app.py
```

If you already installed once:

```cmd
cd backend
venv\Scripts\activate
python app.py
```

Backend URL:

```text
http://127.0.0.1:8000
```

## Run frontend

Open another terminal:

```cmd
cd frontend
npm install
npm run dev
```

Frontend URL:

```text
http://127.0.0.1:5173
```

## Important

Handwritten OCR is not 100% accurate. The right side editable fields are mandatory for review before Excel download.

## CLI option

Inside backend:

```cmd
venv\Scripts\activate
python cli.py "C:\path\to\form11.pdf" --output "C:\output"
```
