import React, { useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import './style.css';

const API = 'http://127.0.0.1:8000';

const FIELD_ORDER = [
  ['member_name', 'Name of member'],
  ['father_spouse_name', "Father / Husband Name"],
  ['date_of_birth', 'Date of Birth'],
  ['gender', 'Gender'],
  ['marital_status', 'Marital Status'],
  ['email_id', 'Email ID'],
  ['mobile_number', 'Mobile Number'],
  ['date_of_joining', 'Date of Joining'],
  ['bank_account_number', 'Bank Account Number'],
  ['ifsc_code', 'IFSC Code'],
  ['aadhaar_number', 'Aadhaar Number'],
  ['pan_number', 'PAN Number'],
  ['previous_establishment', 'Previous Establishment'],
  ['previous_uan', 'Previous UAN'],
  ['previous_pf_number', 'Previous PF Number'],
  ['previous_joining_date', 'Previous Joining Date'],
  ['previous_exit_date', 'Previous Exit Date'],
  ['ncp_days', 'NCP Days'],
];

function App() {
  const [documents, setDocuments] = useState([]);
  const [selectedId, setSelectedId] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('Ready');

  const selected = useMemo(() => documents.find((d) => d.id === selectedId) || null, [documents, selectedId]);

  const handleUpload = async (event) => {
    const files = Array.from(event.target.files || []);
    if (!files.length) return;
    if (files.length > 10) {
      setMessage('Maximum 10 files allowed.');
      return;
    }

    const formData = new FormData();
    files.forEach((file) => formData.append('files', file));
    setLoading(true);
    setMessage('Running AI OCR. Please wait...');

    try {
      const response = await fetch(`${API}/api/process`, {
        method: 'POST',
        body: formData,
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.detail || 'OCR failed');
      setDocuments(data.documents || []);
      setSelectedId(data.documents?.[0]?.id || '');
      setMessage(`${data.documents?.length || 0} file(s) processed. Review/edit fields before Excel download.`);
    } catch (error) {
      setMessage(error.message);
    } finally {
      setLoading(false);
    }
  };

  const updateField = (key, value) => {
    setDocuments((prev) =>
      prev.map((doc) =>
        doc.id === selectedId
          ? { ...doc, fields: { ...doc.fields, [key]: value.toUpperCase() } }
          : doc
      )
    );
  };

  const downloadExcel = async () => {
    if (!selected) return;
    setMessage('Creating Excel...');
    try {
      const response = await fetch(`${API}/api/document/${selected.id}/excel`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fields: selected.fields }),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.detail || 'Excel download failed');
      }
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${selected.filename.replace(/\.[^.]+$/, '')}_FORM11.xlsx`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
      setMessage('Excel downloaded successfully.');
    } catch (error) {
      setMessage(error.message);
    }
  };

  return (
    <div className="app">
      <header className="topbar">
        <h1>FORM 11 FAST AI OCR</h1>
        <div className="actions">
          <label className="uploadBtn">
            Upload PDFs / Images (max 10)
            <input type="file" multiple accept=".pdf,.png,.jpg,.jpeg,.webp,.bmp,.tif,.tiff" onChange={handleUpload} />
          </label>
          <span className="badge">{documents.length} / 10 files selected</span>
          <button disabled={!selected || loading} onClick={downloadExcel}>Download Excel</button>
        </div>
      </header>

      <main className="layout">
        <section className="panel previewPanel">
          <div className="panelHeader">
            <h2>PDF / Image Preview</h2>
            <select value={selectedId} onChange={(e) => setSelectedId(e.target.value)}>
              <option value="">No file selected</option>
              {documents.map((doc, index) => (
                <option key={doc.id} value={doc.id}>PDF {index + 1}: {doc.filename}</option>
              ))}
            </select>
          </div>
          <div className="previewBox">
            {selected ? (
              <img src={`${API}${selected.previewUrl}`} alt="Document preview" />
            ) : (
              <p>Upload handwritten/scanned Form 11 PDF or image.</p>
            )}
          </div>
        </section>

        <section className="panel fieldsPanel">
          <div className="panelHeader">
            <div>
              <h2>Editable Extracted Fields</h2>
              <p>OCR confidence: {selected?.confidence ?? '-'}</p>
            </div>
            <button disabled={!selected || loading} onClick={downloadExcel}>Save Excel</button>
          </div>

          <div className="note">
            AI OCR can make mistakes for handwritten data. Check red/doubtful fields, edit values, then download Excel. Values are saved in CAPITAL LETTERS.
          </div>

          {loading && <div className="loading">Processing OCR...</div>}

          {selected ? (
            <div className="fieldGrid">
              {FIELD_ORDER.map(([key, label]) => {
                const value = selected.fields?.[key] || '';
                const doubtful = isDoubtful(key, value);
                return (
                  <label className={`field ${doubtful ? 'doubtful' : ''}`} key={key}>
                    <span>{label}</span>
                    <input value={value} onChange={(e) => updateField(key, e.target.value)} />
                    {doubtful && <small>{doubtMessage(key)}</small>}
                  </label>
                );
              })}
              <label className="field raw">
                <span>Raw OCR Text</span>
                <textarea value={selected.fields?.raw_ocr_text || ''} onChange={(e) => updateField('raw_ocr_text', e.target.value)} />
              </label>
            </div>
          ) : (
            <div className="emptyFields">Extracted fields will appear here.</div>
          )}
        </section>
      </main>
      <footer>{message}</footer>
    </div>
  );
}

function isDoubtful(key, value) {
  if (!value) return ['member_name', 'mobile_number', 'aadhaar_number', 'pan_number'].includes(key);
  if (key === 'mobile_number') return !/^\d{10}$/.test(value);
  if (key === 'aadhaar_number') return !/^\d{12}$/.test(value);
  if (key === 'pan_number') return !/^[A-Z]{5}\d{4}[A-Z]$/.test(value);
  if (key === 'ifsc_code') return value && !/^[A-Z]{4}0[A-Z0-9]{6}$/.test(value);
  return false;
}

function doubtMessage(key) {
  const map = {
    member_name: 'Check name manually',
    mobile_number: 'Mobile should be 10 digits',
    aadhaar_number: 'Aadhaar should be 12 digits',
    pan_number: 'PAN format looks doubtful',
    ifsc_code: 'IFSC format looks doubtful',
  };
  return map[key] || 'Check this field';
}

createRoot(document.getElementById('root')).render(<App />);
