const pdfInput = document.getElementById("pdfInput");
const convertBtn = document.getElementById("convertBtn");
const pdfArea = document.getElementById("pdfArea");
const excelArea = document.getElementById("excelArea");
const fileName = document.getElementById("fileName");
const statusBox = document.getElementById("status");
const downloadBtn = document.getElementById("downloadBtn");

let currentPdfUrl = null;

pdfInput.addEventListener("change", function () {
  const file = pdfInput.files[0];

  downloadBtn.style.display = "none";
  downloadBtn.href = "#";

  excelArea.innerHTML = `
    <div class="empty">
      Click Convert to extract first page data.
      Downloaded Excel will include Form 3A and full first-page information.
    </div>
  `;

  if (!file) {
    fileName.textContent = "No file selected";

    pdfArea.innerHTML = `
      <div class="empty">
        Upload a PDF file to preview it here.
      </div>
    `;

    setStatus("Ready", "");
    return;
  }

  if (file.type !== "application/pdf" && !file.name.toLowerCase().endsWith(".pdf")) {
    fileName.textContent = "No file selected";

    pdfArea.innerHTML = `
      <div class="empty">
        Please upload a valid PDF file.
      </div>
    `;

    setStatus("Only PDF files are allowed.", "error");
    pdfInput.value = "";
    return;
  }

  fileName.textContent = file.name;

  // Remove old preview URL from browser memory
  if (currentPdfUrl) {
    URL.revokeObjectURL(currentPdfUrl);
  }

  currentPdfUrl = URL.createObjectURL(file);

  // iframe is more reliable than embed for PDF preview in Chrome/Edge
  pdfArea.innerHTML = `
    <iframe
      class="pdf-preview"
      src="${currentPdfUrl}#page=1&toolbar=1&navpanes=0"
      title="PDF first page preview">
    </iframe>
  `;

  setStatus("PDF loaded. Only the first page will be converted.", "");
});

convertBtn.addEventListener("click", async function () {
  const file = pdfInput.files[0];

  if (!file) {
    setStatus("Please select a PDF file first.", "error");
    return;
  }

  const formData = new FormData();
  formData.append("pdf", file);

  convertBtn.disabled = true;
  convertBtn.textContent = "Converting...";
  downloadBtn.style.display = "none";

  setStatus("Converting first page to Excel...", "");

  try {
    const response = await fetch("/convert", {
      method: "POST",
      body: formData
    });

    const result = await response.json();

    if (!response.ok) {
      throw new Error(result.error || "Conversion failed");
    }

    renderExcelTable(result.rows);

    downloadBtn.href = result.download_url;
    downloadBtn.style.display = "inline-block";

    setStatus("First page converted successfully. Click Download Excel.", "success");

  } catch (error) {
    excelArea.innerHTML = `
      <div class="empty">
        Conversion failed.
      </div>
    `;

    setStatus(error.message, "error");

  } finally {
    convertBtn.disabled = false;
    convertBtn.textContent = "Convert";
  }
});

function renderExcelTable(rows) {
  if (!rows || rows.length === 0) {
    excelArea.innerHTML = `
      <div class="empty">
        No data extracted.
      </div>
    `;
    return;
  }

  const maxCols = Math.max(...rows.map(row => row.length));

  let html = `<table class="excel-table">`;

  html += `<thead><tr>`;

  for (let i = 1; i <= maxCols; i++) {
    html += `<th>${getExcelColumnName(i)}</th>`;
  }

  html += `</tr></thead>`;
  html += `<tbody>`;

  rows.forEach(row => {
    const isSectionRow = row.length === 1 && String(row[0]).startsWith("Page ");

    html += `<tr class="${isSectionRow ? "section-row" : ""}">`;

    for (let i = 0; i < maxCols; i++) {
      const value = row[i] || "";
      html += `<td>${escapeHtml(value)}</td>`;
    }

    html += `</tr>`;
  });

  html += `</tbody></table>`;

  excelArea.innerHTML = html;
}

function getExcelColumnName(number) {
  let columnName = "";

  while (number > 0) {
    let remainder = (number - 1) % 26;
    columnName = String.fromCharCode(65 + remainder) + columnName;
    number = Math.floor((number - 1) / 26);
  }

  return columnName;
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function setStatus(message, type) {
  statusBox.textContent = message;
  statusBox.className = "status";

  if (type) {
    statusBox.classList.add(type);
  }
}
