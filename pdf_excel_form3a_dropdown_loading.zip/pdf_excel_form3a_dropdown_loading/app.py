from pathlib import Path
import re
import uuid
from zipfile import ZipFile, ZIP_DEFLATED

import pdfplumber
from flask import Flask, render_template, request, jsonify, send_from_directory
from werkzeug.utils import secure_filename

from openpyxl import Workbook
from openpyxl.styles import Border, Side, Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter


app = Flask(__name__)

BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = BASE_DIR / "uploads"
OUTPUT_DIR = BASE_DIR / "outputs"

UPLOAD_DIR.mkdir(exist_ok=True)
OUTPUT_DIR.mkdir(exist_ok=True)


# ======================================================
# CLEANING
# ======================================================

def clean_text(value):
    if value is None:
        return ""

    value = str(value)
    value = value.replace("\n", " ")
    value = value.replace("\xa0", " ")
    value = re.sub(r"\s+", " ", value)
    return value.strip()


def amount_to_number(value):
    value = clean_text(value)

    if value in ["", "-", ".", "0"]:
        return 0.0

    value = value.replace(",", "")
    value = re.sub(r"[^\d.]", "", value)

    if value == "":
        return 0.0

    try:
        return float(value)
    except Exception:
        return 0.0


def find_value(text, patterns, default=""):
    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE | re.DOTALL)
        if match:
            return clean_text(match.group(1))
    return default


# ======================================================
# PDF EXTRACTION
# ======================================================

def extract_pdf_text(pdf_path, page_number=0):
    """Extract text from one page only. Default: first page."""

    with pdfplumber.open(pdf_path) as pdf:
        if not pdf.pages:
            return ""

        if page_number >= len(pdf.pages):
            page_number = 0

        page = pdf.pages[page_number]
        return page.extract_text(x_tolerance=2, y_tolerance=3) or ""


def extract_pdf_tables(pdf_path, page_number=0):
    """Extract table rows from one page only. Default: first page."""
    all_rows = []

    line_settings = {
        "vertical_strategy": "lines",
        "horizontal_strategy": "lines",
        "snap_tolerance": 3,
        "join_tolerance": 3,
        "intersection_tolerance": 5,
        "text_x_tolerance": 2,
        "text_y_tolerance": 3,
    }

    text_settings = {
        "vertical_strategy": "text",
        "horizontal_strategy": "text",
        "snap_tolerance": 3,
        "join_tolerance": 3,
        "intersection_tolerance": 5,
        "text_x_tolerance": 2,
        "text_y_tolerance": 3,
    }

    with pdfplumber.open(pdf_path) as pdf:
        if not pdf.pages:
            return all_rows

        if page_number >= len(pdf.pages):
            page_number = 0

        page = pdf.pages[page_number]
        tables = page.extract_tables(table_settings=line_settings)

        if not tables:
            tables = page.extract_tables(table_settings=text_settings)

        for table in tables:
            for row in table:
                cleaned_row = [clean_text(cell) for cell in row]

                if any(cleaned_row):
                    all_rows.append(cleaned_row)

    return all_rows


# ======================================================
# PARSE BASIC DETAILS
# Works for:
# 1. Form 3A PDF
# 2. EPFO passbook PDF
# ======================================================


def extract_member_name_from_passbook(text):
    """Get employee name from EPFO passbook text after Member ID/Name.

    This first tries line-by-line extraction so Hindi labels or nearby text
    do not get added to the employee name. It also accepts separators that
    pdfplumber may read as /, |, I, or l.
    """

    raw_text = text or ""

    def clean_name(candidate):
        candidate = clean_text(candidate)

        # Stop immediately if other labels appear after the name.
        candidate = re.split(
            r"\b(?:Date\s*of\s*Birth|DOB|UAN|EPF\s*Passbook|Financial\s*Year|Taxable\s*Data|Establishment\s*ID|Member\s*Passbook)\b",
            candidate,
            maxsplit=1,
            flags=re.IGNORECASE,
        )[0]

        # Keep only alphabetic name characters and spaces.
        candidate = re.sub(r"[^A-Za-z.\s]", " ", candidate)
        candidate = re.sub(r"\b(Member|ID|Name|Date|Birth|UAN|TUE|FRFFK|LFKKIUK|IKKCQD|VKBZMH)\b", "", candidate, flags=re.IGNORECASE)
        candidate = clean_text(candidate)

        # Avoid extra OCR/pdfplumber garbage after the real name.
        words = [w for w in candidate.split() if len(w) > 1]
        if len(words) > 4:
            words = words[:4]

        return " ".join(words).upper()

    # Best path: read the actual text line that contains Member ID/Name.
    for line in raw_text.splitlines():
        line_clean = clean_text(line)
        if not re.search(r"Member\s*ID\s*/?\s*Name", line_clean, re.IGNORECASE):
            continue

        # Remove label.
        after_label = re.sub(
            r".*?Member\s*ID\s*/?\s*Name\s*[:\-]?\s*",
            "",
            line_clean,
            flags=re.IGNORECASE,
        )

        # Remove member id and separator. Whatever remains on this line is the name.
        after_id = re.sub(
            r"^[A-Z]{2,}[A-Z0-9]{8,}\s*(?:/|\||\bI\b|\bl\b|:)\s*",
            "",
            after_label,
            flags=re.IGNORECASE,
        )

        name = clean_name(after_id)
        if name:
            return name

    normalized = clean_text(raw_text)

    # Fallback: normalized paragraph pattern.
    patterns = [
        r"Member\s*ID\s*/?\s*Name\s*[:\-]?\s*[A-Z]{2,}[A-Z0-9]{8,}\s*(?:/|\||\bI\b|\bl\b|:)\s*([A-Z][A-Z.\s]+?)(?=\s*(?:Date\s*of\s*Birth|DOB|UAN\b|EPF\s*Passbook|Financial\s*Year|Taxable\s*Data|Establishment\s*ID|$))",
        r"Member\s*ID\s*Name\s*[:\-]?\s*[A-Z]{2,}[A-Z0-9]{8,}\s*(?:/|\||\bI\b|\bl\b|:)\s*([A-Z][A-Z.\s]+?)(?=\s*(?:Date\s*of\s*Birth|DOB|UAN\b|EPF\s*Passbook|Financial\s*Year|Taxable\s*Data|Establishment\s*ID|$))",
    ]

    for pattern in patterns:
        match = re.search(pattern, normalized, re.IGNORECASE | re.DOTALL)
        if match:
            name = clean_name(match.group(1))
            if name:
                return name

    return ""


def normalize_passbook_text_for_details(text, table_rows=None):
    """Join first-page text and table rows to improve detail extraction."""
    parts = [text or ""]

    if table_rows:
        for row in table_rows:
            row_text = " ".join(clean_text(cell) for cell in row if clean_text(cell))
            if row_text:
                parts.append(row_text)

    return "\n".join(parts)

def parse_basic_details(text, table_rows=None):
    normalized = clean_text(normalize_passbook_text_for_details(text, table_rows))

    details = {
        "account_no": "",
        "uan": "",
        "name": "",
        "father_name": "",
        "factory_address": "",
        "establishment_id": "",
        "company_name": "",
        "statutory_rate": "12%",
        "higher_rate_employee": "NO",
        "higher_rate_employer": "NO",
        "higher_rate_pension": "NO",
        "date": "",
    }

    # Member ID / Name from EPFO passbook
    member_id = find_value(normalized, [
        r"Member\s*ID\s*/?\s*Name\s*([A-Z0-9]+)\s*(?:/|\||\bI\b|\bl\b)?",
        r"Member\s*ID\s*[:\-]?\s*([A-Z0-9]+)",
    ])

    # Take employee name from the raw Member ID/Name line first.
    # This prevents nearby Hindi/OCR text from being pasted into the name.
    member_name = extract_member_name_from_passbook(text) or extract_member_name_from_passbook(normalized)

    # Establishment ID / Name from EPFO passbook
    establishment_id = find_value(normalized, [
        r"Establishment\s*ID\s*/?\s*Name\s*([A-Z0-9]+)\s*(?:/|\||\bI\b|\bl\b)?",
        r"Establishment\s*ID\s*([A-Z0-9]+)",
    ])

    establishment_name = find_value(normalized, [
        r"Establishment\s*ID\s*/?\s*Name\s*[A-Z0-9]+\s*(?:/|\||\bI\b|\bl\b)\s*([A-Z0-9\s\.\-&]+?)(?:\s*Member\s*ID|\s*Member|$)",
    ])

    # Form 3A account number
    account_no = find_value(normalized, [
        r"1\s*Account\s*No\.?\s*([A-Z0-9]+)",
        r"Account\s*No\.?\s*([A-Z0-9]+)",
    ])

    details["account_no"] = account_no or member_id
    details["establishment_id"] = establishment_id

    details["uan"] = find_value(normalized, [
        r"\bUAN\b\s*([0-9]{8,20})",
    ])

    # Form 3A name
    form_name = find_value(normalized, [
        r"2\s*Name\s*/\s*Surname\s*([A-Z][A-Z\s\.]+?)(?:\s*\(in\s*Block|\s*3\s*Father|\s*Father)",
        r"Name\s*/\s*Surname\s*([A-Z][A-Z\s\.]+?)(?:\s*\(in\s*Block|\s*3\s*Father|\s*Father)",
    ])

    details["name"] = member_name or form_name

    details["father_name"] = find_value(normalized, [
        r"3\s*Father'?s\s*/\s*Husband'?s\s*Name\s*([A-Z][A-Z\s\.]+?)(?:\s*4\s*Name|\s*Name\s*&\s*Address)",
        r"Father'?s\s*/\s*Husband'?s\s*Name\s*([A-Z][A-Z\s\.]+?)(?:\s*4\s*Name|\s*Name\s*&\s*Address)",
    ])

    factory_address = find_value(normalized, [
        r"4\s*Name\s*&\s*Address\s*of\s*the\s*Factory\s*(.*?)(?:Establishment\s*ID)",
        r"Name\s*&\s*Address\s*of\s*the\s*Factory\s*(.*?)(?:Establishment\s*ID)",
    ])

    details["factory_address"] = factory_address or establishment_name
    details["company_name"] = establishment_name

    if not details["company_name"] and factory_address:
        details["company_name"] = factory_address.split(",")[0].strip()

    if not details["company_name"]:
        details["company_name"] = "TRICORE SOLUTIONS PRIVATE LIMITED"

    statutory_rate = find_value(normalized, [
        r"Statutory\s*rate\s*of\s*Contribution\s*([0-9]+%?)",
    ])

    if statutory_rate:
        if "%" not in statutory_rate:
            statutory_rate += "%"
        details["statutory_rate"] = statutory_rate

    details["date"] = find_value(normalized, [
        r"Dated\s*([0-9]{1,2}[/-][0-9]{1,2}[/-][0-9]{2,4})",
        r"Printed\s*On\s*[:\-]?\s*([0-9]{1,2}[/-][0-9]{1,2}[/-][0-9]{2,4})",
    ])

    return details


# ======================================================
# PARSE MONTHLY TABLE
# Works for Form 3A and EPFO passbook
# ======================================================

MONTH_PATTERN = r"^(Jan|January|Feb|February|Mar|March|Apr|April|May|Jun|June|Jul|July|Aug|August|Sep|September|Oct|October|Nov|November|Dec|December)"


def is_month_text(value):
    value = clean_text(value)
    return bool(re.match(MONTH_PATTERN, value, re.IGNORECASE))


def numeric_cells(cells):
    nums = []

    for cell in cells:
        text = clean_text(cell)

        if text == "":
            continue

        # Pick values like 15000, 15,000, 1800, 1,800, 0, 0.00
        if re.fullmatch(r"-?\d+(?:,\d{3})*(?:\.\d+)?", text):
            nums.append(amount_to_number(text))

    return nums


def split_employer_share_for_form3a(wages, employer_amount, pension_amount=0.0):
    """
    EPFO passbook usually shows Employee, Employer and Pension columns.
    For Form 3A, employer share must be pasted as:
      4(a) EPF 3.67% / balance employer share
      4(b) Pension Fund 8.33%

    If pension column is blank/0 but employer amount is 12% of wages,
    split employer amount into 550 + 1250 for 15,000 wage.
    """

    wages = float(wages or 0)
    employer_amount = float(employer_amount or 0)
    pension_amount = float(pension_amount or 0)

    if wages <= 0 or employer_amount <= 0:
        return 0.0, pension_amount

    # If PDF already gives pension separately, use it directly.
    if pension_amount > 0:
        epf_367 = max(employer_amount, 0.0)
        return round(epf_367, 2), round(pension_amount, 2)

    # Passbook often has pension as 0 and employer as full 12%.
    # Form 3A needs split: 8.33% pension, balance as EPF.
    pension_wage = min(wages, 15000.0)
    calculated_pension = round(pension_wage * 8.33 / 100)

    if employer_amount >= calculated_pension:
        epf_367 = employer_amount - calculated_pension
        return round(epf_367, 2), round(calculated_pension, 2)

    return round(employer_amount, 2), 0.0


def parse_monthly_rows_from_tables(table_rows):
    monthly_rows = []

    for row in table_rows:
        if not row:
            continue

        cells = [clean_text(cell) for cell in row]

        if not cells:
            continue

        first_cell = cells[0]

        if not is_month_text(first_cell):
            continue

        row_text = " ".join(cells).upper()

        # EPFO passbook has CR / DR.
        # We use only CR contribution rows.
        if " DR " in f" {row_text} ":
            continue

        is_passbook_row = " CR " in f" {row_text} " or "CONTR" in row_text or "DUE-MONTH" in row_text

        if is_passbook_row:
            nums = numeric_cells(cells)

            # Expected EPFO passbook numeric sequence:
            # wages_epf, wages_eps, employee_contribution, employer_contribution, pension
            # We paste into Form 3A as: Wages, EPF, EPF 3.67%, Pension 8.33%.
            if len(nums) >= 5:
                wages = nums[0]
                employee_epf = nums[2]
                employer_amount = nums[3]
                pension_from_pdf = nums[4]
                employer_epf, pension = split_employer_share_for_form3a(
                    wages,
                    employer_amount,
                    pension_from_pdf
                )

                monthly_rows.append({
                    "month": first_cell,
                    "wages": wages,
                    "epf": employee_epf,
                    "epf_833": employer_epf,
                    "pension": pension,
                    "refund": 0.0,
                    "non_contribution_days": 0.0,
                    "remarks": "",
                })
            elif len(nums) >= 3:
                wages = nums[0]
                employee_epf = nums[1]
                employer_amount = nums[2]
                employer_epf, pension = split_employer_share_for_form3a(
                    wages,
                    employer_amount,
                    0.0
                )

                monthly_rows.append({
                    "month": first_cell,
                    "wages": wages,
                    "epf": employee_epf,
                    "epf_833": employer_epf,
                    "pension": pension,
                    "refund": 0.0,
                    "non_contribution_days": 0.0,
                    "remarks": "",
                })

        else:
            # Form 3A table row:
            # Month, Wages, EPF, EPF 8 1/3, Pension, Refund, Days, Remarks
            while len(cells) < 8:
                cells.append("")

            monthly_rows.append({
                "month": cells[0],
                "wages": amount_to_number(cells[1]),
                "epf": amount_to_number(cells[2]),
                "epf_833": amount_to_number(cells[3]),
                "pension": amount_to_number(cells[4]),
                "refund": amount_to_number(cells[5]),
                "non_contribution_days": amount_to_number(cells[6]),
                "remarks": cells[7],
            })

    return monthly_rows


def parse_monthly_rows_from_text(text):
    monthly_rows = []

    for line in text.splitlines():
        line = clean_text(line)

        if not is_month_text(line):
            continue

        upper_line = line.upper()

        if " DR " in f" {upper_line} ":
            continue

        # This fallback works for many selectable PDFs.
        amounts = re.findall(r"\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+\.\d{2}", line)

        if len(amounts) >= 4:
            first_amount_pos = line.find(amounts[0])
            month_part = line[:first_amount_pos].strip()

            values = [amount_to_number(x) for x in amounts]

            wages = values[0]
            epf = values[1] if len(values) > 1 else 0
            employer_amount = values[2] if len(values) > 2 else 0
            pension_from_text = values[3] if len(values) > 3 else 0

            employer, pension = split_employer_share_for_form3a(
                wages,
                employer_amount,
                pension_from_text
            )

            monthly_rows.append({
                "month": month_part,
                "wages": wages,
                "epf": epf,
                "epf_833": employer,
                "pension": pension,
                "refund": 0.0,
                "non_contribution_days": 0.0,
                "remarks": "",
            })

    return monthly_rows


def parse_monthly_rows(table_rows, text):
    monthly_rows = parse_monthly_rows_from_tables(table_rows)

    if monthly_rows:
        return monthly_rows

    return parse_monthly_rows_from_text(text)


# ======================================================
# SAFE EXCEL HELPERS
# Fixes:
# 'MergedCell' object attribute 'value' is read-only
# ======================================================

def get_real_cell(ws, cell_ref):
    for merged_range in ws.merged_cells.ranges:
        if cell_ref in merged_range:
            min_col, min_row, max_col, max_row = merged_range.bounds
            return ws.cell(row=min_row, column=min_col)

    return ws[cell_ref]


def set_cell(ws, cell_ref, value, bold=False, size=10, align="left"):
    cell = get_real_cell(ws, cell_ref)
    cell.value = value
    cell.font = Font(bold=bold, size=size)
    cell.alignment = Alignment(
        horizontal=align,
        vertical="center",
        wrap_text=True
    )
    return cell


def make_border():
    thin = Side(style="thin", color="000000")
    return Border(left=thin, right=thin, top=thin, bottom=thin)


def apply_border(ws, start_row, start_col, end_row, end_col):
    border = make_border()

    for row in ws.iter_rows(
        min_row=start_row,
        max_row=end_row,
        min_col=start_col,
        max_col=end_col
    ):
        for cell in row:
            cell.border = border
            cell.alignment = Alignment(
                horizontal=cell.alignment.horizontal or "center",
                vertical="center",
                wrap_text=True
            )


# ======================================================
# CREATE FORM 3A EXCEL OUTPUT
# ======================================================

def set_cell(ws, cell_ref, value, bold=False, size=10, align="left", valign="center", underline=False):
    cell = get_real_cell(ws, cell_ref)
    cell.value = value
    cell.font = Font(name="Arial", bold=bold, size=size, underline="single" if underline else None)
    cell.alignment = Alignment(
        horizontal=align,
        vertical=valign,
        wrap_text=True
    )
    return cell


def apply_outer_border(ws, start_row, start_col, end_row, end_col):
    medium = Side(style="medium", color="000000")

    for col in range(start_col, end_col + 1):
        ws.cell(start_row, col).border = Border(
            top=medium,
            left=ws.cell(start_row, col).border.left,
            right=ws.cell(start_row, col).border.right,
            bottom=ws.cell(start_row, col).border.bottom,
        )
        ws.cell(end_row, col).border = Border(
            bottom=medium,
            left=ws.cell(end_row, col).border.left,
            right=ws.cell(end_row, col).border.right,
            top=ws.cell(end_row, col).border.top,
        )

    for row in range(start_row, end_row + 1):
        ws.cell(row, start_col).border = Border(
            left=medium,
            top=ws.cell(row, start_col).border.top,
            right=ws.cell(row, start_col).border.right,
            bottom=ws.cell(row, start_col).border.bottom,
        )
        ws.cell(row, end_col).border = Border(
            right=medium,
            top=ws.cell(row, end_col).border.top,
            left=ws.cell(row, end_col).border.left,
            bottom=ws.cell(row, end_col).border.bottom,
        )


def create_form3a_excel(details, monthly_rows, excel_path, full_text="", table_rows=None):
    wb = Workbook()
    ws = wb.active
    ws.title = "FORM 3A"

    ws.sheet_view.showGridLines = False
    ws.sheet_view.zoomScale = 85

    ws.page_setup.orientation = "portrait"
    ws.page_setup.paperSize = ws.PAPERSIZE_A4
    ws.page_setup.fitToPage = True
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 1

    ws.page_margins.left = 0.2
    ws.page_margins.right = 0.2
    ws.page_margins.top = 0.25
    ws.page_margins.bottom = 0.25

    # Widths are tuned to make the downloaded Excel look like a Form 3A sheet.
    column_widths = {
        "A": 24,
        "B": 15,
        "C": 13,
        "D": 15,
        "E": 16,
        "F": 12,
        "G": 17,
        "H": 20,
    }

    for col, width in column_widths.items():
        ws.column_dimensions[col].width = width

    for row_no in range(1, 70):
        ws.row_dimensions[row_no].height = 18

    ws.row_dimensions[1].height = 20
    ws.row_dimensions[2].height = 20
    ws.row_dimensions[3].height = 18
    ws.row_dimensions[4].height = 24
    ws.row_dimensions[8].height = 28
    ws.row_dimensions[9].height = 28
    ws.row_dimensions[14].height = 28
    ws.row_dimensions[15].height = 28
    ws.row_dimensions[16].height = 28
    ws.row_dimensions[17].height = 28
    ws.row_dimensions[20].height = 30
    ws.row_dimensions[21].height = 46
    ws.row_dimensions[22].height = 20

    # ==================================================
    # HEADER - same visual style as the sample screenshot
    # ==================================================

    ws.merge_cells("A1:G1")
    set_cell(
        ws,
        "A1",
        "Form No.3A (Revised) ( See Paragraphs 35 & 42 of the Employees Provident Funds Scheme , 1952)",
        bold=True,
        size=11,
        align="center"
    )
    set_cell(ws, "H1", "S.No\n1", bold=True, size=10, align="center")

    ws.merge_cells("A2:H2")
    set_cell(
        ws,
        "A2",
        "(See Paragraph 19 of the Employees Pension Scheme , 1995)",
        size=10,
        align="center"
    )

    ws.merge_cells("A3:H3")
    set_cell(
        ws,
        "A3",
        "(FOR UNEXEMPTED ESTABLISHMENTS ONLY)",
        bold=True,
        size=11,
        align="center"
    )

    ws.merge_cells("A4:H4")
    set_cell(
        ws,
        "A4",
        "Contribution Card for the Currency Period from 1st April 2025 to 31st March 2026",
        bold=True,
        size=11,
        align="center"
    )

    # ==================================================
    # TOP DETAILS
    # ==================================================

    highlight_fill = PatternFill("solid", fgColor="FFF2CC")

    set_cell(ws, "A6", "1 Account No.")
    ws.merge_cells("B6:D6")
    account_cell = set_cell(ws, "B6", details.get("account_no", ""), bold=True)
    account_cell.fill = highlight_fill
    for row in ws["B6:D6"]:
        for cell in row:
            cell.fill = highlight_fill

    set_cell(ws, "A7", "   UAN")
    ws.merge_cells("B7:D7")
    uan_cell = set_cell(ws, "B7", details.get("uan", ""), bold=True)
    uan_cell.fill = highlight_fill
    for row in ws["B7:D7"]:
        for cell in row:
            cell.fill = highlight_fill

    set_cell(ws, "A8", "2 Name / Surname")
    set_cell(ws, "A9", "   (in Block Capitals)")
    ws.merge_cells("B8:D9")
    set_cell(ws, "B8", details.get("name", ""))

    set_cell(ws, "A11", "3 Father's/Husband's")
    set_cell(ws, "A12", "   Name")
    ws.merge_cells("B11:D12")
    set_cell(ws, "B11", details.get("father_name", ""))

    set_cell(ws, "A14", "4 Name & Address")
    set_cell(ws, "A15", "   of the Factory/")
    ws.merge_cells("B14:D17")
    set_cell(ws, "B14", details.get("factory_address", ""), valign="top")

    set_cell(ws, "A18", "   Establishment ID")
    ws.merge_cells("B18:D18")
    set_cell(ws, "B18", details.get("establishment_id", ""))

    ws.merge_cells("E6:G6")
    set_cell(ws, "E6", "5 Statutory rate of Contribution")
    set_cell(ws, "H6", details.get("statutory_rate", "12%"), bold=True, underline=True, align="center")

    ws.merge_cells("E8:G9")
    set_cell(ws, "E8", "6 Voluntary higher rate of employee's\n   contribution if any")
    ws.merge_cells("H8:H9")
    set_cell(ws, "H8", details.get("higher_rate_employee", "NO"), bold=True, underline=True, align="center")

    ws.merge_cells("E10:G11")
    set_cell(ws, "E10", "7 Employer contribution on Hr. wages to\n   EPF (ER) Y/N")
    ws.merge_cells("H10:H11")
    set_cell(ws, "H10", details.get("higher_rate_employer", "NO"), bold=True, underline=True, align="center")

    ws.merge_cells("E12:G13")
    set_cell(ws, "E12", "8 Voluntary contribution to Pension Y/N")
    ws.merge_cells("H12:H13")
    set_cell(ws, "H12", details.get("higher_rate_pension", "NO"), bold=True, underline=True, align="center")

    # ==================================================
    # TABLE HEADER
    # ==================================================

    ws.merge_cells("A20:A22")
    set_cell(ws, "A20", "Months", bold=True, align="center")

    ws.merge_cells("B20:C20")
    set_cell(ws, "B20", "Employees' Share", bold=True, align="center")

    ws.merge_cells("D20:E20")
    set_cell(ws, "D20", "Employer's share", bold=True, align="center")

    ws.merge_cells("F20:F21")
    set_cell(ws, "F20", "Refund of\nadvance", bold=True, align="center")

    ws.merge_cells("G20:G21")
    set_cell(ws, "G20", "No.of days /\nperiod of non-\ncontributing\nservice if any", bold=True, align="center")

    ws.merge_cells("H20:H21")
    set_cell(ws, "H20", "Remarks", bold=True, align="center")

    set_cell(ws, "B21", "Amount of\nWages", bold=True, align="center")
    set_cell(ws, "C21", "EPF", bold=True, align="center")
    set_cell(ws, "D21", "EPF&8-1/3%\nif any", bold=True, align="center")
    set_cell(ws, "E21", "Pension fund\ncontri 8-1/3%", bold=True, align="center")

    column_numbers = ["1", "2", "3", "4(A)", "4(B)", "5", "6", "7"]

    for col_index, number in enumerate(column_numbers, start=1):
        cell_ref = ws.cell(row=22, column=col_index).coordinate
        set_cell(ws, cell_ref, number, bold=False, align="center")

    # ==================================================
    # MONTHLY DATA
    # ==================================================

    data_start = 23
    minimum_month_rows = 12
    total_data_rows = max(minimum_month_rows, len(monthly_rows))

    for i in range(total_data_rows):
        excel_row = data_start + i
        ws.row_dimensions[excel_row].height = 18

        if i < len(monthly_rows):
            item = monthly_rows[i]
        else:
            item = {
                "month": "",
                "wages": 0,
                "epf": 0,
                "epf_833": 0,
                "pension": 0,
                "refund": 0,
                "non_contribution_days": 0,
                "remarks": "",
            }

        set_cell(ws, f"A{excel_row}", item["month"])
        ws[f"B{excel_row}"] = item["wages"]
        ws[f"C{excel_row}"] = item["epf"]
        ws[f"D{excel_row}"] = item["epf_833"]
        ws[f"E{excel_row}"] = item["pension"]
        ws[f"F{excel_row}"] = "-" if not item.get("refund") else item["refund"]
        ws[f"G{excel_row}"] = item["non_contribution_days"]

        for col in range(2, 6):
            cell = ws.cell(row=excel_row, column=col)
            cell.number_format = "0.00"
            cell.alignment = Alignment(horizontal="right", vertical="center")

        ws[f"G{excel_row}"].number_format = "0.00"
        ws[f"G{excel_row}"].alignment = Alignment(horizontal="right", vertical="center")
        ws[f"F{excel_row}"].alignment = Alignment(horizontal="center", vertical="center")

    # Remarks block as shown in the Form 3A sample.
    if total_data_rows >= 12:
        ws.merge_cells(start_row=data_start, start_column=8, end_row=data_start + 5, end_column=8)
        set_cell(ws, f"H{data_start}", "a) Date of\nleaving", align="center", valign="top")
        ws.merge_cells(start_row=data_start + 6, start_column=8, end_row=data_start + 11, end_column=8)
        set_cell(ws, f"H{data_start + 6}", "b) Reasons\nfor leaving", align="center", valign="top")

    # ==================================================
    # TOTAL ROW
    # ==================================================

    total_row = data_start + total_data_rows
    ws.row_dimensions[total_row].height = 22

    set_cell(ws, f"A{total_row}", "TOTAL", bold=True)

    for col in [2, 3, 4, 5, 7]:
        col_letter = get_column_letter(col)
        cell = ws[f"{col_letter}{total_row}"]
        cell.value = f"=SUM({col_letter}{data_start}:{col_letter}{total_row - 1})"
        cell.font = Font(name="Arial", bold=True, size=10)
        cell.number_format = "0.00"
        cell.alignment = Alignment(horizontal="right", vertical="center")

    ws[f"F{total_row}"] = "-"
    ws[f"F{total_row}"].alignment = Alignment(horizontal="center", vertical="center")

    # ==================================================
    # CERTIFICATION AREA
    # ==================================================

    cert_row = total_row + 2
    ws.row_dimensions[cert_row].height = 34
    ws.row_dimensions[cert_row + 1].height = 24

    ws.merge_cells(start_row=cert_row, start_column=1, end_row=cert_row + 1, end_column=5)
    set_cell(
        ws,
        f"A{cert_row}",
        "Certified that the total amount of contribution (both shares) indicated in this card i.e.,\n"
        "has already been remitted in full in EPF A/C No.1 and Pension Fund A/C No.10",
        align="left",
        valign="top"
    )

    set_cell(ws, f"F{cert_row}", "RS.", bold=True, align="center")
    ws.merge_cells(start_row=cert_row, start_column=7, end_row=cert_row, end_column=8)
    epf_total_cell = set_cell(ws, f"G{cert_row}", f"=C{total_row}+D{total_row}", bold=True, align="center")
    epf_total_cell.number_format = "0.00"

    pension_cell = set_cell(ws, f"E{cert_row + 1}", f"=E{total_row}", bold=True, underline=True, align="center")
    pension_cell.number_format = "0.00"
    ws.merge_cells(start_row=cert_row + 1, start_column=6, end_row=cert_row + 1, end_column=8)
    set_cell(ws, f"F{cert_row + 1}", "(vide below)", align="left")

    cert_row_2 = cert_row + 4
    ws.row_dimensions[cert_row_2].height = 44

    ws.merge_cells(start_row=cert_row_2, start_column=1, end_row=cert_row_2 + 2, end_column=8)
    set_cell(
        ws,
        f"A{cert_row_2}",
        "Certified that the difference between the total of the contributions shown under columns(3) and 4(a) & 4(b) of the above\n"
        "table and that arrived at on the total wages shown in Col(2) at the prescribed rate is solely due to rounding off of\n"
        "contribution to the nearest rupee under the rules.",
        align="left",
        valign="top"
    )

    sign_row = cert_row_2 + 5
    ws.row_dimensions[sign_row].height = 28

    company_name = details.get("company_name") or "TRICORE SOLUTIONS PRIVATE LIMITED"

    ws.merge_cells(start_row=sign_row, start_column=5, end_row=sign_row, end_column=8)
    set_cell(ws, f"E{sign_row}", f"For {company_name},", bold=True, align="center")

    date_row = sign_row + 4
    set_cell(ws, f"A{date_row}", "Dated")
    set_cell(ws, f"B{date_row}", details.get("date", ""), bold=True, align="center")

    ws.merge_cells(start_row=date_row, start_column=6, end_row=date_row, end_column=8)
    set_cell(ws, f"F{date_row}", "Authorised Signatory", bold=True, align="center")

    note_row = date_row + 3
    ws.row_dimensions[note_row].height = 46
    ws.row_dimensions[note_row + 1].height = 34

    ws.merge_cells(start_row=note_row, start_column=1, end_row=note_row + 2, end_column=8)
    set_cell(
        ws,
        f"A{note_row}",
        "Note:- In respect of Form 3(A) sent to the Regional Office during the Course of the Currency period for the purpose of\n"
        "final settlement of the accounts of the member who had left service details of date and reason for leaving service.\n"
        "Should be furnished under column7(A) & (B)\n"
        "In respect of those who are not members of the Pension Fund the employers share of contribution to the EPF\n"
        "will be  8-1/3 or 10 % as the case may be and is to be shown under Column 4(b).",
        align="left",
        valign="top"
    )

    final_row = note_row + 2

    apply_border(ws, 1, 1, final_row, 8)
    apply_outer_border(ws, 1, 1, final_row, 8)

    for row in ws.iter_rows(min_row=1, max_row=final_row, min_col=1, max_col=8):
        for cell in row:
            if cell.font.name != "Arial":
                cell.font = Font(name="Arial", bold=cell.font.bold, size=cell.font.sz or 10)

    ws.print_area = f"A1:H{final_row}"
    ws.freeze_panes = f"A{data_start}"

    # Do not create any extra sheet. Save only the main Form 3A sheet.
    wb.save(excel_path)


# ======================================================
# FLASK ROUTES
# ======================================================

@app.route("/")
def home():
    return render_template("index.html")


@app.route("/convert", methods=["POST"])
def convert_pdf():
    # Accept either the new multi-upload field "pdfs" or the old single field "pdf".
    files = request.files.getlist("pdfs")

    if not files:
        single_file = request.files.get("pdf")
        files = [single_file] if single_file else []

    files = [file for file in files if file and file.filename]

    if not files:
        return jsonify({"error": "Please select at least one PDF file"}), 400

    if len(files) > 5:
        return jsonify({"error": "Maximum 5 PDF files are allowed at one time"}), 400

    for file in files:
        if not file.filename.lower().endswith(".pdf"):
            return jsonify({"error": f"Only PDF files are allowed: {file.filename}"}), 400

    batch_id = uuid.uuid4().hex
    converted_files = []
    failed_files = []

    for file_index, file in enumerate(files, start=1):
        safe_name = secure_filename(file.filename)
        uploaded_pdf_name = f"{batch_id}_{file_index}_{safe_name}"
        uploaded_pdf_path = UPLOAD_DIR / uploaded_pdf_name
        file.save(uploaded_pdf_path)

        try:
            # Extract only first page. Page index 0 means first page.
            text = extract_pdf_text(uploaded_pdf_path, page_number=0)
            table_rows = extract_pdf_tables(uploaded_pdf_path, page_number=0)

            details = parse_basic_details(text, table_rows)
            monthly_rows = parse_monthly_rows(table_rows, text)

            excel_name = f"{Path(safe_name).stem}_form3a_{batch_id}_{file_index}.xlsx"
            excel_path = OUTPUT_DIR / excel_name

            create_form3a_excel(details, monthly_rows, excel_path, full_text=text, table_rows=table_rows)

            converted_files.append({
                "original_name": safe_name,
                "excel_name": excel_name,
                "details": details,
                "monthly_rows": monthly_rows,
                "download_url": f"/download/{excel_name}",
                "pdf_index": file_index - 1,
                "status": "success",
            })

        except Exception as error:
            failed_files.append({
                "original_name": safe_name,
                "error": str(error),
                "pdf_index": file_index - 1,
                "status": "failed",
            })

    if not converted_files:
        return jsonify({
            "error": "No PDF could be converted",
            "failed_files": failed_files,
        }), 500

    # Create one ZIP containing all generated workbooks.
    # This is safer than forcing 5 separate browser downloads, which Chrome may block.
    zip_name = f"form3a_workbooks_{batch_id}.zip"
    zip_path = OUTPUT_DIR / zip_name

    with ZipFile(zip_path, "w", ZIP_DEFLATED) as zip_file:
        used_names = set()

        for item in converted_files:
            excel_path = OUTPUT_DIR / item["excel_name"]
            arcname = item["excel_name"]

            # Avoid duplicate names inside the zip.
            if arcname in used_names:
                arcname = f"{Path(item['excel_name']).stem}_{len(used_names) + 1}.xlsx"

            used_names.add(arcname)
            zip_file.write(excel_path, arcname=arcname)

    first = converted_files[0]

    return jsonify({
        "message": f"{len(converted_files)} workbook(s) created successfully",
        "files": converted_files,
        "failed_files": failed_files,
        "details": first["details"],
        "monthly_rows": first["monthly_rows"],
        "download_url": first["download_url"],
        "download_all_url": f"/download/{zip_name}",
    })

@app.route("/download/<filename>")
def download_excel(filename):
    return send_from_directory(
        OUTPUT_DIR,
        filename,
        as_attachment=True
    )


if __name__ == "__main__":
    app.run(debug=True)
