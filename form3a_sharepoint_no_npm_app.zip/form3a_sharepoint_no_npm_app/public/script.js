const recordsBody = document.getElementById("recordsBody");
const searchInput = document.getElementById("searchInput");
const statusFilter = document.getElementById("statusFilter");
const refreshBtn = document.getElementById("refreshBtn");
const statusBox = document.getElementById("statusBox");
const loadingModal = document.getElementById("loadingModal");
const lastUpdated = document.getElementById("lastUpdated");

let records = [];

function showLoading(show) {
  loadingModal.classList.toggle("hidden", !show);
}

function setStatus(message) {
  statusBox.textContent = message;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function linkHtml(url, label) {
  if (!url) return "-";
  return `<a class="link" href="${escapeHtml(url)}" target="_blank" rel="noopener noreferrer">${label}</a>`;
}

function statusBadge(status) {
  const safe = escapeHtml(status || "");
  if (!safe) return "-";
  return `<span class="badge ${safe}">${safe}</span>`;
}

function formatDate(value) {
  if (!value) return "";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString();
}

function updateCounts(filteredRecords) {
  document.getElementById("totalCount").textContent = records.length;
  document.getElementById("completedCount").textContent = records.filter(x => x.status === "Completed").length;
  document.getElementById("convertingCount").textContent = records.filter(x => x.status === "Converting").length;
  document.getElementById("pendingCount").textContent = records.filter(x => x.status === "Pending").length;
  document.getElementById("failedCount").textContent = records.filter(x => x.status === "Failed").length;
}

function getFilteredRecords() {
  const query = searchInput.value.trim().toLowerCase();
  const status = statusFilter.value;

  return records.filter(record => {
    const matchesStatus = !status || record.status === status;
    const searchText = [
      record.title,
      record.uan,
      record.accountNo,
      record.name,
      record.addedBy,
      record.status
    ].join(" ").toLowerCase();
    const matchesQuery = !query || searchText.includes(query);
    return matchesStatus && matchesQuery;
  });
}

function render() {
  const filtered = getFilteredRecords();
  updateCounts(filtered);

  if (!filtered.length) {
    recordsBody.innerHTML = `<tr><td colspan="9" class="empty">No records found</td></tr>`;
    return;
  }

  recordsBody.innerHTML = filtered.map(record => `
    <tr>
      <td>${escapeHtml(record.title)}</td>
      <td>${escapeHtml(record.uan)}</td>
      <td>${escapeHtml(record.accountNo)}</td>
      <td><strong>${escapeHtml(record.name)}</strong></td>
      <td>${escapeHtml(record.addedBy)}</td>
      <td>${statusBadge(record.status)}</td>
      <td>${linkHtml(record.excelLink, "Open Excel")}</td>
      <td>${linkHtml(record.pdf, "Open PDF")}</td>
      <td>${escapeHtml(formatDate(record.addedAt))}</td>
    </tr>
  `).join("");
}

async function loadRecords() {
  showLoading(true);
  setStatus("Fetching records from SharePoint...");

  try {
    const response = await fetch("/api/records", { cache: "no-store" });
    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || "Failed to fetch records");
    }

    records = data.records || [];
    render();
    lastUpdated.textContent = `Last updated: ${new Date().toLocaleTimeString()}`;
    setStatus(`Loaded ${records.length} record(s) from SharePoint.`);
  } catch (error) {
    recordsBody.innerHTML = `<tr><td colspan="9" class="empty">${escapeHtml(error.message)}</td></tr>`;
    setStatus(error.message);
  } finally {
    showLoading(false);
  }
}

refreshBtn.addEventListener("click", loadRecords);
searchInput.addEventListener("input", render);
statusFilter.addEventListener("change", render);

loadRecords();
setInterval(loadRecords, 15000);
