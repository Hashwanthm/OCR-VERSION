// FORM 3A SharePoint configuration
// Fill these values from Microsoft Entra / Graph Explorer.
// This app uses only built-in Node.js modules. No npm install needed.

module.exports = {
  PORT: 3000,

  TENANT_ID: "",          // Example: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
  CLIENT_ID: "",          // App registration client/application id
  CLIENT_SECRET: "",      // Client secret value

  SHAREPOINT_HOSTNAME: "adponlineind-my.sharepoint.com",
  SHAREPOINT_SITE_PATH: "/personal/mhaswanth_ad_esi_adp_com",
  FORM3A_LIST_NAME: "FORM 3A"
};
