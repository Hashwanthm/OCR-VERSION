const http = require("http");
const https = require("https");
const fs = require("fs");
const path = require("path");
const { URL } = require("url");
const config = require("./config");

const PUBLIC_DIR = path.join(__dirname, "public");

let tokenCache = {
  accessToken: null,
  expiresAt: 0
};

function sendJson(res, statusCode, data) {
  const body = JSON.stringify(data, null, 2);
  res.writeHead(statusCode, {
    "Content-Type": "application/json",
    "Cache-Control": "no-store"
  });
  res.end(body);
}

function sendText(res, statusCode, text) {
  res.writeHead(statusCode, { "Content-Type": "text/plain" });
  res.end(text);
}

function getContentType(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  if (ext === ".html") return "text/html; charset=utf-8";
  if (ext === ".css") return "text/css; charset=utf-8";
  if (ext === ".js") return "application/javascript; charset=utf-8";
  if (ext === ".json") return "application/json; charset=utf-8";
  if (ext === ".png") return "image/png";
  if (ext === ".jpg" || ext === ".jpeg") return "image/jpeg";
  return "application/octet-stream";
}

function serveStatic(res, requestPath) {
  let filePath = requestPath === "/" ? "/index.html" : requestPath;
  filePath = path.normalize(filePath).replace(/^([.][.][/\\])+/, "");
  const fullPath = path.join(PUBLIC_DIR, filePath);

  if (!fullPath.startsWith(PUBLIC_DIR)) {
    sendText(res, 403, "Forbidden");
    return;
  }

  fs.readFile(fullPath, (err, data) => {
    if (err) {
      sendText(res, 404, "File not found");
      return;
    }
    res.writeHead(200, { "Content-Type": getContentType(fullPath) });
    res.end(data);
  });
}

function httpsRequest(method, requestUrl, headers = {}, body = null) {
  return new Promise((resolve, reject) => {
    const parsedUrl = new URL(requestUrl);
    const options = {
      method,
      hostname: parsedUrl.hostname,
      path: parsedUrl.pathname + parsedUrl.search,
      headers
    };

    const req = https.request(options, (res) => {
      let data = "";
      res.on("data", (chunk) => { data += chunk; });
      res.on("end", () => {
        let parsed = data;
        try {
          parsed = data ? JSON.parse(data) : {};
        } catch (_) {}

        if (res.statusCode >= 200 && res.statusCode < 300) {
          resolve(parsed);
        } else {
          reject({
            statusCode: res.statusCode,
            response: parsed,
            url: requestUrl
          });
        }
      });
    });

    req.on("error", reject);

    if (body) {
      req.write(body);
    }
    req.end();
  });
}

function validateConfig() {
  const missing = [];
  ["TENANT_ID", "CLIENT_ID", "CLIENT_SECRET", "SHAREPOINT_HOSTNAME", "SHAREPOINT_SITE_PATH", "FORM3A_LIST_NAME"].forEach((key) => {
    if (!config[key]) missing.push(key);
  });
  return missing;
}

async function getGraphToken() {
  const now = Date.now();
  if (tokenCache.accessToken && tokenCache.expiresAt > now + 60000) {
    return tokenCache.accessToken;
  }

  const missing = validateConfig();
  if (missing.length) {
    throw new Error("Missing config values: " + missing.join(", "));
  }

  const tokenUrl = `https://login.microsoftonline.com/${config.TENANT_ID}/oauth2/v2.0/token`;
  const body = new URLSearchParams({
    client_id: config.CLIENT_ID,
    client_secret: config.CLIENT_SECRET,
    scope: "https://graph.microsoft.com/.default",
    grant_type: "client_credentials"
  }).toString();

  const tokenResponse = await httpsRequest("POST", tokenUrl, {
    "Content-Type": "application/x-www-form-urlencoded",
    "Content-Length": Buffer.byteLength(body)
  }, body);

  tokenCache.accessToken = tokenResponse.access_token;
  tokenCache.expiresAt = now + ((tokenResponse.expires_in || 3600) * 1000);
  return tokenCache.accessToken;
}

async function graphGet(url) {
  const token = await getGraphToken();
  return httpsRequest("GET", url, {
    Authorization: `Bearer ${token}`,
    Accept: "application/json"
  });
}

function graphSiteUrl() {
  return `https://graph.microsoft.com/v1.0/sites/${config.SHAREPOINT_HOSTNAME}:${config.SHAREPOINT_SITE_PATH}`;
}

async function getSite() {
  return graphGet(graphSiteUrl());
}

async function getLists(siteId) {
  return graphGet(`https://graph.microsoft.com/v1.0/sites/${encodeURIComponent(siteId)}/lists?$select=id,displayName,name,webUrl`);
}

async function getForm3AList(siteId) {
  const listsResponse = await getLists(siteId);
  const list = (listsResponse.value || []).find((item) =>
    String(item.displayName || "").toLowerCase() === String(config.FORM3A_LIST_NAME).toLowerCase()
  );

  if (!list) {
    throw new Error(`List not found: ${config.FORM3A_LIST_NAME}`);
  }
  return list;
}

async function getFields(siteId, listId) {
  return graphGet(`https://graph.microsoft.com/v1.0/sites/${encodeURIComponent(siteId)}/lists/${encodeURIComponent(listId)}/columns?$select=name,displayName,text,choice,dateTime,personOrGroup,hyperlinkOrPicture`);
}

async function getItems(siteId, listId) {
  return graphGet(`https://graph.microsoft.com/v1.0/sites/${encodeURIComponent(siteId)}/lists/${encodeURIComponent(listId)}/items?$expand=fields&$top=200`);
}

function normalizeName(value) {
  return String(value || "")
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "");
}

function buildFieldMap(columns) {
  const map = {};
  for (const column of columns) {
    const displayKey = normalizeName(column.displayName);
    const nameKey = normalizeName(column.name);
    if (displayKey) map[displayKey] = column.name;
    if (nameKey) map[nameKey] = column.name;
  }
  return map;
}

function getByDisplay(fields, fieldMap, names) {
  for (const name of names) {
    const key = fieldMap[normalizeName(name)];
    if (key && fields[key] !== undefined) return fields[key];
  }

  for (const name of names) {
    if (fields[name] !== undefined) return fields[name];
  }

  return "";
}

function normalizeLink(value) {
  if (!value) return "";
  if (typeof value === "string") return value;
  if (value.Url) return value.Url;
  if (value.url) return value.url;
  return "";
}

function mapItem(item, fieldMap) {
  const fields = item.fields || {};
  return {
    id: item.id,
    title: getByDisplay(fields, fieldMap, ["Title"]),
    uan: getByDisplay(fields, fieldMap, ["UAN"]),
    accountNo: getByDisplay(fields, fieldMap, ["ACCOUNT NO", "Account No", "ACCOUNTNO"]),
    name: getByDisplay(fields, fieldMap, ["NAME", "Name"]),
    addedBy: getByDisplay(fields, fieldMap, ["ADDED BY", "Added By", "ADDEDBY"]),
    status: getByDisplay(fields, fieldMap, ["STATUS", "Status"]),
    excelLink: normalizeLink(getByDisplay(fields, fieldMap, ["EXCEL LINK", "Excel Link", "EXCELLINK"])),
    pdf: normalizeLink(getByDisplay(fields, fieldMap, ["PDF"])),
    addedAt: getByDisplay(fields, fieldMap, ["ADDED AT", "Added At", "ADDEDAT"])
  };
}

async function handleApi(req, res, pathname) {
  try {
    if (pathname === "/api/health") {
      const missing = validateConfig();
      sendJson(res, 200, {
        ok: missing.length === 0,
        message: missing.length ? "Config missing" : "Server running",
        missing,
        node: process.version
      });
      return;
    }

    if (pathname === "/api/setup/site") {
      const site = await getSite();
      sendJson(res, 200, site);
      return;
    }

    if (pathname === "/api/setup/lists") {
      const site = await getSite();
      const lists = await getLists(site.id);
      sendJson(res, 200, {
        site: { id: site.id, webUrl: site.webUrl },
        lists: lists.value || []
      });
      return;
    }

    if (pathname === "/api/setup/fields") {
      const site = await getSite();
      const list = await getForm3AList(site.id);
      const fields = await getFields(site.id, list.id);
      sendJson(res, 200, {
        site: { id: site.id, webUrl: site.webUrl },
        list,
        columns: fields.value || []
      });
      return;
    }

    if (pathname === "/api/records") {
      const site = await getSite();
      const list = await getForm3AList(site.id);
      const fields = await getFields(site.id, list.id);
      const fieldMap = buildFieldMap(fields.value || []);
      const items = await getItems(site.id, list.id);
      const records = (items.value || []).map((item) => mapItem(item, fieldMap));
      sendJson(res, 200, {
        count: records.length,
        records
      });
      return;
    }

    sendJson(res, 404, { error: "API route not found" });
  } catch (error) {
    sendJson(res, 500, {
      error: error.message || "API error",
      details: error.response || error
    });
  }
}

const server = http.createServer((req, res) => {
  const parsedUrl = new URL(req.url, `http://${req.headers.host}`);
  const pathname = parsedUrl.pathname;

  if (pathname.startsWith("/api/")) {
    handleApi(req, res, pathname);
    return;
  }

  serveStatic(res, pathname);
});

server.listen(config.PORT, () => {
  console.log(`FORM 3A SharePoint app running at http://localhost:${config.PORT}`);
  console.log("No npm install required. Fill config.js before connecting to SharePoint.");
});
