# FORM 3A SharePoint Dashboard - No npm install version

This version uses only built-in Node.js modules.

## Why this version

Your laptop showed:

```text
npm ERR! 503 Service Unavailable - GET https://registry.npmjs.org/dotenv
```

That means npm is trying to download packages from outside internet and your network/company may block it.

This version does not need `npm install`.

## How to run

1. Open `config.js`.
2. Fill:

```js
TENANT_ID: "",
CLIENT_ID: "",
CLIENT_SECRET: "",
SHAREPOINT_HOSTNAME: "adponlineind-my.sharepoint.com",
SHAREPOINT_SITE_PATH: "/personal/mhaswanth_ad_esi_adp_com",
FORM3A_LIST_NAME: "FORM 3A"
```

3. Run:

```bash
node server.js
```

4. Open:

```text
http://localhost:3000
```

## Test URLs

```text
http://localhost:3000/api/health
http://localhost:3000/api/setup/site
http://localhost:3000/api/setup/lists
http://localhost:3000/api/setup/fields
http://localhost:3000/api/records
```

## SharePoint columns supported

- Title
- UAN
- ACCOUNT NO
- NAME
- ADDED BY
- STATUS
- EXCEL LINK
- PDF
- ADDED AT

## Required Microsoft Graph permissions

For reading list data:

- Sites.Read.All

For later write/upload:

- Sites.ReadWrite.All

Admin consent may be required by your company.
