const pdfInput = document.getElementById("pdfInput");
const convertBtn = document.getElementById("convertBtn");
const pdfArea = document.getElementById("pdfArea");
const excelArea = document.getElementById("excelArea");
const statusBox = document.getElementById("status");
const downloadBtn = document.getElementById("downloadBtn");
const downloadAllBtn = document.getElementById("downloadAllBtn");
const pdfCount = document.getElementById("pdfCount");
const pdfSelector = document.getElementById("pdfSelector");
const loadingModal = document.getElementById("loadingModal");
const loadingText = document.getElementById("loadingText");
const workbookName = document.getElementById("workbookName");

let selectedFiles = [];
let selectedPdfUrls = [];
let convertedFiles = [];
let failedFiles = [];
let activeIndex = 0;

updatePdfCount(0);
resetPdfSelector();
setConvertAvailability();

function updatePdfCount(count) {
  if (pdfCount) {
    pdfCount.textContent = `${count} / 5 PDFs selected`;
  }
}

function setConvertAvailability() {
  if (!convertBtn) return;

  convertBtn.disabled = selectedFiles.length !== 5;
}

function resetPdfSelector() {
  if (pdfSelector) {
    pdfSelector.innerHTML = `<option>No file selected</option>`;
    pdfSelector.disabled = true;
  }

  updateWorkbookName(null);
}

function updatePdfSelector() {
  if (!pdfSelector) return;

  if (!selectedFiles.length) {
    resetPdfSelector();
    return;
  }

  pdfSelector.disabled = false;
  pdfSelector.innerHTML = selectedFiles.map((file, index) => {
    const converted = getConvertedByPdfIndex(index);
    const failed = getFailedByPdfIndex(index);
    const status = converted ? "✅" : failed ? "❌" : "📄";
    const workbookLabel = converted
      ? ` → Excel: ${converted.excel_name}`
      : failed
        ? " → Excel: failed"
        : " → Excel: pending";

    return `<option value="${index}">${status} PDF ${index + 1}: ${escapeHtml(file.name)}${escapeHtml(workbookLabel)}</option>`;
  }).join("");

  pdfSelector.value = String(activeIndex);
}

if (pdfSelector) {
  pdfSelector.addEventListener("change", function () {
    const index = Number(pdfSelector.value || 0);
    selectPdf(index);
  });
}

function showLoading(message) {
  if (loadingText) {
    loadingText.textContent = message || "Please wait. Reading first page and creating 5 Form 3A workbooks.";
  }

  if (loadingModal) {
    loadingModal.style.display = "flex";
  }
}

function hideLoading() {
  if (loadingModal) {
    loadingModal.style.display = "none";
  }
}

function basicDuplicateFileCheck(files) {
  const seen = new Map();

  for (const file of files) {
    const key = `${file.name.toLowerCase()}-${file.size}`;

    if (seen.has(key)) {
      return {
        hasDuplicate: true,
        firstName: seen.get(key),
        duplicateName: file.name
      };
    }

    seen.set(key, file.name);
  }

  return { hasDuplicate: false };
}

async function findDuplicatePdf(files) {
  // Compare actual file content. This catches renamed duplicate PDFs also.
  // If browser hashing is unavailable, fall back to a basic filename + size check.
  if (!window.crypto || !window.crypto.subtle) {
    return basicDuplicateFileCheck(files);
  }

  const seenHashes = new Map();

  for (const file of files) {
    const buffer = await file.arrayBuffer();
    const hashBuffer = await window.crypto.subtle.digest("SHA-256", buffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hash = hashArray.map(byte => byte.toString(16).padStart(2, "0")).join("");

    if (seenHashes.has(hash)) {
      return {
        hasDuplicate: true,
        firstName: seenHashes.get(hash),
        duplicateName: file.name
      };
    }

    seenHashes.set(hash, file.name);
  }

  return { hasDuplicate: false };
}

function getSelectedNumberHtml() {
  if (!selectedFiles.length) return "";

  return `
    <div class="upload-number-box">
      Uploaded PDFs: ${selectedFiles.length} / 5 required &nbsp; | &nbsp;
      Current selection: PDF ${activeIndex + 1} - ${escapeHtml(selectedFiles[activeIndex]?.name || "")}
    </div>
  `;
}

function getPairingHtml(index) {
  if (!selectedFiles.length) return "";

  const pdfName = selectedFiles[index]?.name || "";
  const converted = getConvertedByPdfIndex(index);
  const failed = getFailedByPdfIndex(index);

  let workbookText = "Excel workbook will appear after Convert";

  if (converted) {
    workbookText = converted.excel_name || "Workbook created";
  } else if (failed) {
    workbookText = `Workbook failed: ${failed.error || "Unknown error"}`;
  }

  return `
    <div class="pairing-box">
      <span>Dropdown selected:</span>
      <strong>PDF ${index + 1}</strong>
      <span>${escapeHtml(pdfName)}</span>
      <span>⇨</span>
      <strong>Equivalent Excel</strong>
      <span>${escapeHtml(workbookText)}</span>
    </div>
  `;
}

function updateWorkbookName(index) {
  if (!workbookName) return;

  if (index === null || index === undefined || !selectedFiles.length) {
    workbookName.textContent = "No workbook selected";
    workbookName.title = "";
    return;
  }

  const converted = getConvertedByPdfIndex(index);
  const failed = getFailedByPdfIndex(index);

  if (converted) {
    workbookName.textContent = `Selected: ${converted.excel_name}`;
    workbookName.title = converted.excel_name;
  } else if (failed) {
    workbookName.textContent = `Selected: PDF ${index + 1} failed`;
    workbookName.title = failed.error || "Conversion failed";
  } else {
    workbookName.textContent = `Selected: PDF ${index + 1} workbook pending`;
    workbookName.title = selectedFiles[index]?.name || "";
  }
}

pdfInput.addEventListener("change", async function () {
  selectedFiles = Array.from(pdfInput.files || []);
  convertedFiles = [];
  failedFiles = [];
  activeIndex = 0;

  downloadBtn.style.display = "none";
  downloadBtn.href = "#";
  downloadAllBtn.style.display = "none";
  downloadAllBtn.href = "#";
  updateWorkbookName(null);

  if (selectedFiles.length > 5) {
    pdfInput.value = "";
    selectedFiles = [];
    selectedPdfUrls.forEach(url => URL.revokeObjectURL(url));
    selectedPdfUrls = [];
    updatePdfCount(0);
    resetPdfSelector();
    setConvertAvailability();
    setStatus("Please upload exactly 5 PDF files at the same time. More than 5 files are not allowed.", "error");
    pdfArea.innerHTML = `<div class="empty">Select exactly 5 different PDF files.</div>`;
    excelArea.innerHTML = `<div class="empty">Remove extra files and upload again.</div>`;
    return;
  }

  const duplicateCheck = await findDuplicatePdf(selectedFiles);
  if (duplicateCheck.hasDuplicate) {
    pdfInput.value = "";
    selectedFiles = [];
    selectedPdfUrls.forEach(url => URL.revokeObjectURL(url));
    selectedPdfUrls = [];
    updatePdfCount(0);
    resetPdfSelector();
    setConvertAvailability();
    setStatus(`Duplicate PDF detected: ${duplicateCheck.firstName} and ${duplicateCheck.duplicateName}. Please upload 5 different PDF files at the same time.`, "error");
    pdfArea.innerHTML = `<div class="empty">Upload 5 different PDF files.</div>`;
    excelArea.innerHTML = `<div class="empty">Converted Form 3A preview will appear here.</div>`;
    return;
  }

  if (selectedFiles.some(file => file.type !== "application/pdf" && !file.name.toLowerCase().endsWith(".pdf"))) {
    pdfInput.value = "";
    selectedFiles = [];
    selectedPdfUrls.forEach(url => URL.revokeObjectURL(url));
    selectedPdfUrls = [];
    updatePdfCount(0);
    resetPdfSelector();
    setConvertAvailability();
    setStatus("Only PDF files are allowed.", "error");
    pdfArea.innerHTML = `<div class="empty">Upload PDF files only.</div>`;
    excelArea.innerHTML = `<div class="empty">Converted Form 3A preview will appear here.</div>`;
    return;
  }

  selectedPdfUrls.forEach(url => URL.revokeObjectURL(url));
  selectedPdfUrls = selectedFiles.map(file => URL.createObjectURL(file));
  updatePdfCount(selectedFiles.length);
  updatePdfSelector();
  setConvertAvailability();

  if (!selectedFiles.length) {
    updatePdfCount(0);
    resetPdfSelector();
    pdfArea.innerHTML = `
      <div class="empty">
        Select 5 different PDF files at the same time to preview them here.
      </div>
    `;
    excelArea.innerHTML = `
      <div class="empty">
        Converted Form 3A preview will appear here.
      </div>
    `;
    setStatus("Ready", "");
    return;
  }

  selectPdf(0);

  if (selectedFiles.length === 5) {
    setStatus("5 different PDF files selected at the same time. Click Convert to create 5 Excel workbooks.", "success");
  } else {
    setStatus(`Only ${selectedFiles.length} PDF file(s) selected. Please select 5 different PDF files at the same time.`, "error");
  }
});

convertBtn.addEventListener("click", async function () {
  if (!selectedFiles.length) {
    setStatus("Please select 5 PDF files first.", "error");
    return;
  }

  if (selectedFiles.length !== 5) {
    setStatus(`Please upload exactly 5 different PDF files. Currently selected: ${selectedFiles.length}.`, "error");
    return;
  }

  const duplicateCheck = await findDuplicatePdf(selectedFiles);
  if (duplicateCheck.hasDuplicate) {
    setStatus(`Duplicate PDF detected: ${duplicateCheck.firstName} and ${duplicateCheck.duplicateName}. Please upload 5 different PDF files.`, "error");
    return;
  }

  const formData = new FormData();
  selectedFiles.forEach(file => formData.append("pdfs", file));

  convertBtn.disabled = true;
  convertBtn.textContent = "Converting...";
  downloadBtn.style.display = "none";
  downloadAllBtn.style.display = "none";

  showLoading("Converting 5 PDF files. Reading first page only and creating 5 Form 3A workbooks...");
  setStatus("Reading first page of 5 PDF files and preparing 5 Form 3A workbooks...", "");

  try {
    const response = await fetch("/convert", {
      method: "POST",
      body: formData
    });

    const result = await response.json();

    if (!response.ok) {
      throw new Error(result.error || "Conversion failed");
    }

    convertedFiles = result.files || [];
    failedFiles = result.failed_files || [];

    if (convertedFiles.length !== 5) {
      throw new Error(result.error || `Only ${convertedFiles.length} of 5 workbooks were created.`);
    }

    downloadAllBtn.href = result.download_all_url || "#";
    downloadAllBtn.style.display = result.download_all_url ? "inline-block" : "none";

    updatePdfSelector();
    selectPdf(activeIndex);

    const failedCount = failedFiles.length;
    const message = failedCount
      ? `${convertedFiles.length} workbook(s) created. ${failedCount} PDF(s) failed. Use dropdown to check each PDF.`
      : "5 workbooks created successfully. Download all as one ZIP, or use Download Workbook for the selected PDF.";

    setStatus(message, failedCount ? "error" : "success");

  } catch (error) {
    excelArea.innerHTML = `
      <div class="empty">
        Conversion failed.
      </div>
    `;

    setStatus(error.message, "error");

  } finally {
    hideLoading();
    convertBtn.disabled = false;
    convertBtn.textContent = "Convert";
  }
});

function selectPdf(index) {
  if (!selectedFiles.length) return;

  activeIndex = Math.max(0, Math.min(index, selectedFiles.length - 1));
  updateWorkbookName(activeIndex);
  updatePdfSelector();
  renderPdfPreview(activeIndex);
  renderExcelPreviewForPdf(activeIndex);
}

function renderPdfPreview(index) {
  const pdfUrl = selectedPdfUrls[index];

  pdfArea.innerHTML = `
    ${getSelectedNumberHtml()}
    ${getPairingHtml(index)}
    <iframe
      class="pdf-preview"
      src="${pdfUrl}#page=1&toolbar=1&navpanes=0&view=FitH"
      title="First page PDF preview">
    </iframe>
  `;
}

function renderExcelPreviewForPdf(pdfIndex) {
  const converted = getConvertedByPdfIndex(pdfIndex);
  const failed = getFailedByPdfIndex(pdfIndex);

  if (converted) {
    excelArea.innerHTML = `
      ${getSelectedNumberHtml()}
      ${getPairingHtml(pdfIndex)}
      <div id="formPreviewHolder"></div>
    `;

    const holder = document.getElementById("formPreviewHolder");
    holder.innerHTML = renderForm3AHtml(converted.details || {}, converted.monthly_rows || []);

    if (converted.download_url) {
      downloadBtn.href = converted.download_url;
      downloadBtn.style.display = "inline-block";
    }
    return;
  }

  downloadBtn.style.display = "none";
  downloadBtn.href = "#";

  if (failed) {
    excelArea.innerHTML = `
      ${getSelectedNumberHtml()}
      ${getPairingHtml(pdfIndex)}
      <div class="empty">
        Conversion failed for PDF ${pdfIndex + 1}.<br>
        ${escapeHtml(failed.error || "Unknown error")}
      </div>
    `;
    return;
  }

  excelArea.innerHTML = `
    ${getSelectedNumberHtml()}
    ${getPairingHtml(pdfIndex)}
    <div class="empty">
      Select 5 different PDFs at the same time, then click Convert.<br>
      One Excel workbook will be created for each PDF.
    </div>
  `;
}

function getConvertedByPdfIndex(pdfIndex) {
  return convertedFiles.find(item => Number(item.pdf_index) === Number(pdfIndex));
}

function getFailedByPdfIndex(pdfIndex) {
  return failedFiles.find(item => Number(item.pdf_index) === Number(pdfIndex));
}

function renderForm3AHtml(details, monthlyRows) {
  const rows = [...monthlyRows];

  while (rows.length < 12) {
    rows.push({
      month: "",
      wages: 0,
      epf: 0,
      epf_833: 0,
      pension: 0,
      refund: 0,
      non_contribution_days: 0,
      remarks: ""
    });
  }

  const totals = rows.reduce((acc, row) => {
    acc.wages += toNumber(row.wages);
    acc.epf += toNumber(row.epf);
    acc.epf833 += toNumber(row.epf_833);
    acc.pension += toNumber(row.pension);
    acc.days += toNumber(row.non_contribution_days);
    return acc;
  }, { wages: 0, epf: 0, epf833: 0, pension: 0, days: 0 });

  const companyName = details.company_name || "TRICORE SOLUTIONS PRIVATE LIMITED";
  const name = cleanPreviewName(details.name || "");

  const bodyRows = rows.map((row, index) => {
    const remark = index === 0
      ? `a) Date of<br>leaving`
      : index === 6
        ? `b) Reasons<br>for leaving`
        : "";

    return `
      <tr>
        <td class="month-cell">${escapeHtml(row.month || "")}</td>
        <td class="num">${formatAmount(row.wages)}</td>
        <td class="num">${formatAmount(row.epf)}</td>
        <td class="num">${formatAmount(row.epf_833)}</td>
        <td class="num">${formatAmount(row.pension)}</td>
        <td class="center">-</td>
        <td class="num">${formatAmount(row.non_contribution_days)}</td>
        <td class="remarks-cell">${remark}</td>
      </tr>
    `;
  }).join("");

  return `
    <div class="form-preview-wrap">
      <section class="form3a-sheet">
        <div class="form3a-topline">
          <strong>Form No.3A (Revised)</strong>
          <span>( See Paragraphs 35 &amp; 42 of the Employees Provident Funds Scheme , 1952)</span>
        </div>
        <div class="form3a-title">(See Paragraph 19 of the Employees Pension Scheme , 1995)</div>
        <div class="form3a-title bold">(FOR UNEXEMPTED ESTABLISHMENTS ONLY)</div>
        <div class="form3a-title bold period-title">Contribution Card for the Currency Period from 1st April 2025 to 31st March 2026</div>

        <div class="details-layout">
          <div class="left-details">
            <div class="detail-row"><div>1 Account No.</div><div class="highlight-value">${escapeHtml(details.account_no || "")}</div></div>
            <div class="detail-row"><div>&nbsp;&nbsp;&nbsp;UAN</div><div class="highlight-value">${escapeHtml(details.uan || "")}</div></div>
            <div class="detail-row name-row"><div>2 Name / Surname<br><span>(in Block Capitals)</span></div><div class="strong-name">${escapeHtml(name)}</div></div>
            <div class="detail-row father-row"><div>3 Father's/Husband's<br><span>Name</span></div><div>${escapeHtml(details.father_name || "")}</div></div>
            <div class="detail-row address-row"><div>4 Name &amp; Address<br><span>of the Factory/</span></div><div>${escapeHtml(details.factory_address || companyName)}</div></div>
            <div class="detail-row"><div>&nbsp;&nbsp;&nbsp;Establishment ID</div><div>${escapeHtml(details.establishment_id || "")}</div></div>
          </div>

          <div class="right-details">
            <div class="right-detail-line"><span>5 Statutory rate of Contribution</span><strong>${escapeHtml(details.statutory_rate || "12%")}</strong></div>
            <div class="right-detail-line tall"><span>6 Voluntary higher rate of employee's<br>&nbsp;&nbsp;&nbsp;contribution if any</span><strong>NO</strong></div>
            <div class="right-detail-line tall"><span>7 Employer contribution on Hr. wages to<br>&nbsp;&nbsp;&nbsp;EPF (ER) Y/N</span><strong>NO</strong></div>
            <div class="right-detail-line"><span>8 Voluntary contribution to Pension Y/N</span><strong>NO</strong></div>
          </div>
        </div>

        <table class="form3a-table">
          <thead>
            <tr>
              <th rowspan="2">Months</th>
              <th colspan="2">Employees' Share</th>
              <th colspan="2">Employer's share</th>
              <th rowspan="2">Refund of<br>advance</th>
              <th rowspan="2">No.of days /<br>period of non-<br>contributing<br>service if any</th>
              <th rowspan="2">Remarks</th>
            </tr>
            <tr>
              <th>Amount of<br>Wages</th>
              <th>EPF</th>
              <th>EPF&amp;8-1/3%<br>if any</th>
              <th>Pension fund<br>contri 8-1/3%</th>
            </tr>
            <tr class="col-num-row">
              <th>1</th><th>2</th><th>3</th><th>4(A)</th><th>4(B)</th><th>5</th><th>6</th><th>7</th>
            </tr>
          </thead>
          <tbody>
            ${bodyRows}
            <tr class="total-row">
              <td>TOTAL</td>
              <td class="num">${formatAmount(totals.wages)}</td>
              <td class="num">${formatAmount(totals.epf)}</td>
              <td class="num">${formatAmount(totals.epf833)}</td>
              <td class="num">${formatAmount(totals.pension)}</td>
              <td class="center">-</td>
              <td class="num">${formatAmount(totals.days)}</td>
              <td></td>
            </tr>
          </tbody>
        </table>

        <div class="cert-box">
          <div class="cert-left">
            Certified that the total amount of contribution (both shares) indicated in this card i.e.,<br>
            has already been remitted in full in EPF A/C No.1 and Pension Fund A/C No.10
          </div>
          <div class="cert-amount">
            <strong>RS.</strong>
            <strong>${formatAmount(totals.epf + totals.epf833)}</strong><br>
            <span class="pension-line">${formatAmount(totals.pension)}</span>
            <span>(vide below)</span>
          </div>
        </div>

        <div class="rounding-note">
          Certified that the difference between the total of the contributions shown under columns(3) and 4(a) &amp; 4(b) of the above<br>
          table and that arrived at on the total wages shown in Col(2) at the prescribed rate is solely due to rounding off of<br>
          contribution to the nearest rupee under the rules.
        </div>

        <div class="signature-row">
          <div></div>
          <strong>For ${escapeHtml(companyName)},</strong>
        </div>

        <div class="dated-row">
          <div>Dated</div>
          <strong>${escapeHtml(details.date || "")}</strong>
          <strong>Authorised Signatory</strong>
        </div>

        <div class="note-text">
          Note:- In respect of Form 3(A) sent to the Regional Office during the Course of the Currency period for the purpose of<br>
          final settlement of the accounts of the member who had left service details of date and reason for leaving service.<br>
          Should be furnished under column7(A) &amp; (B)<br>
          In respect of those who are not members of the Pension Fund the employers share of contribution to the EPF<br>
          will be&nbsp;&nbsp; 8-1/3 or 10 % as the case may be and is to be shown under Column 4(b).
        </div>
      </section>
    </div>
  `;
}

function cleanPreviewName(value) {
  let text = String(value || "").replace(/[^A-Za-z.\s]/g, " ").replace(/\s+/g, " ").trim();
  text = text.replace(/\b(TUE|FRFFK|LFKKIUK|IKKCQD|VKBZMH)\b/gi, "").replace(/\s+/g, " ").trim();
  const words = text.split(" ").filter(Boolean);
  if (words.length > 4) {
    return words.slice(0, 4).join(" ").toUpperCase();
  }
  return text.toUpperCase();
}

function toNumber(value) {
  const number = Number(value || 0);
  return Number.isFinite(number) ? number : 0;
}

function formatAmount(value) {
  return toNumber(value).toFixed(2);
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function setStatus(message, type) {
  statusBox.textContent = message;
  statusBox.className = "status";

  if (type) {
    statusBox.classList.add(type);
  }
}
