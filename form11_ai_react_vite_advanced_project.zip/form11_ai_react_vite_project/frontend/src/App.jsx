import { useMemo, useState } from "react";
import { Download, FileSpreadsheet, ScanText, UploadCloud, AlertTriangle } from "lucide-react";
import { downloadUrl, exportRecords, extractFiles } from "./api";

const FIELD_LABELS = {
  member_name: "Name of Member",
  father_husband_name: "Father / Husband Name",
  date_of_birth: "Date of Birth",
  gender: "Gender",
  marital_status: "Marital Status",
  email: "Email ID",
  mobile: "Mobile Number",
  uan: "UAN",
  aadhaar: "Aadhaar Number",
  pan: "PAN",
  bank_account_no: "Bank Account Number",
  ifsc: "IFSC Code",
  previous_pf_account_no: "Previous PF Account No",
  establishment_name: "Establishment / Company Name",
  date_of_joining: "Date of Joining",
  nationality: "Nationality",
};

function uppercaseRecord(record) {
  const fields = {};
  Object.entries(record.fields || {}).forEach(([key, value]) => {
    fields[key] = String(value || "").toUpperCase();
  });
  return { ...record, fields };
}

function confidenceClass(score) {
  if (score >= 0.85) return "good";
  if (score >= 0.65) return "medium";
  return "low";
}

export default function App() {
  const [files, setFiles] = useState([]);
  const [records, setRecords] = useState([]);
  const [activeIndex, setActiveIndex] = useState(0);
  const [loading, setLoading] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [error, setError] = useState("");
  const [extractErrors, setExtractErrors] = useState([]);

  const activeRecord = records[activeIndex];
  const fileCountText = `${files.length} / 10 selected`;

  const doubtfulCount = useMemo(() => {
    return records.reduce((sum, rec) => sum + Object.keys(rec.warnings || {}).length, 0);
  }, [records]);

  function handleFiles(selected) {
    const incoming = Array.from(selected || []);
    setError("");

    if (incoming.length > 10) {
      setError("Maximum 10 files allowed at a time.");
      return;
    }

    const allowed = incoming.filter((file) => {
      const name = file.name.toLowerCase();
      return /\.(pdf|png|jpg|jpeg|tif|tiff|bmp|webp)$/.test(name);
    });

    if (allowed.length !== incoming.length) {
      setError("Only PDF and image files are allowed.");
    }

    setFiles(allowed.slice(0, 10));
    setRecords([]);
    setActiveIndex(0);
  }

  async function runExtraction() {
    if (files.length === 0) {
      setError("Upload at least one Form 11 PDF/image.");
      return;
    }

    setLoading(true);
    setError("");
    setExtractErrors([]);

    try {
      const data = await extractFiles(files);
      setRecords((data.results || []).map(uppercaseRecord));
      setExtractErrors(data.errors || []);
      setActiveIndex(0);
    } catch (err) {
      setError(err.message || "Extraction failed");
    } finally {
      setLoading(false);
    }
  }

  function updateField(recordIndex, key, value) {
    setRecords((prev) =>
      prev.map((rec, idx) => {
        if (idx !== recordIndex) return rec;
        return {
          ...rec,
          fields: {
            ...rec.fields,
            [key]: value.toUpperCase(),
          },
        };
      })
    );
  }

  async function downloadExcel() {
    if (records.length === 0) return;

    setDownloading(true);
    setError("");
    try {
      const data = await exportRecords(records.map(uppercaseRecord));
      window.location.href = downloadUrl(data.downloadToken);
    } catch (err) {
      setError(err.message || "Download failed");
    } finally {
      setDownloading(false);
    }
  }

  return (
    <div className="app-shell">
      <header className="hero">
        <div>
          <p className="eyebrow">Offline AI PDF / OCR to Excel</p>
          <h1>Form 11 AI Extractor</h1>
          <p className="hero-text">
            Upload Form 11 PDFs or scanned images, extract values using direct PDF extraction or AI OCR, review fields, and download Excel in capital letters.
          </p>
        </div>
        <div className="hero-card">
          <ScanText size={30} />
          <strong>Hybrid AI Flow</strong>
          <span>PDF text + PaddleOCR + OpenCV + Excel</span>
        </div>
      </header>

      <section className="toolbar">
        <label className="upload-box">
          <UploadCloud size={22} />
          <span>Upload Form 11 files</span>
          <input
            type="file"
            multiple
            accept=".pdf,.png,.jpg,.jpeg,.tif,.tiff,.bmp,.webp"
            onChange={(event) => handleFiles(event.target.files)}
          />
        </label>

        <span className="count-badge">{fileCountText}</span>

        <button className="primary" disabled={files.length === 0 || loading} onClick={runExtraction}>
          {loading ? "Extracting..." : "Extract Data"}
        </button>

        <button className="success" disabled={records.length === 0 || downloading} onClick={downloadExcel}>
          <Download size={18} />
          {records.length > 1 ? "Download ZIP" : "Download Excel"}
        </button>
      </section>

      {files.length > 0 && (
        <section className="file-strip">
          {files.map((file, index) => (
            <div className="file-chip" key={`${file.name}-${index}`}>
              <FileSpreadsheet size={16} />
              <span>{file.name}</span>
            </div>
          ))}
        </section>
      )}

      {error && <div className="error-box">{error}</div>}

      {extractErrors.length > 0 && (
        <div className="warning-box">
          <AlertTriangle size={18} />
          <div>
            <strong>Some files were skipped</strong>
            {extractErrors.map((item, index) => (
              <p key={index}>{item.filename}: {item.error}</p>
            ))}
          </div>
        </div>
      )}

      <main className="workspace">
        <aside className="record-list">
          <h2>Extracted Files</h2>
          {records.length === 0 ? (
            <p className="muted">No extraction yet.</p>
          ) : (
            records.map((record, index) => (
              <button
                className={`record-button ${index === activeIndex ? "active" : ""}`}
                key={record.id}
                onClick={() => setActiveIndex(index)}
              >
                <span>{record.filename}</span>
                <small className={confidenceClass(record.confidence)}>{Math.round(record.confidence * 100)}%</small>
              </button>
            ))
          )}
        </aside>

        <section className="review-panel">
          {!activeRecord ? (
            <div className="empty-state">
              <ScanText size={52} />
              <h2>Upload and extract Form 11 data</h2>
              <p>After extraction, review every field before downloading Excel.</p>
            </div>
          ) : (
            <>
              <div className="panel-header">
                <div>
                  <h2>{activeRecord.filename}</h2>
                  <p>
                    Source: <strong>{activeRecord.source}</strong> · Confidence: <strong>{Math.round(activeRecord.confidence * 100)}%</strong>
                  </p>
                </div>
                <div className="warning-pill">
                  {Object.keys(activeRecord.warnings || {}).length} doubtful fields
                </div>
              </div>

              {doubtfulCount > 0 && (
                <div className="note">
                  OCR can make mistakes for handwritten data. Red fields should be checked before Excel download.
                </div>
              )}

              <div className="field-grid">
                {Object.entries(FIELD_LABELS).map(([key, label]) => {
                  const warning = activeRecord.warnings?.[key];
                  return (
                    <label className={`field-card ${warning ? "has-warning" : ""}`} key={key}>
                      <span>{label}</span>
                      <input
                        value={activeRecord.fields?.[key] || ""}
                        onChange={(event) => updateField(activeIndex, key, event.target.value)}
                      />
                      {warning && <small>{warning}</small>}
                    </label>
                  );
                })}
              </div>

              <details className="raw-text">
                <summary>Show raw extracted text</summary>
                <pre>{activeRecord.rawText || "No raw text extracted."}</pre>
              </details>
            </>
          )}
        </section>
      </main>
    </div>
  );
}
