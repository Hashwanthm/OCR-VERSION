const API_BASE = import.meta.env.VITE_API_BASE || "http://127.0.0.1:8000";

export async function extractFiles(files) {
  const formData = new FormData();
  files.forEach((file) => formData.append("files", file));

  const response = await fetch(`${API_BASE}/api/extract`, {
    method: "POST",
    body: formData,
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({}));
    throw new Error(JSON.stringify(error.detail || error || "Extraction failed"));
  }

  return response.json();
}

export async function exportRecords(records) {
  const response = await fetch(`${API_BASE}/api/export`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ records }),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({}));
    throw new Error(JSON.stringify(error.detail || error || "Export failed"));
  }

  return response.json();
}

export function downloadUrl(token) {
  return `${API_BASE}/api/download/${token}`;
}
