# Form 11 AI PDF/OCR to Excel Extractor

A local/offline-ready Form 11 extraction project with:

- React JS + Vite frontend
- Python FastAPI backend
- Direct PDF text extraction for selectable PDFs
- AI OCR fallback for scanned/handwritten PDFs using PaddleOCR
- Optional advanced AI hooks for TrOCR, LayoutLMv3, Transformers, Sentence Transformers, and Unstructured
- OpenCV preprocessing for better OCR quality
- Review/edit screen before Excel generation
- Values converted to CAPITAL LETTERS before exporting
- Excel/ZIP download

## Important accuracy note

Handwritten OCR is not 100% automatic. This project extracts the data and shows a review screen. The user should verify fields before downloading Excel.

Best quality input:

- 300 DPI scan
- Straight document
- No shadows
- Black or blue ink
- Clear handwriting
- One form per PDF/image

## Folder structure

```text
form11_ai_react_vite_project/
  backend/
    app.py
    requirements.txt
    requirements-ai.txt
    install_backend.bat
    install_ai_cpu.bat
    run_backend.bat
    src/
      extraction/
        ai_postprocess.py
        excel.py
        fields.py
        ocr_paddle.py
        ocr_trocr.py
        pdf_text.py
        preprocessing.py
  frontend/
    package.json
    index.html
    src/
      App.jsx
      api.js
      main.jsx
      styles.css
    run_frontend.bat
```

## Quick start

### 1. Backend

```bat
cd backend
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Backend opens at:

```text
http://127.0.0.1:8000
```

### 2. Frontend

Open another terminal:

```bat
cd frontend
npm install
npm run dev
```

Frontend opens at:

```text
http://127.0.0.1:5173
```

## Install advanced AI OCR libraries

For PaddleOCR + Transformers stack, run:

```bat
cd backend
venv\Scripts\activate
install_ai_cpu.bat
```

First OCR run may download model files. After models are downloaded, the app can run locally.

## Extraction flow

```text
Upload Form 11 PDF/image
  ↓
Try PyMuPDF/pdfplumber direct text extraction
  ↓
If text is weak or empty, use OpenCV + PaddleOCR
  ↓
Extract fields using regex/fuzzy matching
  ↓
Convert values to CAPITAL LETTERS
  ↓
Show review screen
  ↓
Download Excel/ZIP
```

## Main libraries

Core:

- FastAPI
- PyMuPDF
- pdfplumber
- OpenCV
- Pillow
- NumPy
- Pandas
- OpenPyXL
- RapidFuzz

AI/OCR:

- PaddleOCR
- PaddlePaddle
- PyTorch
- Transformers
- Sentence Transformers
- Unstructured

## Notes

- Direct selectable PDF extraction is usually more accurate than OCR.
- OCR is used when the PDF is scanned/image-based.
- For handwritten forms, always review extracted values before Excel download.
