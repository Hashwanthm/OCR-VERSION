from __future__ import annotations

import os
import shutil
import tempfile
import uuid
from pathlib import Path
from typing import Dict, List

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel

from src.extraction.excel import create_form11_workbook, create_zip
from src.extraction.fields import extract_form11_fields, confidence_from_fields
from src.extraction.ocr_paddle import PaddleOCRService
from src.extraction.pdf_text import extract_selectable_text, looks_like_strong_text

MAX_FILES = 10
ALLOWED_EXTENSIONS = {".pdf", ".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".webp"}

app = FastAPI(title="Form 11 AI OCR Extractor", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:5173", "http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

STORE: Dict[str, Dict] = {}
DOWNLOADS: Dict[str, str] = {}
ocr_service = PaddleOCRService(lang="en")


class ExportRequest(BaseModel):
    records: List[Dict]


def save_upload(upload: UploadFile) -> str:
    suffix = Path(upload.filename or "").suffix.lower()
    if suffix not in ALLOWED_EXTENSIONS:
        raise HTTPException(status_code=400, detail=f"Unsupported file type: {suffix}")
    temp_dir = Path(tempfile.mkdtemp(prefix="form11_upload_"))
    out_path = temp_dir / f"{uuid.uuid4().hex}{suffix}"
    with out_path.open("wb") as f:
        shutil.copyfileobj(upload.file, f)
    return out_path.as_posix()


def extract_one(file_path: str, filename: str) -> Dict:
    text, source = extract_selectable_text(file_path)
    used_ocr = False
    ocr_confidence = 0.0
    warnings: Dict[str, str] = {}

    if not looks_like_strong_text(text):
        try:
            text, ocr_confidence, _lines = ocr_service.read_file(file_path)
            source = "paddleocr"
            used_ocr = True
        except Exception as exc:
            # Continue with whatever selectable text was found and tell the user.
            warnings["ocr"] = str(exc).upper()

    fields, field_warnings = extract_form11_fields(text)
    warnings.update(field_warnings)
    confidence = confidence_from_fields(fields, ocr_confidence, used_ocr)

    result = {
        "id": uuid.uuid4().hex,
        "filename": filename,
        "source": source.upper(),
        "usedOcr": used_ocr,
        "confidence": confidence,
        "fields": fields,
        "warnings": warnings,
        "rawText": text,
    }
    STORE[result["id"]] = result
    return result


@app.get("/api/health")
def health() -> Dict:
    return {"status": "ok", "maxFiles": MAX_FILES}


@app.post("/api/extract")
async def extract(files: List[UploadFile] = File(...)) -> Dict:
    if not files:
        raise HTTPException(status_code=400, detail="Upload at least one file")
    if len(files) > MAX_FILES:
        raise HTTPException(status_code=400, detail=f"Maximum {MAX_FILES} files allowed")

    results = []
    errors = []
    seen_names = set()

    for upload in files:
        filename = upload.filename or "uploaded_file"
        lower_name = filename.lower()
        if lower_name in seen_names:
            errors.append({"filename": filename, "error": "Duplicate filename skipped"})
            continue
        seen_names.add(lower_name)

        try:
            path = save_upload(upload)
            results.append(extract_one(path, filename))
        except Exception as exc:
            errors.append({"filename": filename, "error": str(exc)})

    if not results and errors:
        raise HTTPException(status_code=400, detail=errors)

    return {"results": results, "errors": errors}


@app.post("/api/export")
def export_records(payload: ExportRequest) -> Dict:
    if not payload.records:
        raise HTTPException(status_code=400, detail="No records to export")

    paths: List[str] = []
    for record in payload.records:
        record_id = record.get("id")
        original = STORE.get(record_id, {}) if record_id else {}
        merged = {**original, **record}
        paths.append(create_form11_workbook(merged))

    if len(paths) == 1:
        download_path = paths[0]
    else:
        download_path = create_zip(paths)

    token = uuid.uuid4().hex
    DOWNLOADS[token] = download_path
    return {"downloadToken": token, "filename": Path(download_path).name}


@app.get("/api/download/{token}")
def download(token: str):
    path = DOWNLOADS.get(token)
    if not path or not Path(path).exists():
        raise HTTPException(status_code=404, detail="Download not found")
    return FileResponse(
        path,
        filename=Path(path).name,
        media_type="application/octet-stream",
    )


if __name__ == "__main__":
    import uvicorn

    host = os.getenv("HOST", "127.0.0.1")
    port = int(os.getenv("PORT", "8000"))
    uvicorn.run("app:app", host=host, port=port, reload=True)
