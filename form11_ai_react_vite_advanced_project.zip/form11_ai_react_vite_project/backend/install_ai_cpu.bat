@echo off
call venv\Scripts\activate
python -m pip install --upgrade pip setuptools wheel

echo Installing PaddlePaddle CPU...
python -m pip install paddlepaddle -i https://www.paddlepaddle.org.cn/packages/stable/cpu/

echo Installing PaddleOCR...
pip install paddleocr

echo Installing PyTorch CPU...
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu

echo Installing advanced AI document packages...
pip install transformers sentence-transformers huggingface-hub accelerate "unstructured[all-docs]" einops safetensors protobuf

echo.
echo Advanced AI libraries installed.
echo First run may download OCR/model files.
pause
