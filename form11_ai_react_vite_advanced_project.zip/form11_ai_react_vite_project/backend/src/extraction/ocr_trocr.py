from __future__ import annotations

from pathlib import Path
from typing import Optional


class TrOCRLineReader:
    """Optional handwritten line recognizer.

    TrOCR is useful when you crop one handwritten line/field first. It is not a
    full-form parser by itself. This class is included as an advanced AI hook.
    """

    def __init__(self, model_name: str = "microsoft/trocr-base-handwritten") -> None:
        self.model_name = model_name
        self.processor = None
        self.model = None

    def load(self) -> None:
        if self.processor is not None:
            return
        try:
            from transformers import TrOCRProcessor, VisionEncoderDecoderModel
        except Exception as exc:
            raise RuntimeError("Install transformers and torch to use TrOCR.") from exc

        self.processor = TrOCRProcessor.from_pretrained(self.model_name)
        self.model = VisionEncoderDecoderModel.from_pretrained(self.model_name)

    def read_line_image(self, image_path: str) -> str:
        from PIL import Image

        self.load()
        assert self.processor is not None and self.model is not None

        image = Image.open(Path(image_path)).convert("RGB")
        pixel_values = self.processor(images=image, return_tensors="pt").pixel_values
        generated_ids = self.model.generate(pixel_values)
        text = self.processor.batch_decode(generated_ids, skip_special_tokens=True)[0]
        return text.strip()
