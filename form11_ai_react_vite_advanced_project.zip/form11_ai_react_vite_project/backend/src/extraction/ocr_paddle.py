from __future__ import annotations

from dataclasses import dataclass
from typing import Any, List, Tuple

from .preprocessing import prepare_images_for_ocr, preprocess_image_for_ocr


@dataclass
class OCRLine:
    text: str
    confidence: float


class PaddleOCRService:
    """Lazy PaddleOCR wrapper.

    The wrapper supports older and newer PaddleOCR constructor styles.
    """

    def __init__(self, lang: str = "en") -> None:
        self.lang = lang
        self._ocr = None

    def _load(self) -> Any:
        if self._ocr is not None:
            return self._ocr

        try:
            from paddleocr import PaddleOCR
        except Exception as exc:
            raise RuntimeError(
                "PaddleOCR is not installed. Run install_ai_cpu.bat or install paddleocr/paddlepaddle."
            ) from exc

        # PaddleOCR v3 uses use_textline_orientation. Older versions use use_angle_cls.
        try:
            self._ocr = PaddleOCR(use_textline_orientation=True, lang=self.lang)
        except TypeError:
            self._ocr = PaddleOCR(use_angle_cls=True, lang=self.lang)
        return self._ocr

    def read_file(self, file_path: str) -> Tuple[str, float, List[OCRLine]]:
        ocr = self._load()
        images = prepare_images_for_ocr(file_path)
        all_lines: list[OCRLine] = []

        for image_path in images:
            clean_path = preprocess_image_for_ocr(image_path)
            page_lines = self._read_image(ocr, clean_path)
            all_lines.extend(page_lines)

        text = "\n".join(line.text for line in all_lines if line.text.strip())
        confidence = (
            sum(line.confidence for line in all_lines) / len(all_lines) if all_lines else 0.0
        )
        return text.strip(), round(confidence, 3), all_lines

    def _read_image(self, ocr: Any, image_path: str) -> List[OCRLine]:
        try:
            raw = ocr.ocr(image_path, cls=True)
        except TypeError:
            raw = ocr.ocr(image_path)
        except AttributeError:
            # Newer pipeline style fallback.
            raw = ocr.predict(image_path)

        return self._parse_result(raw)

    def _parse_result(self, raw: Any) -> List[OCRLine]:
        lines: list[OCRLine] = []

        def walk(node: Any) -> None:
            if node is None:
                return
            if isinstance(node, dict):
                # PaddleOCR 3 predict-style outputs can be dict-like.
                texts = node.get("rec_texts") or node.get("texts") or []
                scores = node.get("rec_scores") or node.get("scores") or []
                for index, text in enumerate(texts):
                    score = float(scores[index]) if index < len(scores) else 0.0
                    lines.append(OCRLine(str(text), score))
                return
            if isinstance(node, (list, tuple)):
                # Common older format: [box, (text, score)]
                if len(node) >= 2 and isinstance(node[1], (list, tuple)) and len(node[1]) >= 2:
                    maybe_text, maybe_score = node[1][0], node[1][1]
                    if isinstance(maybe_text, str):
                        try:
                            score = float(maybe_score)
                        except Exception:
                            score = 0.0
                        lines.append(OCRLine(maybe_text, score))
                        return
                for child in node:
                    walk(child)

        walk(raw)
        return lines
