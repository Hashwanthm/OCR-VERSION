from __future__ import annotations

from pathlib import Path
from typing import Tuple


def extract_with_pymupdf(file_path: str) -> str:
    """Fast selectable PDF text extraction using PyMuPDF."""
    try:
        import fitz  # PyMuPDF
    except Exception:
        return ""

    path = Path(file_path)
    if path.suffix.lower() != ".pdf":
        return ""

    chunks: list[str] = []
    try:
        with fitz.open(file_path) as doc:
            for page in doc:
                text = page.get_text("text") or ""
                chunks.append(text)
    except Exception:
        return ""

    return "\n".join(chunks).strip()


def extract_with_pdfplumber(file_path: str) -> str:
    """Useful fallback for selectable PDF text and simple tables."""
    try:
        import pdfplumber
    except Exception:
        return ""

    path = Path(file_path)
    if path.suffix.lower() != ".pdf":
        return ""

    chunks: list[str] = []
    try:
        with pdfplumber.open(file_path) as pdf:
            for page in pdf.pages:
                text = page.extract_text(x_tolerance=1, y_tolerance=3) or ""
                chunks.append(text)
    except Exception:
        return ""

    return "\n".join(chunks).strip()


def extract_selectable_text(file_path: str) -> Tuple[str, str]:
    """Return text and source name. OCR is handled separately."""
    pymupdf_text = extract_with_pymupdf(file_path)
    pdfplumber_text = extract_with_pdfplumber(file_path)

    candidates = [
        (pymupdf_text, "pymupdf"),
        (pdfplumber_text, "pdfplumber"),
    ]
    text, source = max(candidates, key=lambda item: len(item[0] or ""))
    return (text or "").strip(), source


def looks_like_strong_text(text: str, minimum_chars: int = 150) -> bool:
    if not text:
        return False
    compact = "".join(ch for ch in text if ch.isalnum())
    return len(compact) >= minimum_chars
