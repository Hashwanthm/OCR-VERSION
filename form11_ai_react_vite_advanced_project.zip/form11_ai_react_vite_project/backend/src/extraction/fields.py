from __future__ import annotations

import re
from typing import Dict, List, Tuple

from rapidfuzz import fuzz

from .ai_postprocess import uppercase_fields, validate_form11_fields, optional_transformer_cleanup

FIELD_KEYS = [
    "member_name",
    "father_husband_name",
    "date_of_birth",
    "gender",
    "marital_status",
    "email",
    "mobile",
    "uan",
    "aadhaar",
    "pan",
    "bank_account_no",
    "ifsc",
    "previous_pf_account_no",
    "establishment_name",
    "date_of_joining",
    "nationality",
]

LABELS = {
    "member_name": ["NAME", "NAME OF MEMBER", "MEMBER NAME", "EMPLOYEE NAME"],
    "father_husband_name": ["FATHER", "HUSBAND", "FATHER'S NAME", "HUSBAND'S NAME", "FATHER / HUSBAND"],
    "date_of_birth": ["DATE OF BIRTH", "DOB", "D.O.B"],
    "gender": ["GENDER", "SEX"],
    "marital_status": ["MARITAL STATUS", "MARRIED", "UNMARRIED"],
    "email": ["EMAIL", "EMAIL ID", "E-MAIL"],
    "mobile": ["MOBILE", "MOBILE NO", "PHONE", "CONTACT"],
    "uan": ["UAN", "UNIVERSAL ACCOUNT NUMBER"],
    "aadhaar": ["AADHAAR", "AADHAR", "AADHAAR NO", "AADHAR NO"],
    "pan": ["PAN", "PAN NO", "PERMANENT ACCOUNT NUMBER"],
    "bank_account_no": ["BANK ACCOUNT", "ACCOUNT NO", "BANK A/C", "SAVINGS ACCOUNT"],
    "ifsc": ["IFSC", "IFSC CODE"],
    "previous_pf_account_no": ["PREVIOUS PF", "PF ACCOUNT", "PREVIOUS ACCOUNT"],
    "establishment_name": ["ESTABLISHMENT", "COMPANY", "FACTORY", "NAME OF ESTABLISHMENT"],
    "date_of_joining": ["DATE OF JOINING", "DOJ", "JOINING DATE"],
    "nationality": ["NATIONALITY"],
}


def clean_text(text: str) -> str:
    text = text.replace("\r", "\n")
    text = re.sub(r"[\t ]+", " ", text)
    text = re.sub(r"\n{2,}", "\n", text)
    return text.strip()


def lines(text: str) -> List[str]:
    return [line.strip() for line in clean_text(text).splitlines() if line.strip()]


def after_label(line: str, label: str) -> str:
    pattern = rf"{re.escape(label)}\s*[:\-]?(.*)$"
    match = re.search(pattern, line, flags=re.IGNORECASE)
    if match:
        return match.group(1).strip(" :-_\t")
    return ""


def find_by_label(all_lines: List[str], key: str) -> str:
    labels = LABELS[key]
    for i, line in enumerate(all_lines):
        upper_line = line.upper()
        for label in labels:
            if label in upper_line:
                value = after_label(line, label)
                if value:
                    return value
                # Many forms have label in one line and value in next line.
                if i + 1 < len(all_lines):
                    nxt = all_lines[i + 1].strip()
                    if not looks_like_label(nxt):
                        return nxt
    return ""


def looks_like_label(text: str) -> bool:
    u = text.upper().strip()
    if len(u) > 45:
        return False
    best = 0
    for labels in LABELS.values():
        for label in labels:
            best = max(best, fuzz.partial_ratio(u, label))
    return best >= 85


def regex_extract(text: str) -> Dict[str, str]:
    compact = re.sub(r"\s+", " ", text)
    out = {key: "" for key in FIELD_KEYS}

    email = re.search(r"[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}", compact, re.I)
    if email:
        out["email"] = email.group(0)

    pan = re.search(r"\b[A-Z]{5}[0-9]{4}[A-Z]\b", compact, re.I)
    if pan:
        out["pan"] = pan.group(0)

    ifsc = re.search(r"\b[A-Z]{4}0[A-Z0-9]{6}\b", compact, re.I)
    if ifsc:
        out["ifsc"] = ifsc.group(0)

    # Find long numeric IDs.
    nums = re.findall(r"(?<!\d)(?:\d[\s\-]?){10,16}(?!\d)", compact)
    cleaned_nums = [re.sub(r"\D", "", n) for n in nums]

    for n in cleaned_nums:
        if len(n) == 12 and not out["uan"]:
            out["uan"] = n
            continue
        if len(n) == 12 and not out["aadhaar"]:
            out["aadhaar"] = n
            continue
        if len(n) == 10 and not out["mobile"]:
            out["mobile"] = n
            continue
        if 9 <= len(n) <= 18 and not out["bank_account_no"]:
            out["bank_account_no"] = n

    date_patterns = re.findall(
        r"\b(?:\d{1,2}[\/\-.]\d{1,2}[\/\-.]\d{2,4}|\d{4}[\/\-.]\d{1,2}[\/\-.]\d{1,2})\b",
        compact,
    )
    if date_patterns:
        out["date_of_birth"] = date_patterns[0]
    if len(date_patterns) > 1:
        out["date_of_joining"] = date_patterns[1]

    gender = re.search(r"\b(MALE|FEMALE|TRANSGENDER|M|F)\b", compact, re.I)
    if gender:
        out["gender"] = gender.group(1)

    marital = re.search(r"\b(MARRIED|UNMARRIED|SINGLE|DIVORCED|WIDOWED)\b", compact, re.I)
    if marital:
        out["marital_status"] = marital.group(1)

    return out


def extract_form11_fields(raw_text: str) -> Tuple[Dict[str, str], Dict[str, str]]:
    raw_text = clean_text(raw_text)
    all_lines = lines(raw_text)
    fields = regex_extract(raw_text)

    for key in FIELD_KEYS:
        value = find_by_label(all_lines, key)
        if value and len(value) >= 2:
            fields[key] = value

    # Cleanup common noisy label leftovers.
    for key, value in list(fields.items()):
        value = re.sub(r"^[\s:\-_/]+", "", str(value)).strip()
        value = re.sub(r"\s+", " ", value)
        fields[key] = value

    fields = optional_transformer_cleanup(raw_text, fields)
    fields = uppercase_fields(fields)
    warnings = validate_form11_fields(fields)
    return fields, warnings


def confidence_from_fields(fields: Dict[str, str], ocr_confidence: float, used_ocr: bool) -> float:
    filled = sum(1 for v in fields.values() if str(v).strip())
    coverage = filled / max(len(fields), 1)
    source_bonus = 0.25 if not used_ocr else max(ocr_confidence, 0.35) * 0.35
    score = min(0.99, 0.45 + coverage * 0.35 + source_bonus)
    return round(score, 3)
