from __future__ import annotations

import os
import re
from typing import Dict, Any


def uppercase_fields(fields: Dict[str, Any]) -> Dict[str, Any]:
    clean: Dict[str, Any] = {}
    for key, value in fields.items():
        if value is None:
            clean[key] = ""
        else:
            clean[key] = str(value).strip().upper()
    return clean


def normalize_numbers(text: str) -> str:
    # Common OCR confusions in numeric IDs.
    return (
        text.replace("O", "0")
        .replace("o", "0")
        .replace("I", "1")
        .replace("l", "1")
        .replace("S", "5")
    )


def validate_form11_fields(fields: Dict[str, str]) -> Dict[str, str]:
    warnings: Dict[str, str] = {}

    uan = re.sub(r"\D", "", normalize_numbers(fields.get("uan", "")))
    aadhaar = re.sub(r"\D", "", normalize_numbers(fields.get("aadhaar", "")))
    mobile = re.sub(r"\D", "", normalize_numbers(fields.get("mobile", "")))
    pan = fields.get("pan", "").replace(" ", "").upper()

    if uan and len(uan) != 12:
        warnings["uan"] = "UAN SHOULD BE 12 DIGITS"
    if aadhaar and len(aadhaar) != 12:
        warnings["aadhaar"] = "AADHAAR SHOULD BE 12 DIGITS"
    if mobile and len(mobile) != 10:
        warnings["mobile"] = "MOBILE SHOULD BE 10 DIGITS"
    if pan and not re.fullmatch(r"[A-Z]{5}[0-9]{4}[A-Z]", pan):
        warnings["pan"] = "PAN FORMAT LOOKS DOUBTFUL"

    return warnings


def optional_transformer_cleanup(raw_text: str, fields: Dict[str, str]) -> Dict[str, str]:
    """Optional local transformer cleanup hook.

    Disabled by default because it downloads a model. Set ENABLE_TRANSFORMER_CLEANUP=1
    to experiment with it. Regex + review screen remains the reliable default.
    """
    if os.getenv("ENABLE_TRANSFORMER_CLEANUP") != "1":
        return fields

    try:
        from transformers import pipeline
    except Exception:
        return fields

    try:
        prompt = (
            "Clean these Form 11 extracted fields. Return only KEY=VALUE lines.\n"
            f"RAW TEXT:\n{raw_text[:2500]}\n\nFIELDS:\n{fields}"
        )
        generator = pipeline("text2text-generation", model="google/flan-t5-small")
        output = generator(prompt, max_new_tokens=256)[0]["generated_text"]
        for line in output.splitlines():
            if "=" in line:
                key, value = line.split("=", 1)
                key = key.strip().lower().replace(" ", "_")
                if key in fields and value.strip():
                    fields[key] = value.strip()
    except Exception:
        return fields

    return fields
