from __future__ import annotations

import tempfile
from pathlib import Path
from typing import List

import cv2
import numpy as np
from PIL import Image

IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".webp"}


def pdf_to_images(file_path: str, dpi: int = 220) -> List[str]:
    """Render PDF pages to PNG images for OCR."""
    import fitz  # PyMuPDF

    output_paths: list[str] = []
    scale = dpi / 72
    matrix = fitz.Matrix(scale, scale)
    temp_dir = Path(tempfile.mkdtemp(prefix="form11_pages_"))

    with fitz.open(file_path) as doc:
        for page_index, page in enumerate(doc):
            pix = page.get_pixmap(matrix=matrix, alpha=False)
            output_path = temp_dir / f"page_{page_index + 1}.png"
            pix.save(output_path.as_posix())
            output_paths.append(output_path.as_posix())

    return output_paths


def image_to_png(file_path: str) -> str:
    """Normalize uploaded image into PNG for OCR."""
    temp_dir = Path(tempfile.mkdtemp(prefix="form11_img_"))
    out_path = temp_dir / "image.png"
    with Image.open(file_path) as img:
        img.convert("RGB").save(out_path)
    return out_path.as_posix()


def prepare_images_for_ocr(file_path: str) -> List[str]:
    path = Path(file_path)
    suffix = path.suffix.lower()
    if suffix == ".pdf":
        return pdf_to_images(file_path)
    if suffix in IMAGE_SUFFIXES:
        return [image_to_png(file_path)]
    return []


def preprocess_image_for_ocr(image_path: str) -> str:
    """Basic OpenCV cleanup: grayscale, denoise, threshold, sharpen."""
    image = cv2.imread(image_path)
    if image is None:
        return image_path

    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    gray = cv2.fastNlMeansDenoising(gray, h=10)

    # Increase contrast using CLAHE.
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    gray = clahe.apply(gray)

    # Adaptive threshold helps scanned and photographed forms.
    thresh = cv2.adaptiveThreshold(
        gray,
        255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        31,
        11,
    )

    # Small sharpen kernel.
    kernel = np.array([[0, -1, 0], [-1, 5, -1], [0, -1, 0]])
    sharp = cv2.filter2D(thresh, -1, kernel)

    out_path = str(Path(image_path).with_name(Path(image_path).stem + "_clean.png"))
    cv2.imwrite(out_path, sharp)
    return out_path
