from __future__ import annotations

import tempfile
import zipfile
from pathlib import Path
from typing import Dict, List

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

FIELD_LABELS = {
    "member_name": "NAME OF MEMBER",
    "father_husband_name": "FATHER / HUSBAND NAME",
    "date_of_birth": "DATE OF BIRTH",
    "gender": "GENDER",
    "marital_status": "MARITAL STATUS",
    "email": "EMAIL ID",
    "mobile": "MOBILE NUMBER",
    "uan": "UAN",
    "aadhaar": "AADHAAR NUMBER",
    "pan": "PAN",
    "bank_account_no": "BANK ACCOUNT NUMBER",
    "ifsc": "IFSC CODE",
    "previous_pf_account_no": "PREVIOUS PF ACCOUNT NUMBER",
    "establishment_name": "ESTABLISHMENT / COMPANY NAME",
    "date_of_joining": "DATE OF JOINING",
    "nationality": "NATIONALITY",
}


def safe_filename(name: str) -> str:
    safe = "".join(ch if ch.isalnum() or ch in "-_ ." else "_" for ch in name)
    return safe.strip(" ._") or "FORM11"


def create_form11_workbook(record: Dict) -> str:
    fields: Dict[str, str] = record.get("fields", {})
    warnings: Dict[str, str] = record.get("warnings", {})
    raw_text: str = record.get("rawText", "")
    filename: str = record.get("filename", "form11")

    wb = Workbook()
    ws = wb.active
    ws.title = "FORM 11 DATA"
    ws.sheet_view.showGridLines = False
    ws.sheet_view.zoomScale = 100
    ws.page_setup.paperSize = ws.PAPERSIZE_A4
    ws.page_setup.orientation = "portrait"
    ws.page_margins.left = 0.35
    ws.page_margins.right = 0.35
    ws.page_margins.top = 0.45
    ws.page_margins.bottom = 0.45

    thin = Side(style="thin", color="111827")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    header_fill = PatternFill("solid", fgColor="1F4E78")
    label_fill = PatternFill("solid", fgColor="D9EAF7")
    warn_fill = PatternFill("solid", fgColor="FFE5E5")

    ws.merge_cells("A1:D1")
    ws["A1"] = "FORM 11 EXTRACTED DATA"
    ws["A1"].font = Font(size=16, bold=True, color="FFFFFF")
    ws["A1"].fill = header_fill
    ws["A1"].alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 28

    ws["A2"] = "SOURCE FILE"
    ws["B2"] = filename.upper()
    ws["A3"] = "EXTRACTION SOURCE"
    ws["B3"] = str(record.get("source", "")).upper()
    ws["C3"] = "CONFIDENCE"
    ws["D3"] = str(record.get("confidence", "")).upper()

    start_row = 5
    ws.cell(start_row, 1, "SL NO")
    ws.cell(start_row, 2, "FIELD")
    ws.cell(start_row, 3, "VALUE")
    ws.cell(start_row, 4, "WARNING")

    for cell in ws[start_row]:
        cell.fill = header_fill
        cell.font = Font(bold=True, color="FFFFFF")
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = border

    row = start_row + 1
    for idx, (key, label) in enumerate(FIELD_LABELS.items(), start=1):
        ws.cell(row, 1, idx)
        ws.cell(row, 2, label)
        ws.cell(row, 3, str(fields.get(key, "")).upper())
        ws.cell(row, 4, warnings.get(key, ""))
        for col in range(1, 5):
            cell = ws.cell(row, col)
            cell.border = border
            cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
            cell.font = Font(size=11, bold=(col == 3))
            if col == 2:
                cell.fill = label_fill
            if col == 4 and warnings.get(key):
                cell.fill = warn_fill
        ws.cell(row, 1).alignment = Alignment(horizontal="center", vertical="center")
        row += 1

    ws.column_dimensions["A"].width = 8
    ws.column_dimensions["B"].width = 34
    ws.column_dimensions["C"].width = 45
    ws.column_dimensions["D"].width = 35

    for r in range(2, row):
        ws.row_dimensions[r].height = 24

    raw = wb.create_sheet("OCR RAW TEXT")
    raw.sheet_view.showGridLines = False
    raw["A1"] = "RAW EXTRACTED TEXT"
    raw["A1"].font = Font(size=14, bold=True)
    raw["A2"] = raw_text[:32000]
    raw["A2"].alignment = Alignment(wrap_text=True, vertical="top")
    raw.column_dimensions["A"].width = 120
    raw.row_dimensions[2].height = 420

    warnings_sheet = wb.create_sheet("VALIDATION")
    warnings_sheet.sheet_view.showGridLines = False
    warnings_sheet.append(["FIELD", "WARNING"])
    for cell in warnings_sheet[1]:
        cell.fill = header_fill
        cell.font = Font(bold=True, color="FFFFFF")
    if warnings:
        for k, v in warnings.items():
            warnings_sheet.append([FIELD_LABELS.get(k, k).upper(), v])
    else:
        warnings_sheet.append(["ALL", "NO WARNINGS"])
    warnings_sheet.column_dimensions["A"].width = 35
    warnings_sheet.column_dimensions["B"].width = 60

    out_dir = Path(tempfile.mkdtemp(prefix="form11_excel_"))
    stem = safe_filename(Path(filename).stem.upper())
    out_path = out_dir / f"{stem}_FORM11_EXTRACTED.xlsx"
    wb.save(out_path)
    return out_path.as_posix()


def create_zip(paths: List[str]) -> str:
    out_dir = Path(tempfile.mkdtemp(prefix="form11_zip_"))
    zip_path = out_dir / "FORM11_EXTRACTED_WORKBOOKS.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in paths:
            zf.write(path, arcname=Path(path).name)
    return zip_path.as_posix()
