const recordsBody = document.getElementById('recordsBody');
const refreshBtn = document.getElementById('refreshBtn');
const refreshInfo = document.getElementById('refreshInfo');
const loadingModal = document.getElementById('loadingModal');
const errorBox = document.getElementById('errorBox');
const searchInput = document.getElementById('searchInput');
const statusFilter = document.getElementById('statusFilter');

const totalCount = document.getElementById('totalCount');
const completedCount = document.getElementById('completedCount');
const convertingCount = document.getElementById('convertingCount');
const pendingCount = document.getElementById('pendingCount');
const failedCount = document.getElementById('failedCount');

let refreshSeconds = 10;
let refreshTimer = null;
let firstLoad = true;

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function showLoading(show) {
  loadingModal.classList.toggle('hidden', !show);
}

function showError(message) {
  if (!message) {
    errorBox.classList.add('hidden');
    errorBox.textContent = '';
    return;
  }

  errorBox.textContent = message;
  errorBox.classList.remove('hidden');
}

function statusClass(status) {
  const value = String(status || '').toLowerCase();
  if (value === 'completed') return 'completed';
  if (value === 'converting') return 'converting';
  if (value === 'pending') return 'pending';
  if (value === 'failed') return 'failed';
  return 'empty-status';
}

function renderLink(url, label, type) {
  if (!url) return '<span class="no-link">No link</span>';
  return `<a class="link-btn ${type || ''}" href="${escapeHtml(url)}" target="_blank" rel="noopener">${escapeHtml(label)}</a>`;
}

function renderRows(records) {
  if (!records || records.length === 0) {
    recordsBody.innerHTML = `
      <tr>
        <td colspan="9" class="empty-cell">
          No records found in SharePoint List.<br />
          Add an item in FORM 3A list or check Graph permissions.
        </td>
      </tr>
    `;
    return;
  }

  recordsBody.innerHTML = records.map(record => `
    <tr>
      <td>${escapeHtml(record.title)}</td>
      <td>${escapeHtml(record.uan)}</td>
      <td>${escapeHtml(record.accountNo)}</td>
      <td>${escapeHtml(record.name)}</td>
      <td>${escapeHtml(record.addedBy)}</td>
      <td><span class="badge ${statusClass(record.status)}">${escapeHtml(record.status || 'No Status')}</span></td>
      <td>${renderLink(record.excelLink, 'Open Excel', '')}</td>
      <td>${renderLink(record.pdf, 'Open PDF', 'pdf')}</td>
      <td>${escapeHtml(record.addedAt)}</td>
    </tr>
  `).join('');
}

function updateCounts(data) {
  const allRecords = data.records || [];

  const counts = allRecords.reduce((acc, item) => {
    const key = String(item.status || 'No Status').toLowerCase();
    acc[key] = (acc[key] || 0) + 1;
    return acc;
  }, {});

  totalCount.textContent = String(data.count || 0);
  completedCount.textContent = String(counts.completed || 0);
  convertingCount.textContent = String(counts.converting || 0);
  pendingCount.textContent = String(counts.pending || 0);
  failedCount.textContent = String(counts.failed || 0);
}

async function loadConfig() {
  try {
    const response = await fetch('/api/config');
    const config = await response.json();
    refreshSeconds = Number(config.refreshSeconds || 10);
  } catch (_) {
    refreshSeconds = 10;
  }
}

async function loadRecords() {
  const q = searchInput.value.trim();
  const status = statusFilter.value;
  const params = new URLSearchParams();

  if (q) params.set('q', q);
  if (status) params.set('status', status);

  try {
    if (firstLoad) showLoading(true);
    showError('');

    const response = await fetch(`/api/records?${params.toString()}`);
    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || 'Failed to fetch SharePoint records');
    }

    renderRows(data.records);
    updateCounts(data);

    const refreshed = new Date(data.refreshedAt || Date.now()).toLocaleTimeString('en-IN');
    refreshInfo.textContent = `Last refreshed: ${refreshed}`;
  } catch (error) {
    showError(error.message);
    recordsBody.innerHTML = `
      <tr>
        <td colspan="9" class="empty-cell">Could not load SharePoint records.</td>
      </tr>
    `;
  } finally {
    firstLoad = false;
    showLoading(false);
  }
}

function resetTimer() {
  if (refreshTimer) clearInterval(refreshTimer);
  refreshTimer = setInterval(loadRecords, refreshSeconds * 1000);
}

let searchDebounce = null;
searchInput.addEventListener('input', () => {
  clearTimeout(searchDebounce);
  searchDebounce = setTimeout(loadRecords, 400);
});

statusFilter.addEventListener('change', loadRecords);
refreshBtn.addEventListener('click', loadRecords);

(async function init() {
  await loadConfig();
  await loadRecords();
  resetTimer();
})();
