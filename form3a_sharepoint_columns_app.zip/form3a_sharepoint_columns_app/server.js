require('dotenv').config();

const express = require('express');
const path = require('path');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const GRAPH_BASE = 'https://graph.microsoft.com/v1.0';

app.use(express.json({ limit: '2mb' }));
app.use(express.static(path.join(__dirname, 'public')));

let tokenCache = {
  accessToken: null,
  expiresAt: 0
};

let siteIdCache = null;
let listIdCache = null;

function requiredEnv(name) {
  const value = process.env[name];
  if (!value || !String(value).trim()) {
    throw new Error(`Missing .env value: ${name}`);
  }
  return String(value).trim();
}

function getFieldNames() {
  return {
    title: process.env.FIELD_TITLE || 'Title',
    uan: process.env.FIELD_UAN || 'UAN',
    accountNo: process.env.FIELD_ACCOUNT_NO || 'ACCOUNT_x0020_NO',
    name: process.env.FIELD_NAME || 'NAME',
    addedBy: process.env.FIELD_ADDED_BY || 'ADDED_x0020_BY',
    status: process.env.FIELD_STATUS || 'STATUS',
    excelLink: process.env.FIELD_EXCEL_LINK || 'EXCEL_x0020_LINK',
    pdf: process.env.FIELD_PDF || 'PDF',
    addedAt: process.env.FIELD_ADDED_AT || 'ADDED_x0020_AT'
  };
}

function pickField(fields, envName, fallbackNames = []) {
  if (!fields) return '';

  const keys = [envName, ...fallbackNames].filter(Boolean);
  for (const key of keys) {
    if (Object.prototype.hasOwnProperty.call(fields, key)) {
      return fields[key];
    }
  }

  // case-insensitive fallback, useful when SharePoint internal names differ
  const lowerMap = new Map(Object.keys(fields).map(k => [k.toLowerCase(), k]));
  for (const key of keys) {
    const actual = lowerMap.get(String(key).toLowerCase());
    if (actual) return fields[actual];
  }

  return '';
}

function normalizeLink(value) {
  if (!value) return '';

  if (typeof value === 'string') {
    const trimmed = value.trim();
    if (!trimmed) return '';

    // SharePoint hyperlink fields sometimes return "url, description".
    const firstPart = trimmed.split(',')[0].trim();
    return firstPart || trimmed;
  }

  if (typeof value === 'object') {
    return value.Url || value.url || value.href || value.webUrl || '';
  }

  return String(value);
}

function formatDate(value) {
  if (!value) return '';
  try {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return String(value);
    return date.toLocaleString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  } catch (_) {
    return String(value);
  }
}

async function getGraphToken() {
  const now = Date.now();
  if (tokenCache.accessToken && tokenCache.expiresAt > now + 60_000) {
    return tokenCache.accessToken;
  }

  const tenantId = requiredEnv('TENANT_ID');
  const clientId = requiredEnv('CLIENT_ID');
  const clientSecret = requiredEnv('CLIENT_SECRET');

  const body = new URLSearchParams();
  body.set('client_id', clientId);
  body.set('client_secret', clientSecret);
  body.set('scope', 'https://graph.microsoft.com/.default');
  body.set('grant_type', 'client_credentials');

  const response = await fetch(`https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.error_description || data.error || `Token request failed: ${response.status}`);
  }

  tokenCache = {
    accessToken: data.access_token,
    expiresAt: now + Number(data.expires_in || 3600) * 1000
  };

  return tokenCache.accessToken;
}

async function graphRequest(url, options = {}) {
  const token = await getGraphToken();
  const response = await fetch(url, {
    ...options,
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json',
      ...(options.headers || {})
    }
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const message = data.error?.message || data.error_description || JSON.stringify(data) || response.statusText;
    throw new Error(`Graph error ${response.status}: ${message}`);
  }

  return data;
}

async function graphGetPaged(url) {
  const rows = [];
  let nextUrl = url;

  while (nextUrl) {
    const data = await graphRequest(nextUrl);
    rows.push(...(data.value || []));
    nextUrl = data['@odata.nextLink'] || null;
  }

  return rows;
}

async function getSiteId() {
  if (siteIdCache) return siteIdCache;

  if (process.env.SHAREPOINT_SITE_ID && process.env.SHAREPOINT_SITE_ID.trim()) {
    siteIdCache = process.env.SHAREPOINT_SITE_ID.trim();
    return siteIdCache;
  }

  const hostname = requiredEnv('SHAREPOINT_HOSTNAME');
  const sitePath = requiredEnv('SHAREPOINT_SITE_PATH');

  const site = await graphRequest(`${GRAPH_BASE}/sites/${hostname}:${sitePath}`);
  siteIdCache = site.id;
  return siteIdCache;
}

async function getListId() {
  if (listIdCache) return listIdCache;

  if (process.env.FORM3A_LIST_ID && process.env.FORM3A_LIST_ID.trim()) {
    listIdCache = process.env.FORM3A_LIST_ID.trim();
    return listIdCache;
  }

  const siteId = await getSiteId();
  const listName = requiredEnv('FORM3A_LIST_NAME');
  const lists = await graphGetPaged(`${GRAPH_BASE}/sites/${siteId}/lists?$select=id,displayName,name,webUrl`);
  const found = lists.find(item =>
    String(item.displayName || '').toLowerCase() === listName.toLowerCase() ||
    String(item.name || '').toLowerCase() === listName.toLowerCase()
  );

  if (!found) {
    const names = lists.map(item => item.displayName || item.name).join(', ');
    throw new Error(`List '${listName}' not found. Available lists: ${names}`);
  }

  listIdCache = found.id;
  return listIdCache;
}

function mapListItem(item) {
  const fields = item.fields || {};
  const f = getFieldNames();

  const accountNo = pickField(fields, f.accountNo, ['ACCOUNT NO', 'Account No', 'AccountNo', 'ACCOUNTNO']);
  const uan = pickField(fields, f.uan, ['UAN']);
  const name = pickField(fields, f.name, ['Name', 'Employee Name', 'EmployeeName']);
  const status = pickField(fields, f.status, ['Status']);
  const addedBy = pickField(fields, f.addedBy, ['ADDED BY', 'Added By', 'AddedBy', 'Author']);
  const addedAt = pickField(fields, f.addedAt, ['ADDED AT', 'Added At', 'AddedAt', 'Created']);
  const excelLink = pickField(fields, f.excelLink, ['EXCEL LINK', 'Excel Link', 'ExcelLink']);
  const pdf = pickField(fields, f.pdf, ['PDF', 'Pdf', 'PDF Link', 'PDFLink']);

  return {
    id: item.id,
    title: pickField(fields, f.title, ['Title']),
    uan: String(uan || ''),
    accountNo: String(accountNo || ''),
    name: String(name || ''),
    addedBy: typeof addedBy === 'object' ? (addedBy.LookupValue || addedBy.email || addedBy.name || '') : String(addedBy || ''),
    status: String(status || ''),
    excelLink: normalizeLink(excelLink),
    pdf: normalizeLink(pdf),
    addedAtRaw: addedAt || '',
    addedAt: formatDate(addedAt),
    webUrl: item.webUrl || '',
    rawFields: fields
  };
}

app.get('/api/config', (req, res) => {
  res.json({
    refreshSeconds: Number(process.env.REFRESH_SECONDS || 10),
    columns: ['Title', 'UAN', 'ACCOUNT NO', 'NAME', 'ADDED BY', 'STATUS', 'EXCEL LINK', 'PDF', 'ADDED AT']
  });
});

app.get('/api/health', async (req, res) => {
  try {
    await getGraphToken();
    res.json({ ok: true, message: 'Graph token received successfully' });
  } catch (error) {
    res.status(500).json({ ok: false, error: error.message });
  }
});

app.get('/api/setup/site', async (req, res) => {
  try {
    const siteId = await getSiteId();
    const site = await graphRequest(`${GRAPH_BASE}/sites/${siteId}`);
    res.json(site);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/setup/lists', async (req, res) => {
  try {
    const siteId = await getSiteId();
    const lists = await graphGetPaged(`${GRAPH_BASE}/sites/${siteId}/lists?$select=id,displayName,name,webUrl`);
    res.json(lists);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/setup/fields', async (req, res) => {
  try {
    const siteId = await getSiteId();
    const listId = await getListId();
    const fields = await graphGetPaged(`${GRAPH_BASE}/sites/${siteId}/lists/${listId}/columns?$select=id,name,displayName,columnGroup`);
    res.json(fields);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/records', async (req, res) => {
  try {
    const siteId = await getSiteId();
    const listId = await getListId();

    const url = `${GRAPH_BASE}/sites/${siteId}/lists/${listId}/items?$expand=fields&$top=999`;
    const items = await graphGetPaged(url);
    let records = items.map(mapListItem);

    const status = String(req.query.status || '').trim().toLowerCase();
    const q = String(req.query.q || '').trim().toLowerCase();

    if (status && status !== 'all') {
      records = records.filter(item => String(item.status || '').toLowerCase() === status);
    }

    if (q) {
      records = records.filter(item =>
        [item.title, item.uan, item.accountNo, item.name, item.addedBy, item.status]
          .some(value => String(value || '').toLowerCase().includes(q))
      );
    }

    records.sort((a, b) => {
      const ad = new Date(a.addedAtRaw || 0).getTime();
      const bd = new Date(b.addedAtRaw || 0).getTime();
      return bd - ad;
    });

    const counts = records.reduce((acc, item) => {
      const key = item.status || 'No Status';
      acc[key] = (acc[key] || 0) + 1;
      return acc;
    }, {});

    res.json({
      count: records.length,
      counts,
      records,
      refreshedAt: new Date().toISOString()
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`FORM 3A SharePoint app running on http://localhost:${PORT}`);
});
