# FORM 3A SharePoint List Web Application

This Node.js web application reads your **FORM 3A** SharePoint List using Microsoft Graph API and shows the columns visible in your screenshot:

- Title
- UAN
- ACCOUNT NO
- NAME
- ADDED BY
- STATUS
- EXCEL LINK
- PDF
- ADDED AT

## 1. Install

```bash
npm install
```

## 2. Create `.env`

Copy `.env.example` to `.env`.

```bash
copy .env.example .env
```

Or in PowerShell:

```powershell
Copy-Item .env.example .env
```

## 3. Fill `.env`

For your screenshot URL:

```text
https://adponlineind-my.sharepoint.com/personal/mhaswanth_ad_esi_adp_com/Lists/FORM%203A/AllItems.aspx
```

Use:

```env
SHAREPOINT_HOSTNAME=adponlineind-my.sharepoint.com
SHAREPOINT_SITE_PATH=/personal/mhaswanth_ad_esi_adp_com
FORM3A_LIST_NAME=FORM 3A
```

Fill your Graph app values:

```env
TENANT_ID=
CLIENT_ID=
CLIENT_SECRET=
```

## 4. Graph permissions needed

Your app registration needs Microsoft Graph application permission such as:

```text
Sites.Read.All
```

If you also want to write/update records later, use:

```text
Sites.ReadWrite.All
```

Admin consent is usually required.

## 5. Run

```bash
npm start
```

Open:

```text
http://localhost:3000
```

## 6. Useful setup URLs

Check Graph token:

```text
http://localhost:3000/api/health
```

Check SharePoint site connection:

```text
http://localhost:3000/api/setup/site
```

List all SharePoint lists:

```text
http://localhost:3000/api/setup/lists
```

Check actual internal column names:

```text
http://localhost:3000/api/setup/fields
```

If your column values do not show, open `/api/setup/fields` and copy the real `name` values into `.env`:

```env
FIELD_ACCOUNT_NO=ACCOUNT_x0020_NO
FIELD_EXCEL_LINK=EXCEL_x0020_LINK
FIELD_ADDED_AT=ADDED_x0020_AT
```

## 7. Important note about SharePoint internal names

SharePoint display names and internal names can be different.

Example:

```text
Display name: ACCOUNT NO
Internal name: ACCOUNT_x0020_NO
```

This app supports `.env` mapping so you can fix it without changing code.
