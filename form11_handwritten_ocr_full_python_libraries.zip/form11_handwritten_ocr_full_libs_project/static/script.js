const fileInput = document.getElementById("fileInput");
const fileCount = document.getElementById("fileCount");
const convertBtn = document.getElementById("convertBtn");
const fileSelector = document.getElementById("fileSelector");
const imagePreview = document.getElementById("imagePreview");
const fieldsForm = document.getElementById("fieldsForm");
const rawOcrText = document.getElementById("rawOcrText");
const confidenceText = document.getElementById("confidenceText");
const downloadWorkbook = document.getElementById("downloadWorkbook");
const downloadZip = document.getElementById("downloadZip");
const regenerateBtn = document.getElementById("regenerateBtn");
const statusBox = document.getElementById("status");

let selectedFiles = [];
let results = [];
let activeIndex = 0;

function setStatus(message, isError = false) {
  statusBox.textContent = message || "";
  statusBox.classList.toggle("error", Boolean(isError));
}

function updateCount() {
  fileCount.textContent = `${selectedFiles.length} / ${window.MAX_FILES} files selected`;
  convertBtn.disabled = selectedFiles.length === 0 || selectedFiles.length > window.MAX_FILES;
}

async function sha256(file) {
  const buffer = await file.arrayBuffer();
  const hash = await crypto.subtle.digest("SHA-256", buffer);
  return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, "0")).join("");
}

fileInput.addEventListener("change", async () => {
  const files = Array.from(fileInput.files || []);
  if (files.length > window.MAX_FILES) {
    setStatus(`Maximum ${window.MAX_FILES} files allowed.`, true);
    fileInput.value = "";
    selectedFiles = [];
    updateCount();
    return;
  }

  const seen = new Set();
  const unique = [];
  for (const file of files) {
    const digest = await sha256(file);
    if (seen.has(digest)) {
      setStatus(`Duplicate file skipped: ${file.name}`, true);
      continue;
    }
    seen.add(digest);
    unique.push(file);
  }
  selectedFiles = unique;
  updateCount();
  resetResultView();
});

function resetResultView() {
  results = [];
  activeIndex = 0;
  fileSelector.innerHTML = "";
  imagePreview.innerHTML = "Upload handwritten/scanned Form 11 PDF or image.";
  imagePreview.classList.add("empty-state");
  rawOcrText.textContent = "";
  confidenceText.textContent = "OCR confidence: -";
  downloadWorkbook.href = "#";
  downloadZip.href = "#";
  downloadWorkbook.classList.add("disabled");
  downloadZip.classList.add("disabled");
  regenerateBtn.disabled = true;
  fieldsForm.querySelectorAll("textarea").forEach(t => t.value = "");
}

convertBtn.addEventListener("click", async () => {
  if (!selectedFiles.length) return;
  setStatus("Running OCR. This can take time for handwritten/scanned files...");
  convertBtn.disabled = true;

  const formData = new FormData();
  selectedFiles.forEach(file => formData.append("files", file));

  try {
    const response = await fetch("/convert", { method: "POST", body: formData });
    const data = await response.json();
    if (!response.ok || !data.success) {
      const errorText = data.error || "OCR failed.";
      setStatus(errorText, true);
      convertBtn.disabled = false;
      return;
    }

    results = data.results.filter(r => r.success);
    fileSelector.innerHTML = "";
    results.forEach((item, index) => {
      const option = document.createElement("option");
      option.value = index;
      option.textContent = `${index + 1}. ${item.filename}`;
      fileSelector.appendChild(option);
    });

    if (data.zip_url) {
      downloadZip.href = data.zip_url;
      downloadZip.download = data.zip_name || "form11_ocr_workbooks.zip";
      downloadZip.classList.remove("disabled");
    }

    activeIndex = 0;
    renderResult();
    setStatus(`${results.length} workbook(s) created. Review fields and update Excel if needed.`);
  } catch (error) {
    setStatus(error.message || String(error), true);
  } finally {
    convertBtn.disabled = selectedFiles.length === 0;
  }
});

fileSelector.addEventListener("change", () => {
  activeIndex = Number(fileSelector.value || 0);
  renderResult();
});

function renderResult() {
  const item = results[activeIndex];
  if (!item) return;

  imagePreview.classList.remove("empty-state");
  imagePreview.innerHTML = `<img src="${item.preview_url}" alt="Preview of ${item.filename}" />`;
  confidenceText.textContent = `OCR confidence: ${item.confidence || 0}%`;

  fieldsForm.querySelectorAll("textarea").forEach(textarea => {
    const key = textarea.dataset.key;
    textarea.value = (item.fields && item.fields[key] ? item.fields[key] : "").toUpperCase();
  });

  rawOcrText.textContent = (item.raw_text || "").toUpperCase();
  downloadWorkbook.href = item.workbook_url;
  downloadWorkbook.download = item.workbook_name;
  downloadWorkbook.classList.remove("disabled");
  regenerateBtn.disabled = false;
}

fieldsForm.addEventListener("input", (event) => {
  if (event.target.tagName === "TEXTAREA") {
    const start = event.target.selectionStart;
    const end = event.target.selectionEnd;
    event.target.value = event.target.value.toUpperCase();
    event.target.setSelectionRange(start, end);
  }
});

regenerateBtn.addEventListener("click", async () => {
  const item = results[activeIndex];
  if (!item) return;

  const fields = {};
  fieldsForm.querySelectorAll("textarea").forEach(textarea => {
    fields[textarea.dataset.key] = textarea.value.toUpperCase();
  });

  setStatus("Updating Excel with reviewed uppercase values...");

  const response = await fetch("/regenerate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      fields,
      raw_text: item.raw_text || "",
      source_name: item.filename,
      confidence: item.confidence || 0
    })
  });

  const data = await response.json();
  if (!response.ok || !data.success) {
    setStatus(data.error || "Failed to update Excel.", true);
    return;
  }

  item.fields = fields;
  item.workbook_url = data.workbook_url;
  item.workbook_name = data.workbook_name;
  downloadWorkbook.href = data.workbook_url;
  downloadWorkbook.download = data.workbook_name;
  setStatus("Excel updated with reviewed uppercase values.");
});

updateCount();
