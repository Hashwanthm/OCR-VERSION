# Form 11 High-End AI OCR Project

This is a NEW separate project for scanned/handwritten EPFO Form 11 extraction.

## What this version does

- Left side shows uploaded PDF/image preview.
- Right side shows extracted editable fields, not Excel preview.
- Uses high-end AI OCR for image/scanned PDFs.
- Converts values to CAPITAL LETTERS.
- User reviews/corrects extracted fields before saving Excel.
- Creates Excel workbook after review.
- Supports up to 10 files.
- Includes CLI tool for command line extraction.

## Why this version is different

Handwritten Form 11 values are image-based. Normal PDF libraries like PyMuPDF/pdfplumber can read printed labels, but they usually cannot read handwritten values.

So this project always attempts AI OCR first:

1. Convert PDF pages to high-resolution images using PyMuPDF.
2. Clean/upscale the image using OpenCV.
3. Run PaddleOCR first.
4. Use EasyOCR as fallback.
5. Map OCR text to Form 11 fields using layout coordinates and fuzzy matching.
6. Show editable fields for manual review.
7. Save Excel.

## Backend setup

```cmd
cd backend
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

Install high-end AI OCR packages:

```cmd
install_ai_cpu.bat
```

Then run backend:

```cmd
python app.py
```

Backend URL:

```txt
http://127.0.0.1:8000
```

## Frontend setup

Use Node 20.19+ or Node 22.12+.

```cmd
cd frontend
npm install
npm run dev
```

Frontend URL:

```txt
http://127.0.0.1:5173
```

## CLI usage

```cmd
cd backend
venv\Scripts\activate
python cli.py extract "C:\path\to\form11.pdf" --output form11_output.xlsx
```

## Important accuracy note

AI OCR can still make mistakes for handwriting. The review/edit screen is mandatory before Excel download.

For best results, use:

- Clear scanned PDF, not a blurry mobile photo.
- 300 DPI scan.
- Straight page alignment.
- Blue/black ink.
- One full Form 11 page per scan.
