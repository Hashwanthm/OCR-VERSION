from __future__ import annotations

from pathlib import Path
import typer
from rich.console import Console

from extractor import extract_form11
from excel_writer import create_form11_workbook

app = typer.Typer(help="Form 11 OCR command line tool")
console = Console()


@app.command()
def extract(input_file: Path, output: Path = Path("form11_output.xlsx")):
    """Extract Form 11 data from one PDF/image and save Excel."""
    if not input_file.exists():
        console.print(f"[red]File not found:[/red] {input_file}")
        raise typer.Exit(1)
    result = extract_form11(input_file)
    create_form11_workbook(result["fields"], output, result["raw_text"], result["warnings"])
    console.print(f"[green]Excel created:[/green] {output}")
    if result["warnings"]:
        console.print("[yellow]Review warnings:[/yellow]")
        for warning in result["warnings"]:
            console.print(f"- {warning}")


if __name__ == "__main__":
    app()
