from __future__ import annotations

import re
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import fitz  # PyMuPDF
import pdfplumber
from rapidfuzz import fuzz

FORM11_FIELDS = [
    ("member_name", "Name of Member"),
    ("father_husband_name", "Father / Husband Name"),
    ("dob", "Date of Birth"),
    ("gender", "Gender"),
    ("marital_status", "Marital Status"),
    ("email_id", "Email ID"),
    ("mobile_no", "Mobile Number"),
    ("date_of_joining", "Date of Joining"),
    ("bank_account_no", "Bank Account No"),
    ("ifsc_code", "IFSC Code"),
    ("aadhaar_no", "Aadhaar Number"),
    ("pan_no", "PAN Number"),
    ("earlier_epf_member", "Earlier EPF Member"),
    ("earlier_eps_member", "Earlier EPS Member"),
    ("prev_establishment", "Previous Establishment Name & Address"),
    ("prev_uan", "Previous UAN"),
    ("prev_pf_account_no", "Previous PF Account No"),
    ("prev_date_of_joining", "Previous Date of Joining"),
    ("prev_date_of_exit", "Previous Date of Exit"),
    ("scheme_certificate_no", "Scheme Certificate No"),
    ("ppo_no", "PPO Number"),
    ("ncp_days", "NCP Days"),
    ("international_worker", "International Worker"),
    ("country_origin", "Country of Origin"),
    ("passport_no", "Passport No"),
    ("passport_valid_from", "Passport Valid From"),
    ("passport_valid_to", "Passport Valid To"),
]

FIELD_KEYS = [key for key, _ in FORM11_FIELDS]

LABEL_WORDS = {
    "NAME", "MEMBER", "FATHER", "HUSBAND", "SPOUSE", "DATE", "BIRTH", "GENDER",
    "MARITAL", "STATUS", "EMAIL", "MOBILE", "PRESENT", "EMPLOYMENT", "DETAILS",
    "JOINING", "CURRENT", "ESTABLISHMENT", "KYC", "BANK", "ACCOUNT", "IFSC",
    "BRANCH", "AADHAAR", "AADHAR", "NUMBER", "PAN", "AVAILABLE", "WHETHER",
    "EARLIER", "EMPLOYEES", "PROVIDENT", "FUND", "PENSION", "SCHEME", "PREVIOUS",
    "UNEXEMPTED", "EXEMPTED", "TRUST", "INTERNATIONAL", "WORKER", "COUNTRY",
    "PASSPORT", "VALIDITY", "DECLARATION", "FORM", "ORGANISATION", "NO", "YES",
}

LABEL_HINTS = {
    "member_name": ["NAME OF THE MEMBER", "NAME OF MEMBER"],
    "father_husband_name": ["FATHER", "SPOUSE", "HUSBAND"],
    "dob": ["DATE OF BIRTH", "DOB", "DD MM YYYY"],
    "gender": ["GENDER", "MALE", "FEMALE", "TRANSGENDER"],
    "marital_status": ["MARITAL STATUS", "MARRIED", "UNMARRIED", "WIDOW", "DIVORCEE"],
    "email_id": ["EMAIL", "EMAIL ID"],
    "mobile_no": ["MOBILE", "MOBILE NO"],
    "date_of_joining": ["DATE OF JOINING", "CURRENT ESTABLISHMENT"],
    "bank_account_no": ["BANK ACCOUNT", "ACCOUNT NO"],
    "ifsc_code": ["IFSC"],
    "aadhaar_no": ["AADHAAR", "AADHAR"],
    "pan_no": ["PAN", "PERMANENT ACCOUNT"],
    "earlier_epf_member": ["EMPLOYEES PROVIDENT FUND SCHEME"],
    "earlier_eps_member": ["EMPLOYEES PENSION SCHEME"],
    "prev_establishment": ["PREVIOUS EMPLOYMENT", "ESTABLISHMENT NAME", "NAME & ADDRESS"],
    "prev_uan": ["UNIVERSAL ACCOUNT NUMBER", "UAN"],
    "prev_pf_account_no": ["PF ACCOUNT NUMBER"],
    "prev_date_of_joining": ["DATE OF JOINING"],
    "prev_date_of_exit": ["DATE OF EXIT"],
    "scheme_certificate_no": ["SCHEME CERTIFICATE"],
    "ppo_no": ["PPO NUMBER"],
    "ncp_days": ["NON CONTRIBUTORY", "NCP"],
    "international_worker": ["INTERNATIONAL WORKER"],
    "country_origin": ["COUNTRY OF ORIGIN"],
    "passport_no": ["PASSPORT NO"],
    "passport_valid_from": ["VALIDITY OF PASSPORT"],
    "passport_valid_to": ["VALIDITY OF PASSPORT"],
}

@dataclass
class OCRItem:
    text: str
    conf: float
    page: int
    x1: float
    y1: float
    x2: float
    y2: float
    width: float
    height: float

    @property
    def cx(self) -> float:
        return ((self.x1 + self.x2) / 2) / self.width if self.width else 0

    @property
    def cy(self) -> float:
        return ((self.y1 + self.y2) / 2) / self.height if self.height else 0


def blank_fields() -> Dict[str, str]:
    return {key: "" for key in FIELD_KEYS}


def uppercase_value(value: str) -> str:
    return re.sub(r"\s+", " ", (value or "").strip()).upper()


def normalize_ocr_text(text: str) -> str:
    text = text.replace("\u00a0", " ")
    text = re.sub(r"[|]+", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def extract_selectable_pdf_text(path: Path) -> str:
    parts: List[str] = []
    if path.suffix.lower() != ".pdf":
        return ""
    try:
        with fitz.open(path) as doc:
            for page in doc:
                parts.append(page.get_text("text") or "")
    except Exception:
        pass
    try:
        with pdfplumber.open(path) as pdf:
            for page in pdf.pages:
                parts.append(page.extract_text() or "")
    except Exception:
        pass
    return "\n".join(parts).strip()


def render_pdf_to_images(path: Path) -> List[Path]:
    image_paths: List[Path] = []
    tmpdir = Path(tempfile.mkdtemp(prefix="form11_pages_"))
    with fitz.open(path) as doc:
        for i, page in enumerate(doc):
            matrix = fitz.Matrix(3.2, 3.2)
            pix = page.get_pixmap(matrix=matrix, alpha=False)
            out = tmpdir / f"page_{i + 1}.png"
            pix.save(out)
            image_paths.append(out)
    return image_paths


def image_size(path: Path) -> Tuple[int, int]:
    try:
        from PIL import Image
        with Image.open(path) as im:
            return im.size
    except Exception:
        return (1, 1)


def preprocess_image_for_ocr(path: Path) -> Path:
    """Return one strong preprocessing image for backward compatibility."""
    variants = preprocess_image_variants(path)
    return variants[-1] if variants else path


def preprocess_image_variants(path: Path) -> List[Path]:
    """Create OCR variants for scanned/handwritten Form 11 pages.

    Handwritten forms are sensitive to contrast and thresholding. PaddleOCR/EasyOCR
    may read one variant better than another, so we generate multiple high-quality
    variants and select the OCR result with the strongest score per page.
    """
    variants: List[Path] = [path]
    try:
        import cv2
        import numpy as np
        image = cv2.imread(str(path))
        if image is None:
            return variants

        # 1) Upscaled original with light denoise/sharpen: preserves blue handwriting.
        scale = 1.6
        up = cv2.resize(image, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
        up = cv2.fastNlMeansDenoisingColored(up, None, 5, 5, 7, 21)
        sharpen_kernel = np.array([[0, -1, 0], [-1, 5, -1], [0, -1, 0]])
        up_sharp = cv2.filter2D(up, -1, sharpen_kernel)
        out1 = path.with_name(path.stem + "_ocr_upscaled.png")
        cv2.imwrite(str(out1), up_sharp)
        variants.append(out1)

        # 2) CLAHE grayscale: good for low-light scans and camera PDFs.
        gray = cv2.cvtColor(up, cv2.COLOR_BGR2GRAY)
        gray = cv2.fastNlMeansDenoising(gray, h=10)
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        clahe_img = clahe.apply(gray)
        out2 = path.with_name(path.stem + "_ocr_clahe.png")
        cv2.imwrite(str(out2), clahe_img)
        variants.append(out2)

        # 3) Adaptive threshold: good for printed boxes/table lines and weak scans.
        thresh = cv2.adaptiveThreshold(
            clahe_img, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 35, 11
        )
        out3 = path.with_name(path.stem + "_ocr_threshold.png")
        cv2.imwrite(str(out3), thresh)
        variants.append(out3)
    except Exception:
        pass
    return variants


def _box_to_bounds(box) -> Tuple[float, float, float, float] | None:
    try:
        # Paddle/EasyOCR polygon: [[x,y], [x,y], [x,y], [x,y]]
        points = []
        for p in box:
            if isinstance(p, (list, tuple)) and len(p) >= 2:
                points.append((float(p[0]), float(p[1])))
        if not points:
            return None
        xs = [p[0] for p in points]
        ys = [p[1] for p in points]
        return min(xs), min(ys), max(xs), max(ys)
    except Exception:
        return None


def _flatten_paddle_result(result, page: int, width: int, height: int) -> List[OCRItem]:
    items: List[OCRItem] = []

    def add(text: str, conf: float, box):
        text = uppercase_value(text)
        if not text:
            return
        bounds = _box_to_bounds(box) if box is not None else None
        if bounds:
            x1, y1, x2, y2 = bounds
        else:
            x1 = y1 = 0.0
            x2 = float(width)
            y2 = float(height)
        items.append(OCRItem(text=text, conf=float(conf or 0), page=page, x1=x1, y1=y1, x2=x2, y2=y2, width=width, height=height))

    def walk(obj):
        if obj is None:
            return
        if isinstance(obj, dict):
            # PaddleOCR v3 often returns rec_texts + rec_scores + rec_boxes/rec_polys.
            texts = obj.get("rec_texts") or obj.get("texts")
            scores = obj.get("rec_scores") or obj.get("scores") or []
            boxes = obj.get("rec_boxes") or obj.get("rec_polys") or obj.get("dt_polys") or []
            if isinstance(texts, list):
                for i, text in enumerate(texts):
                    box = boxes[i] if isinstance(boxes, list) and i < len(boxes) else None
                    score = scores[i] if isinstance(scores, list) and i < len(scores) else 0
                    add(str(text), score, box)
            for val in obj.values():
                walk(val)
            return
        if isinstance(obj, (list, tuple)):
            # PaddleOCR v2 shape: [box, (text, score)]
            if len(obj) >= 2 and isinstance(obj[1], (list, tuple)) and obj[1] and isinstance(obj[1][0], str):
                box = obj[0]
                text = obj[1][0]
                conf = obj[1][1] if len(obj[1]) > 1 else 0
                add(text, conf, box)
                return
            for val in obj:
                walk(val)
    walk(result)
    return items


def ocr_item_score(items: List[OCRItem]) -> float:
    if not items:
        return 0.0
    avg_conf = sum(max(0.0, min(1.0, i.conf)) for i in items) / max(1, len(items))
    value_like = sum(1 for i in items if re.search(r"[A-Z]{2,}|\d", i.text))
    # Prefer many useful boxes, but also reward confidence.
    return value_like + (avg_conf * 5.0)


def dedupe_items(items: List[OCRItem]) -> List[OCRItem]:
    seen = set()
    deduped: List[OCRItem] = []
    for item in sorted(items, key=lambda i: (i.page, i.y1, i.x1, -i.conf)):
        key = (item.page, round(item.cx, 3), round(item.cy, 3), item.text)
        if key in seen:
            continue
        seen.add(key)
        deduped.append(item)
    return deduped


def run_paddle_ocr_items(image_paths: List[Path]) -> Tuple[List[OCRItem], str, bool]:
    try:
        from paddleocr import PaddleOCR
    except Exception:
        return [], "", False

    try:
        try:
            ocr = PaddleOCR(use_angle_cls=True, lang="en", show_log=False)
        except TypeError:
            try:
                ocr = PaddleOCR(use_angle_cls=True, lang="en")
            except TypeError:
                ocr = PaddleOCR(lang="en")
        all_items: List[OCRItem] = []
        for page_index, path in enumerate(image_paths, start=1):
            best_page_items: List[OCRItem] = []
            for processed in preprocess_image_variants(path):
                width, height = image_size(processed)
                try:
                    result = ocr.ocr(str(processed), cls=True)
                except TypeError:
                    result = ocr.ocr(str(processed))
                page_items = _flatten_paddle_result(result, page_index, width, height)
                if ocr_item_score(page_items) > ocr_item_score(best_page_items):
                    best_page_items = page_items
            all_items.extend(best_page_items)
        all_items = dedupe_items(all_items)
        return all_items, "\n".join(i.text for i in all_items), True
    except Exception as exc:
        return [], f"PADDLEOCR_ERROR: {exc}", False


def run_easy_ocr_items(image_paths: List[Path]) -> Tuple[List[OCRItem], str, bool]:
    try:
        import easyocr
    except Exception:
        return [], "", False
    try:
        reader = easyocr.Reader(["en"], gpu=False)
        items: List[OCRItem] = []
        for page_index, path in enumerate(image_paths, start=1):
            best_page_items: List[OCRItem] = []
            for processed in preprocess_image_variants(path):
                width, height = image_size(processed)
                result = reader.readtext(str(processed), detail=1, paragraph=False)
                page_items: List[OCRItem] = []
                for box, text, conf in result:
                    bounds = _box_to_bounds(box)
                    if bounds:
                        x1, y1, x2, y2 = bounds
                    else:
                        x1 = y1 = 0.0
                        x2 = float(width)
                        y2 = float(height)
                    page_items.append(OCRItem(uppercase_value(str(text)), float(conf or 0), page_index, x1, y1, x2, y2, width, height))
                if ocr_item_score(page_items) > ocr_item_score(best_page_items):
                    best_page_items = page_items
            items.extend(best_page_items)
        items = dedupe_items(items)
        return items, "\n".join(i.text for i in items), True
    except Exception as exc:
        return [], f"EASYOCR_ERROR: {exc}", False


def image_or_pdf_to_ocr(path: Path) -> Tuple[str, str, List[OCRItem]]:
    image_paths = render_pdf_to_images(path) if path.suffix.lower() == ".pdf" else [path]

    paddle_items, paddle_text, paddle_ok = run_paddle_ocr_items(image_paths)
    if paddle_ok and paddle_text.strip():
        return paddle_text, "PADDLEOCR", paddle_items

    easy_items, easy_text, easy_ok = run_easy_ocr_items(image_paths)
    if easy_ok and easy_text.strip():
        return easy_text, "EASYOCR", easy_items

    if paddle_text.startswith("PADDLEOCR_ERROR"):
        return paddle_text, "OCR_ERROR", []
    if easy_text.startswith("EASYOCR_ERROR"):
        return easy_text, "OCR_ERROR", []
    return "", "NO_OCR_LIBRARY", []


def line_like_text(items: List[OCRItem]) -> str:
    rows: List[List[OCRItem]] = []
    for item in sorted(items, key=lambda i: (i.page, i.y1, i.x1)):
        placed = False
        for row in rows:
            if row and row[0].page == item.page and abs(row[0].cy - item.cy) < 0.012:
                row.append(item)
                placed = True
                break
        if not placed:
            rows.append([item])
    lines: List[str] = []
    for row in rows:
        row.sort(key=lambda i: i.x1)
        lines.append(" ".join(i.text for i in row))
    return "\n".join(lines)


def is_label_like(line: str) -> bool:
    cleaned = re.sub(r"[^A-Z0-9 ]", " ", line.upper())
    words = [w for w in cleaned.split() if w]
    if not words:
        return True
    label_count = sum(1 for w in words if w in LABEL_WORDS)
    return label_count >= max(1, len(words) * 0.65)


def useful_lines(text: str) -> List[str]:
    lines = []
    for raw in text.splitlines():
        line = uppercase_value(raw)
        if len(line) < 2:
            continue
        lines.append(line)
    return lines


def regex_search(pattern: str, text: str) -> str:
    match = re.search(pattern, text, flags=re.I)
    return uppercase_value(match.group(1) if match and match.groups() else match.group(0) if match else "")


def normalize_date(raw: str) -> str:
    raw = uppercase_value(raw)
    raw = raw.replace("O", "0").replace("I", "1").replace("L", "1")
    m = re.search(r"(\d{1,2})\D+(\d{1,2})\D+(\d{2,4})", raw)
    if not m:
        return ""
    d, mo, y = m.groups()
    if len(y) == 2:
        y = "20" + y if int(y) <= 30 else "19" + y
    try:
        return f"{int(d):02d}/{int(mo):02d}/{y}"
    except ValueError:
        return ""


def cleanup_name(value: str) -> str:
    value = uppercase_value(value)
    value = re.sub(r"[^A-Z .'-]", " ", value)
    value = re.sub(r"\b(NAME|MEMBER|FATHER|SPOUSE|HUSBAND|DATE|BIRTH|GENDER|MARITAL|STATUS)\b", " ", value)
    return uppercase_value(value)


def cleanup_alpha_num(value: str) -> str:
    return uppercase_value(re.sub(r"[^A-Z0-9 @._/,&()\-]", " ", value))


def normalize_choice(value: str, choices: List[str]) -> str:
    value = uppercase_value(value)
    if not value:
        return ""
    # Prefer exact substring first.
    for c in choices:
        if c in value:
            return c
    best = max(choices, key=lambda c: fuzz.partial_ratio(value, c))
    return best if fuzz.partial_ratio(value, best) >= 65 else value


def normalize_yes_no(value: str) -> str:
    value = uppercase_value(value)
    if not value:
        return ""
    if re.search(r"\bYES\b|\bY\b", value):
        return "YES"
    if re.search(r"\bNO\b|\bN\b", value):
        return "NO"
    # circled/checked yes/no often returns both words; leave for review.
    return value


def value_after_label(lines: List[str], label_variants: List[str], window: int = 3) -> str:
    best_i = -1
    best_score = 0
    for i, line in enumerate(lines):
        for label in label_variants:
            score = fuzz.partial_ratio(line, label.upper())
            if score > best_score:
                best_i = i
                best_score = score
    if best_i < 0 or best_score < 65:
        return ""
    candidates: List[str] = []
    same_line = lines[best_i]
    for label in label_variants:
        # Remove everything up to the label if the value was OCR'd on the same line.
        m = re.search(re.escape(label.upper()), same_line)
        if m:
            tail = uppercase_value(same_line[m.end():])
            tail = re.sub(r"^[:\-\s]+", "", tail)
            if tail and not is_label_like(tail):
                candidates.append(tail)
    for j in range(best_i + 1, min(len(lines), best_i + 1 + window)):
        line = lines[j]
        if not is_label_like(line):
            candidates.append(line)
    if not candidates:
        return ""
    return candidates[0]


def items_in_region(items: List[OCRItem], page: int, xmin: float, xmax: float, ymin: float, ymax: float) -> List[OCRItem]:
    return [i for i in items if i.page == page and xmin <= i.cx <= xmax and ymin <= i.cy <= ymax]


def join_region(items: List[OCRItem], page: int, xmin: float, xmax: float, ymin: float, ymax: float) -> str:
    selected = items_in_region(items, page, xmin, xmax, ymin, ymax)
    selected = [i for i in selected if not is_label_like(i.text) or any(ch.isdigit() for ch in i.text)]
    selected.sort(key=lambda i: (i.y1, i.x1))
    return uppercase_value(" ".join(i.text for i in selected))


def extract_from_standard_form11_layout(items: List[OCRItem]) -> Dict[str, str]:
    """Extract handwritten values from the standard EPFO Form 11 layout by position.

    The common Form 11 page has printed labels on the left and handwritten values in the right column.
    This uses normalized coordinates, so it works even when the PDF is rendered at a different DPI.
    """
    fields = blank_fields()
    if not items:
        return fields
    page = min(i.page for i in items)

    # Right-hand value column for rows 1 to 8 on page 1.
    right_xmin, right_xmax = 0.50, 0.98
    bands = {
        "member_name": (0.185, 0.245),
        "father_husband_name": (0.235, 0.295),
        "dob": (0.295, 0.345),
        "gender": (0.335, 0.390),
        "marital_status": (0.380, 0.435),
        "email_id": (0.430, 0.485),
        "mobile_no": (0.480, 0.535),
        "date_of_joining": (0.565, 0.635),
        "bank_account_no": (0.655, 0.705),
        "ifsc_code": (0.700, 0.750),
        "aadhaar_no": (0.745, 0.800),
        "pan_no": (0.790, 0.845),
        "earlier_epf_member": (0.835, 0.880),
        "earlier_eps_member": (0.875, 0.920),
    }
    for key, (y1, y2) in bands.items():
        value = join_region(items, page, right_xmin, right_xmax, y1, y2)
        if value:
            fields[key] = value

    # Previous employment details table. These are often handwritten in the lower half.
    prev_ymin, prev_ymax = 0.700, 0.980
    previous_regions = {
        "prev_establishment": (0.03, 0.22),
        "prev_uan": (0.22, 0.34),
        "prev_pf_account_no": (0.34, 0.48),
        "prev_date_of_joining": (0.48, 0.57),
        "prev_date_of_exit": (0.57, 0.66),
        "scheme_certificate_no": (0.66, 0.76),
        "ppo_no": (0.76, 0.86),
        "ncp_days": (0.86, 0.98),
    }
    for key, (x1, x2) in previous_regions.items():
        value = join_region(items, page, x1, x2, prev_ymin, prev_ymax)
        if value:
            fields[key] = value
    return fields


def extract_fields(raw_text: str, ocr_items: List[OCRItem] | None = None) -> Tuple[Dict[str, str], List[str]]:
    ocr_items = ocr_items or []
    layout_fields = extract_from_standard_form11_layout(ocr_items)

    # Add line-like OCR text so regex/fuzzy extraction has both reading order and layout order.
    layout_text = line_like_text(ocr_items) if ocr_items else ""
    combined_text = "\n".join(part for part in [layout_text, raw_text] if part).strip()
    text = normalize_ocr_text(combined_text).upper()
    lines = useful_lines(combined_text)
    fields = blank_fields()
    warnings: List[str] = []

    # Use layout extraction first because it avoids labels being pasted as values.
    fields.update({k: v for k, v in layout_fields.items() if v})

    email = regex_search(r"[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}", text)
    if email:
        fields["email_id"] = email

    pan = regex_search(r"\b[A-Z]{5}\d{4}[A-Z]\b", text)
    if pan:
        fields["pan_no"] = pan

    ifsc = regex_search(r"\b[A-Z]{4}0[A-Z0-9]{6}\b", text)
    if ifsc:
        fields["ifsc_code"] = ifsc

    # Dates in order: DOB, current DOJ, previous DOJ, previous DOE, passport from/to.
    dates = []
    for m in re.finditer(r"\b\d{1,2}\D+\d{1,2}\D+\d{2,4}\b", text):
        nd = normalize_date(m.group(0))
        if nd and nd not in dates:
            dates.append(nd)
    ordered_date_keys = ["dob", "date_of_joining", "prev_date_of_joining", "prev_date_of_exit", "passport_valid_from", "passport_valid_to"]
    for key, date in zip(ordered_date_keys, dates):
        if not fields.get(key):
            fields[key] = date

    digit_groups = re.findall(r"\b\d[\d\s\-]{7,}\d\b", text)
    normalized_digits = []
    for x in digit_groups:
        d = re.sub(r"\D", "", x)
        if len(d) >= 8 and d not in normalized_digits:
            normalized_digits.append(d)

    # Keep field-specific values from layout when present; otherwise infer.
    if not fields.get("mobile_no"):
        ten_digits = [x for x in normalized_digits if len(x) == 10]
        if ten_digits:
            fields["mobile_no"] = ten_digits[0]
    if not fields.get("aadhaar_no"):
        twelve_digits = [x for x in normalized_digits if len(x) == 12]
        if twelve_digits:
            fields["aadhaar_no"] = twelve_digits[-1]
    if not fields.get("bank_account_no"):
        used = {fields.get("mobile_no", ""), fields.get("aadhaar_no", ""), fields.get("prev_uan", "")}
        for d in normalized_digits:
            if 9 <= len(d) <= 18 and d not in used:
                fields["bank_account_no"] = d
                break

    # Fuzzy label fallback for empty fields only.
    for key, hints in LABEL_HINTS.items():
        if fields.get(key):
            continue
        value = value_after_label(lines, hints)
        if value:
            fields[key] = value

    # Cleanup / normalize values.
    fields["member_name"] = cleanup_name(fields.get("member_name", ""))
    fields["father_husband_name"] = cleanup_name(fields.get("father_husband_name", ""))
    fields["gender"] = normalize_choice(fields.get("gender", ""), ["MALE", "FEMALE", "TRANSGENDER"])
    fields["marital_status"] = normalize_choice(fields.get("marital_status", ""), ["MARRIED", "UNMARRIED", "WIDOW", "WIDOWER", "DIVORCEE"])
    fields["earlier_epf_member"] = normalize_yes_no(fields.get("earlier_epf_member", ""))
    fields["earlier_eps_member"] = normalize_yes_no(fields.get("earlier_eps_member", ""))
    fields["international_worker"] = normalize_yes_no(fields.get("international_worker", ""))

    # Digits-only cleanup.
    for key in ["mobile_no", "aadhaar_no", "bank_account_no", "prev_uan", "ncp_days"]:
        if fields.get(key):
            candidate = re.sub(r"\D", "", fields[key])
            fields[key] = candidate or fields[key]
    if fields.get("ifsc_code"):
        fields["ifsc_code"] = re.sub(r"[^A-Z0-9]", "", fields["ifsc_code"])
    if fields.get("pan_no"):
        fields["pan_no"] = re.sub(r"[^A-Z0-9]", "", fields["pan_no"])

    for k, v in fields.items():
        fields[k] = cleanup_alpha_num(v)

    # Validation warnings.
    if fields["mobile_no"] and not re.fullmatch(r"\d{10}", fields["mobile_no"]):
        warnings.append("Mobile number should be 10 digits")
    if fields["aadhaar_no"] and not re.fullmatch(r"\d{12}", fields["aadhaar_no"]):
        warnings.append("Aadhaar number should be 12 digits")
    if fields["pan_no"] and not re.fullmatch(r"[A-Z]{5}\d{4}[A-Z]", fields["pan_no"]):
        warnings.append("PAN format looks doubtful")
    if fields["ifsc_code"] and not re.fullmatch(r"[A-Z]{4}0[A-Z0-9]{6}", fields["ifsc_code"]):
        warnings.append("IFSC format looks doubtful")
    if not fields["member_name"]:
        warnings.append("Name of member was not confidently extracted. Please review manually.")
    if ocr_items and len(ocr_items) < 12:
        warnings.append("OCR found very few text boxes. Use a clearer 300 DPI scan if values are missing.")
    return fields, warnings


def extract_form11(path: Path) -> Dict:
    """Extract Form 11 handwritten/image data.

    Important: scanned Form 11 PDFs may contain printed labels as selectable text but the
    filled handwritten values are image-only. Therefore this function ALWAYS attempts
    AI OCR first for PDF/image uploads. Direct PDF text is kept only as supporting raw
    text, not as the primary source for handwritten values.
    """
    direct_text = extract_selectable_pdf_text(path) if path.suffix.lower() == ".pdf" else ""
    ocr_text, engine, ocr_items = image_or_pdf_to_ocr(path)

    raw_text = "\n".join(part for part in [ocr_text, direct_text] if part).strip()

    # Field extraction should be driven by OCR bounding boxes whenever possible. This
    # prevents printed labels like "NAME OF MEMBER" from being pasted as values.
    if ocr_items:
        fields, warnings = extract_fields(ocr_text, ocr_items)
    else:
        fields = blank_fields()
        warnings = ["AI OCR did not return text boxes. Install/run PaddleOCR or EasyOCR and use a clear 300 DPI scan."]
        if direct_text.strip():
            warnings.append("Direct PDF text was found, but it may contain only printed labels. Handwritten values need AI OCR.")

    if engine == "NO_OCR_LIBRARY":
        warnings.append("AI OCR libraries are not installed. Run install_ai_cpu.bat in backend venv.")
    if engine == "OCR_ERROR":
        warnings.append("OCR engine failed. See raw text/error output.")
    if not raw_text.strip():
        warnings.append("No text was extracted. Check whether OCR libraries are installed and the PDF/image is clear.")

    return {
        "engine": engine,
        "fields": fields,
        "warnings": warnings,
        "raw_text": raw_text,
    }
