@echo off
cd /d %~dp0
call venv\Scripts\activate
python -m pip install --upgrade pip setuptools wheel
REM CPU PaddlePaddle for laptops without NVIDIA GPU.
python -m pip install paddlepaddle -i https://www.paddlepaddle.org.cn/packages/stable/cpu/
pip install paddleocr easyocr
REM Optional advanced AI/document understanding libraries. These are heavy.
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu
pip install transformers sentence-transformers huggingface-hub accelerate unstructured[all-docs] python-doctr[torch] einops safetensors protobuf
pause
