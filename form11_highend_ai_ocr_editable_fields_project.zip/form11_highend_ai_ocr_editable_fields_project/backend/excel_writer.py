from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Tuple

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from extractor import FORM11_FIELDS, uppercase_value

HEADER_FILL = PatternFill("solid", fgColor="1F2937")
SECTION_FILL = PatternFill("solid", fgColor="E0F2FE")
LABEL_FILL = PatternFill("solid", fgColor="F3F4F6")
VALUE_FILL = PatternFill("solid", fgColor="FFF7D6")
THIN = Side(style="thin", color="111827")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)


def apply_common_style(ws):
    ws.sheet_view.showGridLines = False
    ws.sheet_view.zoomScale = 100
    ws.page_setup.paperSize = ws.PAPERSIZE_A4
    ws.page_setup.orientation = ws.ORIENTATION_PORTRAIT
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.freeze_panes = "A6"
    widths = {
        "A": 7, "B": 28, "C": 42, "D": 18, "E": 18,
    }
    for col, width in widths.items():
        ws.column_dimensions[col].width = width


def write_label_value(ws, row: int, no: str, label: str, value: str):
    ws.cell(row=row, column=1, value=no)
    ws.cell(row=row, column=2, value=label)
    ws.cell(row=row, column=3, value=uppercase_value(value))
    ws.merge_cells(start_row=row, start_column=3, end_row=row, end_column=5)
    for col in range(1, 6):
        cell = ws.cell(row=row, column=col)
        cell.border = BORDER
        cell.alignment = Alignment(vertical="center", wrap_text=True)
        cell.font = Font(name="Arial", size=10, bold=(col == 3))
        if col == 2:
            cell.fill = LABEL_FILL
        if col >= 3:
            cell.fill = VALUE_FILL
    ws.row_dimensions[row].height = 28


def create_form11_workbook(fields: Dict[str, str], output_path: Path, raw_text: str = "", warnings: List[str] | None = None):
    wb = Workbook()
    ws = wb.active
    ws.title = "FORM 11 DATA"
    apply_common_style(ws)

    ws.merge_cells("A1:E1")
    ws["A1"] = "FORM 11 EXTRACTED DATA"
    ws["A1"].font = Font(name="Arial", size=16, bold=True, color="FFFFFF")
    ws["A1"].fill = HEADER_FILL
    ws["A1"].alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 30

    ws.merge_cells("A2:E2")
    ws["A2"] = "Values are saved in CAPITAL LETTERS. Please verify OCR data before submission."
    ws["A2"].font = Font(name="Arial", size=10, italic=True, color="92400E")
    ws["A2"].fill = PatternFill("solid", fgColor="FEF3C7")
    ws["A2"].alignment = Alignment(horizontal="center", vertical="center")

    ws.merge_cells("A4:E4")
    ws["A4"] = "MEMBER AND KYC DETAILS"
    ws["A4"].font = Font(name="Arial", size=12, bold=True)
    ws["A4"].fill = SECTION_FILL
    ws["A4"].alignment = Alignment(horizontal="center", vertical="center")

    row = 5
    main_fields: List[Tuple[str, str, str]] = [
        ("1", "Name of the Member", "member_name"),
        ("2", "Father / Husband / Spouse Name", "father_husband_name"),
        ("3", "Date of Birth", "dob"),
        ("4", "Gender", "gender"),
        ("5", "Marital Status", "marital_status"),
        ("6(a)", "Email ID", "email_id"),
        ("6(b)", "Mobile Number", "mobile_no"),
        ("7", "Date of Joining", "date_of_joining"),
        ("8(a)", "Bank Account No", "bank_account_no"),
        ("8(b)", "IFSC Code", "ifsc_code"),
        ("8(c)", "Aadhaar Number", "aadhaar_no"),
        ("8(d)", "PAN Number", "pan_no"),
        ("9", "Earlier EPF Member", "earlier_epf_member"),
        ("10", "Earlier EPS Member", "earlier_eps_member"),
    ]
    for no, label, key in main_fields:
        write_label_value(ws, row, no, label, fields.get(key, ""))
        row += 1

    row += 1
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=5)
    ws.cell(row=row, column=1, value="PREVIOUS EMPLOYMENT DETAILS")
    ws.cell(row=row, column=1).font = Font(name="Arial", size=12, bold=True)
    ws.cell(row=row, column=1).fill = SECTION_FILL
    ws.cell(row=row, column=1).alignment = Alignment(horizontal="center")
    row += 1

    previous_fields: List[Tuple[str, str, str]] = [
        ("11(a)", "Previous Establishment Name & Address", "prev_establishment"),
        ("11(b)", "Previous UAN", "prev_uan"),
        ("11(c)", "Previous PF Account No", "prev_pf_account_no"),
        ("11(d)", "Previous Date of Joining", "prev_date_of_joining"),
        ("11(e)", "Previous Date of Exit", "prev_date_of_exit"),
        ("11(f)", "Scheme Certificate No", "scheme_certificate_no"),
        ("11(g)", "PPO Number", "ppo_no"),
        ("11(h)", "NCP Days", "ncp_days"),
    ]
    for no, label, key in previous_fields:
        write_label_value(ws, row, no, label, fields.get(key, ""))
        row += 1

    row += 1
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=5)
    ws.cell(row=row, column=1, value="INTERNATIONAL WORKER / PASSPORT DETAILS")
    ws.cell(row=row, column=1).font = Font(name="Arial", size=12, bold=True)
    ws.cell(row=row, column=1).fill = SECTION_FILL
    ws.cell(row=row, column=1).alignment = Alignment(horizontal="center")
    row += 1

    international_fields: List[Tuple[str, str, str]] = [
        ("13(a)", "International Worker", "international_worker"),
        ("13(b)", "Country of Origin", "country_origin"),
        ("13(c)", "Passport No", "passport_no"),
        ("13(d)", "Passport Valid From", "passport_valid_from"),
        ("13(e)", "Passport Valid To", "passport_valid_to"),
    ]
    for no, label, key in international_fields:
        write_label_value(ws, row, no, label, fields.get(key, ""))
        row += 1

    if warnings:
        row += 1
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=5)
        ws.cell(row=row, column=1, value="WARNINGS / REVIEW NOTES")
        ws.cell(row=row, column=1).font = Font(name="Arial", size=12, bold=True, color="991B1B")
        ws.cell(row=row, column=1).fill = PatternFill("solid", fgColor="FEE2E2")
        row += 1
        for w in warnings:
            ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=5)
            ws.cell(row=row, column=1, value=w)
            ws.cell(row=row, column=1).font = Font(name="Arial", size=10, color="991B1B")
            ws.cell(row=row, column=1).border = BORDER
            ws.cell(row=row, column=1).alignment = Alignment(wrap_text=True)
            row += 1

    raw = wb.create_sheet("RAW OCR TEXT")
    raw.sheet_view.showGridLines = False
    raw.column_dimensions["A"].width = 120
    raw["A1"] = "RAW OCR TEXT"
    raw["A1"].font = Font(name="Arial", size=14, bold=True)
    raw["A2"] = raw_text or ""
    raw["A2"].alignment = Alignment(wrap_text=True, vertical="top")
    raw.row_dimensions[2].height = 400

    wb.save(output_path)
    return output_path
