from __future__ import annotations

import json
import shutil
import uuid
import zipfile
from pathlib import Path
from typing import Dict, List

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel

from extractor import FORM11_FIELDS, extract_form11, uppercase_value
from excel_writer import create_form11_workbook

BASE_DIR = Path(__file__).parent
UPLOAD_DIR = BASE_DIR / "uploads"
OUTPUT_DIR = BASE_DIR / "outputs"
UPLOAD_DIR.mkdir(exist_ok=True)
OUTPUT_DIR.mkdir(exist_ok=True)

app = FastAPI(title="Form 11 AI OCR Editable Fields API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173", "*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

ALLOWED_SUFFIXES = {".pdf", ".png", ".jpg", ".jpeg", ".webp", ".tif", ".tiff"}


class ExcelRequest(BaseModel):
    file_id: str
    file_name: str
    fields: Dict[str, str]
    raw_text: str = ""
    warnings: List[str] = []


class ZipRequest(BaseModel):
    items: List[ExcelRequest]


@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.get("/api/fields")
def fields():
    return {"fields": [{"key": k, "label": label} for k, label in FORM11_FIELDS]}


@app.post("/api/extract")
async def extract(files: List[UploadFile] = File(...)):
    if not files:
        raise HTTPException(status_code=400, detail="Please upload at least one file")
    if len(files) > 10:
        raise HTTPException(status_code=400, detail="Maximum 10 files allowed")

    results = []
    for file in files:
        suffix = Path(file.filename or "").suffix.lower()
        if suffix not in ALLOWED_SUFFIXES:
            raise HTTPException(status_code=400, detail=f"Unsupported file type: {file.filename}")

        file_id = uuid.uuid4().hex
        safe_name = Path(file.filename or f"upload{suffix}").name
        stored_path = UPLOAD_DIR / f"{file_id}_{safe_name}"
        with stored_path.open("wb") as f:
            shutil.copyfileobj(file.file, f)

        extracted = extract_form11(stored_path)
        results.append({
            "file_id": file_id,
            "file_name": safe_name,
            "preview_url": f"/api/file/{file_id}",
            "engine": extracted["engine"],
            "fields": extracted["fields"],
            "warnings": extracted["warnings"],
            "raw_text": extracted["raw_text"],
        })
    return {"items": results}


@app.get("/api/file/{file_id}")
def get_file(file_id: str):
    candidates = list(UPLOAD_DIR.glob(f"{file_id}_*"))
    if not candidates:
        raise HTTPException(status_code=404, detail="File not found")
    path = candidates[0]
    return FileResponse(path, filename=path.name)


def safe_xlsx_name(name: str, suffix: str = "") -> str:
    base = Path(name).stem
    base = "".join(ch if ch.isalnum() or ch in ("-", "_") else "_" for ch in base)
    return f"{base}{suffix}_form11.xlsx"


@app.post("/api/download-excel")
def download_excel(req: ExcelRequest):
    fields = {k: uppercase_value(v) for k, v in req.fields.items()}
    out_name = safe_xlsx_name(req.file_name)
    out_path = OUTPUT_DIR / f"{uuid.uuid4().hex}_{out_name}"
    create_form11_workbook(fields, out_path, raw_text=req.raw_text, warnings=req.warnings)
    return FileResponse(
        out_path,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        filename=out_name,
    )


@app.post("/api/download-zip")
def download_zip(req: ZipRequest):
    if not req.items:
        raise HTTPException(status_code=400, detail="No records to download")
    zip_name = f"form11_workbooks_{uuid.uuid4().hex[:8]}.zip"
    zip_path = OUTPUT_DIR / zip_name
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for i, item in enumerate(req.items, start=1):
            fields = {k: uppercase_value(v) for k, v in item.fields.items()}
            xlsx_name = safe_xlsx_name(item.file_name, suffix=f"_{i}")
            xlsx_path = OUTPUT_DIR / f"{uuid.uuid4().hex}_{xlsx_name}"
            create_form11_workbook(fields, xlsx_path, raw_text=item.raw_text, warnings=item.warnings)
            zf.write(xlsx_path, xlsx_name)
    return FileResponse(zip_path, media_type="application/zip", filename=zip_name)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host="127.0.0.1", port=8000, reload=True)
