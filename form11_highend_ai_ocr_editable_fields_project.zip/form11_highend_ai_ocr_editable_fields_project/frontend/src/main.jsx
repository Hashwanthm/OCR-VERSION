import React from 'react';
import { createRoot } from 'react-dom/client';
import { Upload, FileText, Download, Archive, RefreshCcw, AlertTriangle } from 'lucide-react';
import './styles.css';

const API_BASE = 'http://127.0.0.1:8000';

const FIELD_GROUPS = [
  {
    title: 'Member Details',
    fields: [
      ['member_name', 'Name of Member'],
      ['father_husband_name', 'Father / Husband Name'],
      ['dob', 'Date of Birth'],
      ['gender', 'Gender'],
      ['marital_status', 'Marital Status'],
      ['email_id', 'Email ID'],
      ['mobile_no', 'Mobile Number'],
      ['date_of_joining', 'Date of Joining'],
    ],
  },
  {
    title: 'KYC Details',
    fields: [
      ['bank_account_no', 'Bank Account No'],
      ['ifsc_code', 'IFSC Code'],
      ['aadhaar_no', 'Aadhaar Number'],
      ['pan_no', 'PAN Number'],
    ],
  },
  {
    title: 'Previous Employment Details',
    fields: [
      ['earlier_epf_member', 'Earlier EPF Member'],
      ['earlier_eps_member', 'Earlier EPS Member'],
      ['prev_establishment', 'Previous Establishment Name & Address'],
      ['prev_uan', 'Previous UAN'],
      ['prev_pf_account_no', 'Previous PF Account No'],
      ['prev_date_of_joining', 'Previous Date of Joining'],
      ['prev_date_of_exit', 'Previous Date of Exit'],
      ['scheme_certificate_no', 'Scheme Certificate No'],
      ['ppo_no', 'PPO Number'],
      ['ncp_days', 'NCP Days'],
    ],
  },
  {
    title: 'International Worker / Passport',
    fields: [
      ['international_worker', 'International Worker'],
      ['country_origin', 'Country of Origin'],
      ['passport_no', 'Passport No'],
      ['passport_valid_from', 'Passport Valid From'],
      ['passport_valid_to', 'Passport Valid To'],
    ],
  },
];

function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function App() {
  const [files, setFiles] = React.useState([]);
  const [localPreviews, setLocalPreviews] = React.useState([]);
  const [items, setItems] = React.useState([]);
  const [selectedIndex, setSelectedIndex] = React.useState(0);
  const [loading, setLoading] = React.useState(false);
  const [status, setStatus] = React.useState('Ready');
  const [showRaw, setShowRaw] = React.useState(false);

  const selectedItem = items[selectedIndex] || null;
  const selectedFile = files[selectedIndex] || null;
  const previewUrl = selectedItem
    ? `${API_BASE}${selectedItem.preview_url}`
    : localPreviews[selectedIndex] || '';

  function handleFiles(event) {
    const chosen = Array.from(event.target.files || []);
    if (chosen.length > 10) {
      alert('Maximum 10 files allowed.');
      return;
    }
    setFiles(chosen);
    setItems([]);
    setSelectedIndex(0);
    setStatus(chosen.length ? `${chosen.length} file(s) selected. Click Extract.` : 'Ready');
    localPreviews.forEach((url) => URL.revokeObjectURL(url));
    setLocalPreviews(chosen.map((file) => URL.createObjectURL(file)));
  }

  async function extractFiles() {
    if (!files.length) {
      alert('Please choose at least one PDF/image.');
      return;
    }
    setLoading(true);
    setStatus('Extracting handwritten data using high-end AI OCR...');
    try {
      const formData = new FormData();
      files.forEach((file) => formData.append('files', file));
      const response = await fetch(`${API_BASE}/api/extract`, {
        method: 'POST',
        body: formData,
      });
      if (!response.ok) {
        const error = await response.json().catch(() => ({}));
        throw new Error(error.detail || 'Extraction failed');
      }
      const data = await response.json();
      setItems(data.items || []);
      setSelectedIndex(0);
      setStatus(`${data.items?.length || 0} file(s) extracted. Review/edit fields before Excel download.`);
    } catch (error) {
      setStatus(`Error: ${error.message}`);
    } finally {
      setLoading(false);
    }
  }

  function updateField(key, value) {
    setItems((prev) => {
      const copy = [...prev];
      const item = { ...copy[selectedIndex] };
      item.fields = { ...item.fields, [key]: value.toUpperCase() };
      copy[selectedIndex] = item;
      return copy;
    });
  }

  async function downloadSelectedExcel() {
    if (!selectedItem) {
      alert('Extract the file first.');
      return;
    }
    setStatus('Creating Excel workbook...');
    const response = await fetch(`${API_BASE}/api/download-excel`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(selectedItem),
    });
    if (!response.ok) {
      setStatus('Excel download failed.');
      return;
    }
    const blob = await response.blob();
    downloadBlob(blob, `${selectedItem.file_name.replace(/\.[^.]+$/, '')}_form11.xlsx`);
    setStatus('Excel workbook downloaded.');
  }

  async function downloadZip() {
    if (!items.length) {
      alert('Extract files first.');
      return;
    }
    setStatus('Creating ZIP file...');
    const response = await fetch(`${API_BASE}/api/download-zip`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ items }),
    });
    if (!response.ok) {
      setStatus('ZIP download failed.');
      return;
    }
    const blob = await response.blob();
    downloadBlob(blob, 'form11_workbooks.zip');
    setStatus('ZIP downloaded.');
  }

  const fileOptions = items.length ? items : files.map((file, index) => ({ file_name: file.name, file_id: index }));

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">FORM 11 AI OCR</div>
        <div className="actions">
          <label className="upload-pill">
            <Upload size={16} /> Upload PDFs / Images (max 10)
            <input hidden type="file" accept=".pdf,.png,.jpg,.jpeg,.webp,.tif,.tiff" multiple onChange={handleFiles} />
          </label>
          <span className="count-pill">{files.length} / 10 files selected</span>
          <button className="primary" disabled={loading || !files.length} onClick={extractFiles}>
            {loading ? <RefreshCcw size={16} className="spin" /> : <FileText size={16} />} Extract AI OCR
          </button>
        </div>
      </header>

      <main className="workspace">
        <section className="panel document-panel">
          <div className="panel-header">
            <h2>PDF / Image Preview</h2>
            <select value={selectedIndex} onChange={(e) => setSelectedIndex(Number(e.target.value))}>
              {fileOptions.length === 0 && <option>No file selected</option>}
              {fileOptions.map((item, index) => (
                <option key={item.file_id || index} value={index}>
                  {index + 1}. {item.file_name}
                </option>
              ))}
            </select>
          </div>
          <div className="preview-box">
            {!previewUrl && <div className="empty">Upload Form 11 PDF or image to preview here.</div>}
            {previewUrl && (selectedFile?.type?.startsWith('image/') || /\.(png|jpg|jpeg|webp|tif|tiff)$/i.test(selectedItem?.file_name || selectedFile?.name || '')) && (
              <img src={previewUrl} alt="Uploaded preview" className="image-preview" />
            )}
            {previewUrl && /\.pdf$/i.test(selectedItem?.file_name || selectedFile?.name || '') && (
              <iframe src={previewUrl} title="PDF Preview" className="pdf-preview" />
            )}
          </div>
        </section>

        <section className="panel fields-panel">
          <div className="panel-header fields-header">
            <div>
              <h2>Editable Extracted Fields</h2>
              <p>{selectedItem ? `AI Engine: ${selectedItem.engine}` : 'Extracted values will appear here.'}</p>
            </div>
            <div className="download-actions">
              <button className="success" disabled={!selectedItem} onClick={downloadSelectedExcel}>
                <Download size={15} /> Save Excel
              </button>
              <button className="success" disabled={!items.length} onClick={downloadZip}>
                <Archive size={15} /> ZIP
              </button>
            </div>
          </div>

          {selectedItem?.warnings?.length > 0 && (
            <div className="warning-box">
              <AlertTriangle size={16} />
              <div>
                <strong>Review needed</strong>
                {selectedItem.warnings.map((warning, index) => (
                  <p key={index}>{warning}</p>
                ))}
              </div>
            </div>
          )}

          {!selectedItem && (
            <div className="empty fields-empty">Upload and click Extract AI OCR. Then edit fields here and save Excel.</div>
          )}

          {selectedItem && (
            <div className="form-scroll">
              {FIELD_GROUPS.map((group) => (
                <div className="field-group" key={group.title}>
                  <h3>{group.title}</h3>
                  <div className="field-grid">
                    {group.fields.map(([key, label]) => (
                      <label className="field" key={key}>
                        <span>{label}</span>
                        {key === 'prev_establishment' ? (
                          <textarea
                            value={selectedItem.fields?.[key] || ''}
                            onChange={(e) => updateField(key, e.target.value)}
                          />
                        ) : (
                          <input
                            value={selectedItem.fields?.[key] || ''}
                            onChange={(e) => updateField(key, e.target.value)}
                          />
                        )}
                      </label>
                    ))}
                  </div>
                </div>
              ))}

              <button className="raw-toggle" onClick={() => setShowRaw((v) => !v)}>
                {showRaw ? 'Hide Raw OCR Text' : 'Show Raw OCR Text'}
              </button>
              {showRaw && <pre className="raw-text">{selectedItem.raw_text || 'No raw OCR text.'}</pre>}
            </div>
          )}
        </section>
      </main>

      <footer className={`status ${status.startsWith('Error') ? 'error' : ''}`}>{status}</footer>
    </div>
  );
}

createRoot(document.getElementById('root')).render(<App />);
