from pathlib import Path
import hashlib
import os
import re
import time
import uuid
from zipfile import ZipFile, ZIP_DEFLATED

from flask import Flask, jsonify, render_template, request, send_from_directory
from werkzeug.utils import secure_filename

from PIL import Image, ImageOps, ImageFilter
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

try:
    import fitz  # PyMuPDF
except Exception:
    fitz = None

try:
    import easyocr
except Exception:
    easyocr = None

try:
    import cv2
    import numpy as np
except Exception:
    cv2 = None
    np = None

# Optional common Python libraries used for better validation/export.
# The app still runs if optional modules are unavailable, but installing
# requirements.txt gives the complete setup.
try:
    import pandas as pd
except Exception:
    pd = None

try:
    from dateutil import parser as date_parser
except Exception:
    date_parser = None

try:
    from rapidfuzz import fuzz, process
except Exception:
    fuzz = None
    process = None


app = Flask(__name__)

BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = BASE_DIR / "uploads"
OUTPUT_DIR = BASE_DIR / "outputs"
PREVIEW_DIR = OUTPUT_DIR / "previews"

for folder in (UPLOAD_DIR, OUTPUT_DIR, PREVIEW_DIR):
    folder.mkdir(exist_ok=True)

MAX_FILES = 10
ALLOWED_EXTENSIONS = {"pdf", "png", "jpg", "jpeg", "webp", "tif", "tiff"}

# EasyOCR is used so no separate Tesseract installation is required.
# The first run may download the English OCR model. After the model is cached,
# the OCR can run locally/offline on the same computer.
_easyocr_reader = None

def get_ocr_reader():
    global _easyocr_reader
    if easyocr is None:
        raise RuntimeError("EasyOCR is not installed. Run: pip install -r requirements.txt")
    if _easyocr_reader is None:
        # gpu=False keeps setup simple for office laptops.
        _easyocr_reader = easyocr.Reader(["en"], gpu=False, verbose=False)
    return _easyocr_reader


FIELD_ORDER = [
    "NAME_OF_MEMBER",
    "FATHER_OR_SPOUSE_NAME",
    "DATE_OF_BIRTH",
    "GENDER",
    "MARITAL_STATUS",
    "EMAIL_ID",
    "MOBILE_NO",
    "DATE_OF_JOINING",
    "BANK_ACCOUNT_NO",
    "IFSC_CODE",
    "AADHAAR_NO",
    "PAN_NO",
    "EPF_SCHEME_MEMBER",
    "EPS_SCHEME_MEMBER",
    "PREVIOUS_ESTABLISHMENT_NAME_ADDRESS",
    "PREVIOUS_UAN",
    "PREVIOUS_PF_ACCOUNT_NO",
    "PREVIOUS_DATE_OF_JOINING",
    "PREVIOUS_DATE_OF_EXIT",
    "PREVIOUS_NCP_DAYS",
    "PREVIOUS_TRUST_NAME_ADDRESS",
    "PREVIOUS_TRUST_UAN",
    "PREVIOUS_TRUST_MEMBER_ID",
    "PREVIOUS_TRUST_DATE_OF_JOINING",
    "PREVIOUS_TRUST_DATE_OF_EXIT",
    "INTERNATIONAL_WORKER",
    "COUNTRY_OF_ORIGIN",
    "PASSPORT_NO",
    "PASSPORT_VALID_FROM",
    "PASSPORT_VALID_TO",
]

FIELD_LABELS = {
    "NAME_OF_MEMBER": "Name of the member",
    "FATHER_OR_SPOUSE_NAME": "Father's / Spouse's Name",
    "DATE_OF_BIRTH": "Date of Birth",
    "GENDER": "Gender",
    "MARITAL_STATUS": "Marital Status",
    "EMAIL_ID": "Email ID",
    "MOBILE_NO": "Mobile No.",
    "DATE_OF_JOINING": "Date of Joining",
    "BANK_ACCOUNT_NO": "Bank Account No.",
    "IFSC_CODE": "IFS Code of the Branch",
    "AADHAAR_NO": "AADHAAR Number",
    "PAN_NO": "PAN Number",
    "EPF_SCHEME_MEMBER": "Earlier EPF Scheme Member",
    "EPS_SCHEME_MEMBER": "Earlier EPS Scheme Member",
    "PREVIOUS_ESTABLISHMENT_NAME_ADDRESS": "Previous Establishment Name & Address",
    "PREVIOUS_UAN": "Previous UAN",
    "PREVIOUS_PF_ACCOUNT_NO": "Previous PF Account Number",
    "PREVIOUS_DATE_OF_JOINING": "Previous Date of Joining",
    "PREVIOUS_DATE_OF_EXIT": "Previous Date of Exit",
    "PREVIOUS_NCP_DAYS": "Previous NCP Days",
    "PREVIOUS_TRUST_NAME_ADDRESS": "Previous Exempted Trust Name & Address",
    "PREVIOUS_TRUST_UAN": "Previous Trust UAN",
    "PREVIOUS_TRUST_MEMBER_ID": "Previous Trust Member ID",
    "PREVIOUS_TRUST_DATE_OF_JOINING": "Previous Trust Date of Joining",
    "PREVIOUS_TRUST_DATE_OF_EXIT": "Previous Trust Date of Exit",
    "INTERNATIONAL_WORKER": "International Worker",
    "COUNTRY_OF_ORIGIN": "Country of Origin",
    "PASSPORT_NO": "Passport No.",
    "PASSPORT_VALID_FROM": "Passport Valid From",
    "PASSPORT_VALID_TO": "Passport Valid To",
}

# Approximate regions for EPFO Form-11 first page.
# Coordinates are percentages of page width/height: x1, y1, x2, y2.
# These help handwritten OCR by reading only the handwritten/value area.
FIELD_REGIONS = {
    "NAME_OF_MEMBER": (0.49, 0.105, 0.90, 0.145),
    "FATHER_OR_SPOUSE_NAME": (0.49, 0.145, 0.90, 0.190),
    "DATE_OF_BIRTH": (0.49, 0.195, 0.88, 0.235),
    "GENDER": (0.49, 0.235, 0.88, 0.275),
    "MARITAL_STATUS": (0.49, 0.275, 0.88, 0.315),
    "EMAIL_ID": (0.49, 0.315, 0.90, 0.355),
    "MOBILE_NO": (0.49, 0.355, 0.88, 0.405),
    "DATE_OF_JOINING": (0.49, 0.405, 0.88, 0.455),
    "BANK_ACCOUNT_NO": (0.49, 0.505, 0.88, 0.545),
    "IFSC_CODE": (0.49, 0.545, 0.88, 0.585),
    "AADHAAR_NO": (0.49, 0.585, 0.88, 0.625),
    "PAN_NO": (0.49, 0.625, 0.88, 0.665),
    "EPF_SCHEME_MEMBER": (0.74, 0.665, 0.86, 0.705),
    "EPS_SCHEME_MEMBER": (0.74, 0.700, 0.86, 0.740),
    "PREVIOUS_ESTABLISHMENT_NAME_ADDRESS": (0.04, 0.755, 0.18, 0.865),
    "PREVIOUS_UAN": (0.18, 0.755, 0.27, 0.865),
    "PREVIOUS_PF_ACCOUNT_NO": (0.27, 0.755, 0.40, 0.865),
    "PREVIOUS_DATE_OF_JOINING": (0.40, 0.755, 0.51, 0.865),
    "PREVIOUS_DATE_OF_EXIT": (0.51, 0.755, 0.62, 0.865),
    "PREVIOUS_NCP_DAYS": (0.83, 0.755, 0.94, 0.865),
    "INTERNATIONAL_WORKER": (0.66, 0.865, 0.82, 0.905),
    "COUNTRY_OF_ORIGIN": (0.50, 0.900, 0.90, 0.935),
    "PASSPORT_NO": (0.50, 0.930, 0.90, 0.965),
    "PASSPORT_VALID_FROM": (0.50, 0.960, 0.68, 0.992),
    "PASSPORT_VALID_TO": (0.68, 0.960, 0.90, 0.992),
}


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def file_hash(file_path):
    digest = hashlib.sha256()
    with open(file_path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def uppercase_value(value):
    value = "" if value is None else str(value)
    value = value.replace("\n", " ").replace("\r", " ")
    value = re.sub(r"\s+", " ", value).strip()
    return value.upper()


def clean_ocr_value(value):
    value = uppercase_value(value)
    value = value.replace("|", " ").replace("—", "-").replace("_", " ")
    value = re.sub(r"[^A-Z0-9@./,()&+\-\s:]", "", value)
    value = re.sub(r"\s+", " ", value).strip()
    return value


def image_from_upload(path):
    ext = path.suffix.lower().replace(".", "")
    if ext == "pdf":
        if fitz is None:
            raise RuntimeError("PyMuPDF is not installed. Install requirements.txt first.")
        doc = fitz.open(str(path))
        if len(doc) == 0:
            raise RuntimeError("PDF has no pages.")
        page = doc[0]
        # 2.5x improves OCR for handwritten/scanned forms.
        matrix = fitz.Matrix(2.5, 2.5)
        pix = page.get_pixmap(matrix=matrix, alpha=False)
        preview_path = PREVIEW_DIR / f"{path.stem}_{uuid.uuid4().hex[:8]}.png"
        pix.save(str(preview_path))
        doc.close()
        return Image.open(preview_path).convert("RGB"), preview_path.name

    image = Image.open(path).convert("RGB")
    preview_path = PREVIEW_DIR / f"{path.stem}_{uuid.uuid4().hex[:8]}.png"
    image.save(preview_path)
    return image, preview_path.name


def preprocess_image(image):
    image = ImageOps.exif_transpose(image).convert("RGB")

    # enlarge small scans/images
    w, h = image.size
    if max(w, h) < 1800:
        scale = 1800 / max(w, h)
        image = image.resize((int(w * scale), int(h * scale)), Image.LANCZOS)

    gray = ImageOps.grayscale(image)
    gray = ImageOps.autocontrast(gray)
    gray = gray.filter(ImageFilter.SHARPEN)

    if cv2 is not None and np is not None:
        arr = np.array(gray)
        arr = cv2.fastNlMeansDenoising(arr, None, 18, 7, 21)
        arr = cv2.adaptiveThreshold(
            arr,
            255,
            cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
            cv2.THRESH_BINARY,
            35,
            11,
        )
        return Image.fromarray(arr)

    return gray


def run_easyocr(image, allowlist=None, paragraph=True):
    """Read text from a PIL image using EasyOCR.

    EasyOCR does not need the external Tesseract installer. It works directly
    from Python packages and is better suited for scanned/handwritten input
    than direct PDF text extraction.
    """
    reader = get_ocr_reader()
    if np is not None:
        image_data = np.array(image.convert("RGB"))
    else:
        image_data = image.convert("RGB")

    result = reader.readtext(
        image_data,
        detail=1,
        paragraph=paragraph,
        allowlist=allowlist,
        decoder="beamsearch",
    )

    lines = []
    for item in result:
        if len(item) >= 2:
            lines.append(str(item[1]))
    return "\n".join(lines)


def run_tesseract(image, psm=6, whitelist=None):
    # Kept as a compatibility wrapper so the rest of the app code remains stable.
    # It now calls EasyOCR, not Tesseract.
    return run_easyocr(image, allowlist=whitelist, paragraph=(psm not in [7, 8]))


def ocr_confidence(image):
    try:
        reader = get_ocr_reader()
        image_data = np.array(image.convert("RGB")) if np is not None else image.convert("RGB")
        result = reader.readtext(image_data, detail=1, paragraph=False)
        scores = []
        for item in result:
            if len(item) >= 3:
                try:
                    scores.append(float(item[2]) * 100)
                except Exception:
                    pass
        if not scores:
            return 0
        return round(sum(scores) / len(scores), 1)
    except Exception:
        return 0


def crop_by_ratio(image, ratio_box):
    w, h = image.size
    x1, y1, x2, y2 = ratio_box
    # Expand crop slightly for handwriting strokes.
    pad_x = int(w * 0.006)
    pad_y = int(h * 0.004)
    box = (
        max(0, int(w * x1) - pad_x),
        max(0, int(h * y1) - pad_y),
        min(w, int(w * x2) + pad_x),
        min(h, int(h * y2) + pad_y),
    )
    return image.crop(box)


def normalize_date(value):
    value = clean_ocr_value(value)
    match = re.search(r"(\d{1,2})\D+(\d{1,2})\D+(\d{2,4})", value)
    if match:
        dd, mm, yy = match.groups()
        if len(yy) == 2:
            yy = "19" + yy if int(yy) > 30 else "20" + yy
        return f"{int(dd):02d}/{int(mm):02d}/{yy}"

    # dateutil is a widely used Python date parser. It helps when OCR
    # reads dates with different separators or text noise.
    if date_parser and value:
        try:
            parsed = date_parser.parse(value, dayfirst=True, fuzzy=True)
            return parsed.strftime("%d/%m/%Y")
        except Exception:
            pass
    return value



def normalize_yes_no(value):
    """Normalize handwritten/OCR output to YES or NO when possible."""
    value = clean_ocr_value(value)
    if not value:
        return value
    compact = value.replace(" ", "")
    direct = {"YES", "Y", "NO", "N"}
    if compact in direct:
        return "YES" if compact in {"YES", "Y"} else "NO"
    if process:
        match = process.extractOne(compact, ["YES", "NO"], scorer=fuzz.ratio)
        if match and match[1] >= 70:
            return match[0]
    return value

def parse_regex_fallback(raw_text, fields):
    text = uppercase_value(raw_text)

    email = re.search(r"[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}", text)
    if email and not fields.get("EMAIL_ID"):
        fields["EMAIL_ID"] = email.group(0)

    mobiles = re.findall(r"\b[6-9]\d{9}\b", text)
    if mobiles and not fields.get("MOBILE_NO"):
        fields["MOBILE_NO"] = mobiles[0]

    aadhaar = re.search(r"\b\d{4}\s?\d{4}\s?\d{4}\b", text)
    if aadhaar and not fields.get("AADHAAR_NO"):
        fields["AADHAAR_NO"] = re.sub(r"\s+", "", aadhaar.group(0))

    pan = re.search(r"\b[A-Z]{5}\d{4}[A-Z]\b", text)
    if pan and not fields.get("PAN_NO"):
        fields["PAN_NO"] = pan.group(0)

    ifsc = re.search(r"\b[A-Z]{4}0[A-Z0-9]{6}\b", text)
    if ifsc and not fields.get("IFSC_CODE"):
        fields["IFSC_CODE"] = ifsc.group(0)

    dates = re.findall(r"\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b", text)
    if dates:
        if not fields.get("DATE_OF_BIRTH"):
            fields["DATE_OF_BIRTH"] = normalize_date(dates[0])
        if len(dates) > 1 and not fields.get("DATE_OF_JOINING"):
            fields["DATE_OF_JOINING"] = normalize_date(dates[1])

    # Find long numeric account numbers, excluding Aadhaar/mobile where possible.
    nums = re.findall(r"\b\d{9,18}\b", text)
    for num in nums:
        if num not in [fields.get("AADHAAR_NO", ""), fields.get("MOBILE_NO", "")]:
            if not fields.get("BANK_ACCOUNT_NO"):
                fields["BANK_ACCOUNT_NO"] = num
                break

    yes_no_matches = re.findall(r"\b(YES|NO)\b", text)
    if yes_no_matches:
        if not fields.get("EPF_SCHEME_MEMBER"):
            fields["EPF_SCHEME_MEMBER"] = yes_no_matches[0]
        if len(yes_no_matches) > 1 and not fields.get("EPS_SCHEME_MEMBER"):
            fields["EPS_SCHEME_MEMBER"] = yes_no_matches[1]

    passport = re.search(r"\b[A-Z][0-9]{7}\b", text)
    if passport and not fields.get("PASSPORT_NO"):
        fields["PASSPORT_NO"] = passport.group(0)

    return fields


def extract_form11_fields(image):
    processed = preprocess_image(image)
    raw_text = run_tesseract(processed, psm=6)
    raw_text_alt = run_tesseract(processed, psm=11)
    combined_raw = raw_text + "\n" + raw_text_alt

    fields = {key: "" for key in FIELD_ORDER}
    crop_texts = {}

    for key, ratio_box in FIELD_REGIONS.items():
        crop = crop_by_ratio(image, ratio_box)
        crop_processed = preprocess_image(crop)
        whitelist = None
        if "DATE" in key or key in ["MOBILE_NO", "AADHAAR_NO", "BANK_ACCOUNT_NO", "PREVIOUS_NCP_DAYS"]:
            whitelist = "0123456789/-"
        elif key in ["PAN_NO", "IFSC_CODE", "PASSPORT_NO"]:
            whitelist = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"

        try:
            crop_text = run_tesseract(crop_processed, psm=7, whitelist=whitelist)
        except Exception:
            crop_text = ""
        cleaned = clean_ocr_value(crop_text)
        if key in ["DATE_OF_BIRTH", "DATE_OF_JOINING", "PREVIOUS_DATE_OF_JOINING", "PREVIOUS_DATE_OF_EXIT", "PASSPORT_VALID_FROM", "PASSPORT_VALID_TO"]:
            cleaned = normalize_date(cleaned)
        if key in ["EPF_SCHEME_MEMBER", "EPS_SCHEME_MEMBER", "INTERNATIONAL_WORKER"]:
            cleaned = normalize_yes_no(cleaned)
        fields[key] = cleaned
        crop_texts[key] = cleaned

    fields = parse_regex_fallback(combined_raw, fields)
    confidence = ocr_confidence(processed)

    # Make final values uppercase and clean.
    for key in fields:
        fields[key] = clean_ocr_value(fields.get(key, ""))

    return fields, combined_raw, crop_texts, confidence


def create_form11_workbook(fields, raw_text, source_name, confidence):
    wb = Workbook()
    ws = wb.active
    ws.title = "FORM 11 OCR DATA"
    raw_ws = wb.create_sheet("RAW OCR TEXT")

    ws.sheet_view.showGridLines = False
    raw_ws.sheet_view.showGridLines = False

    thin = Side(style="thin", color="444444")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    header_fill = PatternFill("solid", fgColor="1F4E78")
    section_fill = PatternFill("solid", fgColor="D9EAF7")
    value_fill = PatternFill("solid", fgColor="FFF2CC")

    ws.merge_cells("A1:D1")
    ws["A1"] = "COMPOSITE DECLARATION FORM - 11 OCR EXTRACTION"
    ws["A1"].font = Font(bold=True, size=14, color="FFFFFF")
    ws["A1"].fill = header_fill
    ws["A1"].alignment = Alignment(horizontal="center")

    ws["A3"] = "SOURCE FILE"
    ws["B3"] = source_name.upper()
    ws["C3"] = "OCR CONFIDENCE"
    ws["D3"] = f"{confidence}%"

    for cell in ["A3", "C3"]:
        ws[cell].font = Font(bold=True)
        ws[cell].fill = section_fill
    for cell in ["B3", "D3"]:
        ws[cell].fill = value_fill

    ws.append([])
    ws.append(["SL.NO", "FIELD", "EXTRACTED VALUE", "REVIEW / CORRECTION"])
    header_row = ws.max_row
    for cell in ws[header_row]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = border

    for idx, key in enumerate(FIELD_ORDER, start=1):
        value = uppercase_value(fields.get(key, ""))
        ws.append([idx, FIELD_LABELS[key].upper(), value, ""])
        row = ws.max_row
        for cell in ws[row]:
            cell.border = border
            cell.alignment = Alignment(vertical="top", wrap_text=True)
        ws.cell(row=row, column=1).alignment = Alignment(horizontal="center", vertical="top")
        ws.cell(row=row, column=3).fill = value_fill
        ws.cell(row=row, column=3).font = Font(bold=True)

    ws.freeze_panes = "A6"
    ws.column_dimensions["A"].width = 8
    ws.column_dimensions["B"].width = 38
    ws.column_dimensions["C"].width = 52
    ws.column_dimensions["D"].width = 36
    for row in range(1, ws.max_row + 1):
        ws.row_dimensions[row].height = 22

    ws.page_setup.paperSize = ws.PAPERSIZE_A4
    ws.page_setup.orientation = ws.ORIENTATION_LANDSCAPE
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_view.zoomScale = 100

    raw_ws["A1"] = "RAW OCR TEXT"
    raw_ws["A1"].font = Font(bold=True, size=14)
    raw_ws["A3"] = uppercase_value(raw_text)
    raw_ws["A3"].alignment = Alignment(wrap_text=True, vertical="top")
    raw_ws.column_dimensions["A"].width = 140
    raw_ws.row_dimensions[3].height = 400

    # pandas is used to create a clean field table model. The workbook
    # already contains the formatted sheet above; this extra sheet gives
    # a simple machine-readable view of the extracted data.
    if pd is not None:
        df_ws = wb.create_sheet("DATA TABLE")
        data = pd.DataFrame([
            {
                "FIELD_KEY": key,
                "FIELD_LABEL": FIELD_LABELS[key].upper(),
                "VALUE": uppercase_value(fields.get(key, "")),
            }
            for key in FIELD_ORDER
        ])
        df_ws.append(list(data.columns))
        for row in data.itertuples(index=False):
            df_ws.append(list(row))
        for row in df_ws.iter_rows():
            for cell in row:
                cell.border = border
                cell.alignment = Alignment(vertical="top", wrap_text=True)
        for cell in df_ws[1]:
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = header_fill
        df_ws.column_dimensions["A"].width = 30
        df_ws.column_dimensions["B"].width = 42
        df_ws.column_dimensions["C"].width = 60
        df_ws.freeze_panes = "A2"
        df_ws.sheet_view.showGridLines = False

    return wb


def save_workbook(fields, raw_text, source_name, confidence):
    safe_source = secure_filename(Path(source_name).stem)[:80] or "form11"
    output_name = f"{safe_source}_form11_ocr_{uuid.uuid4().hex[:10]}.xlsx"
    output_path = OUTPUT_DIR / output_name
    wb = create_form11_workbook(fields, raw_text, source_name, confidence)
    wb.save(output_path)
    return output_name


def cleanup_old_files():
    cutoff = time.time() - 60 * 60 * 8
    for folder in [UPLOAD_DIR, OUTPUT_DIR, PREVIEW_DIR]:
        for path in folder.glob("*"):
            if path.is_file() and path.stat().st_mtime < cutoff:
                try:
                    path.unlink()
                except Exception:
                    pass


@app.route("/")
def index():
    return render_template("index.html", max_files=MAX_FILES, field_order=FIELD_ORDER, field_labels=FIELD_LABELS)


@app.route("/outputs/<path:filename>")
def output_file(filename):
    return send_from_directory(OUTPUT_DIR, filename, as_attachment=False)


@app.route("/previews/<path:filename>")
def preview_file(filename):
    return send_from_directory(PREVIEW_DIR, filename, as_attachment=False)


@app.route("/convert", methods=["POST"])
def convert_files():
    cleanup_old_files()

    if "files" not in request.files:
        return jsonify({"success": False, "error": "No files uploaded."}), 400

    files = request.files.getlist("files")
    if not files:
        return jsonify({"success": False, "error": "Please upload at least one file."}), 400

    if len(files) > MAX_FILES:
        return jsonify({"success": False, "error": f"Maximum {MAX_FILES} files allowed."}), 400

    if easyocr is None:
        return jsonify({
            "success": False,
            "error": "EasyOCR is not installed. Run: pip install -r requirements.txt"
        }), 500

    seen_hashes = set()
    results = []
    zip_name = f"form11_ocr_workbooks_{uuid.uuid4().hex[:12]}.zip"
    zip_path = OUTPUT_DIR / zip_name

    workbook_names = []

    for upload in files:
        original_name = upload.filename or "uploaded_file"
        if not allowed_file(original_name):
            results.append({
                "success": False,
                "filename": original_name,
                "error": "Unsupported file type. Use PDF, PNG, JPG, JPEG, WEBP or TIFF."
            })
            continue

        safe_name = f"{uuid.uuid4().hex[:8]}_{secure_filename(original_name)}"
        upload_path = UPLOAD_DIR / safe_name
        upload.save(upload_path)

        digest = file_hash(upload_path)
        if digest in seen_hashes:
            upload_path.unlink(missing_ok=True)
            results.append({
                "success": False,
                "filename": original_name,
                "error": "Duplicate file detected."
            })
            continue
        seen_hashes.add(digest)

        try:
            image, preview_name = image_from_upload(upload_path)
            fields, raw_text, crop_texts, confidence = extract_form11_fields(image)
            workbook_name = save_workbook(fields, raw_text, original_name, confidence)
            workbook_names.append(workbook_name)
            results.append({
                "success": True,
                "filename": original_name,
                "preview_url": f"/previews/{preview_name}",
                "workbook_name": workbook_name,
                "workbook_url": f"/outputs/{workbook_name}",
                "fields": fields,
                "raw_text": uppercase_value(raw_text),
                "confidence": confidence,
                "message": "OCR completed. Please review handwritten values before using the Excel."
            })
        except Exception as exc:
            results.append({
                "success": False,
                "filename": original_name,
                "error": str(exc)
            })

    if workbook_names:
        with ZipFile(zip_path, "w", ZIP_DEFLATED) as zipf:
            for workbook_name in workbook_names:
                zipf.write(OUTPUT_DIR / workbook_name, workbook_name)

    return jsonify({
        "success": bool(workbook_names),
        "results": results,
        "zip_url": f"/outputs/{zip_name}" if workbook_names else "",
        "zip_name": zip_name if workbook_names else "",
        "field_order": FIELD_ORDER,
        "field_labels": FIELD_LABELS,
    })


@app.route("/regenerate", methods=["POST"])
def regenerate_workbook():
    data = request.get_json(silent=True) or {}
    fields = data.get("fields") or {}
    raw_text = data.get("raw_text") or ""
    source_name = data.get("source_name") or "reviewed_form11"
    confidence = data.get("confidence") or 0

    cleaned_fields = {}
    for key in FIELD_ORDER:
        cleaned_fields[key] = uppercase_value(fields.get(key, ""))

    workbook_name = save_workbook(cleaned_fields, raw_text, source_name, confidence)
    return jsonify({
        "success": True,
        "workbook_name": workbook_name,
        "workbook_url": f"/outputs/{workbook_name}",
    })


if __name__ == "__main__":
    app.run(debug=True)
