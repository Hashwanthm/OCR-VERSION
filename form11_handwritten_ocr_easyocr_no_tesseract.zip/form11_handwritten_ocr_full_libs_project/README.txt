FORM 11 HANDWRITTEN OCR - EASYOCR VERSION

This is a NEW separate project. It does not change the existing Form 3A project.

This version does NOT need the separate Tesseract OCR installation.
It uses EasyOCR from Python packages.

Purpose:
- Upload scanned/handwritten Form 11 PDF or image.
- Extract handwritten values using OCR.
- Convert extracted values to CAPITAL LETTERS.
- Show extracted fields for review/editing.
- Generate Excel workbook.
- Supports up to 10 files.
- Duplicate file checking is included.

Python libraries used:
1. Flask - local offline web application
2. Werkzeug - safe file upload names
3. PyMuPDF / fitz - convert PDF page to image
4. Pillow - image loading and preprocessing
5. OpenCV - denoise and threshold scanned/handwritten images
6. NumPy - image array processing for OpenCV/EasyOCR
7. EasyOCR - OCR engine without separate Tesseract installer
8. openpyxl - Excel workbook creation and formatting
9. pandas - clean extracted-data table sheet
10. python-dateutil - stronger date parsing/normalization
11. rapidfuzz - fuzzy YES/NO cleanup from OCR text

Install:
1. Open command prompt in this project folder.
2. Create virtual environment:
   python -m venv venv
3. Activate:
   venv\Scripts\activate
4. Install libraries:
   pip install -r requirements.txt
5. Run:
   python app.py
6. Open browser:
   http://127.0.0.1:5000

Important:
- First run may download the EasyOCR English model. After that, it can run locally from cache.
- EasyOCR installation can be large because it uses PyTorch internally.
- Handwritten OCR cannot guarantee 100% accuracy. The app includes review/edit fields before downloading the final Excel.
